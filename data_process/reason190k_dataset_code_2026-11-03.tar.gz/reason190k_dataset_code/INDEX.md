# reason-190k dataset-processing code (copied 2026-11-03 from /scratch/ducpham/Working)

Paths below are relative to /scratch/ducpham/Working on the source machine. Data files (jsonl, pkl, videos) are not included.

## Question pool (190k mix)
- spatial_reasoning/finetuning/idea_3i_190k_es_64f_lat512_clean/build_mix.py, build_mix_180k.py, filter_mix_es.py, build_mix_190k.py
- dataset/idea_3i_dataset_jsons/mix_stats*.json, dropped_scenes.txt  (outputs' statistics)
- dataset/vsi_590k/VSI-590K/README.md, dataset/vlm_3r_data/README.md  (question sources)

## det_es: 64 posed frames + GT boxes in the camera-0 frame
- dataset/vgllm_data/det64f_posed_mp4/build_posed64f.py  (ScanNet + ARKitScenes, EmbodiedScan annotations)
- dataset/vgllm_data/det64f_posed_es/build_posed64f_scannetpp.py  (ScanNet++ raw annotations); det_es_orientation.py = orientation audit
- spatial_reasoning/scene_graph_idea/VG-LLM/scripts/preprocess/utils.py, process_threedod.py  (embodiedscan_bbox_to_o3d_geo, o3d_geo_to_9dof, create_question_answer)
- spatial_reasoning/finetuning/legacy/idea_3i_130k_joint_cached_64f/graph_vgllm.py  (canonicalize, box parsing/metrics)
- spatial_reasoning/scene_graph_idea/processing_scannetpp_3dod/export_scannetpp_3dod.py  (to_camera), scannetpp_vgllm/export_scannetpp.py
- NOT on the source machine, needed by build_posed64f_scannetpp.py: prep_scene.py, labelmap.py, bench_ids.json (Jean Zay)

## ScanNet++ poses and download
- dataset/scannetpp/DET_ES_OPTIONS.md  (pose source choice, frame mapping, measurements)
- dataset/scannetpp/_det_es_proto/q*.py + q*.json  (measurement scripts and results)
- dataset/scannetpp/data_download/*.yml, *.sh, download_scannetpp.py  (token removed from every yml)
- dataset/scannetpp/splits/*.txt
- extra/scannetpp_cam0/cam0_convert.py + README.md  (world -> first-frame camera, numpy only)

## Benchmark side
- dataset/vsib_det64f/*.py  (VSI-Bench det_es build), dataset/vsibench_rebuilt/build_vsibench_rebuilt.py
- spatial_reasoning/finetuning/gemma_eval/*.py  (scene-text evals, box helpers)

## Reasoning traces (reason-190k targets)
- dataset/idea_3i_dataset_jsons/simplesr_traces_20260920/README.md, statistics.txt, full_statistics.txt
- spatial_reasoning/finetuning/idea_3i_190k_es_64f_lat512_text256_reason/collator.py, train.py  (consumer: target format and loading)
- spatial_reasoning/sr_vggt/sr_vggt/data.py (frame-sampling rule), reasoning.py (prompt, answer parsing)
- The trace generator itself is NOT here: Jean Zay /lustre/fswork/projects/rech/fcf/uyj73pb/scenecodemllm/

## Notes
- spatial_reasoning/finetuning/NAMING.md, EXPERIMENTS.md, notes.md; spatial_reasoning/sr_vggt/README.md, EXPERIMENTS.md
