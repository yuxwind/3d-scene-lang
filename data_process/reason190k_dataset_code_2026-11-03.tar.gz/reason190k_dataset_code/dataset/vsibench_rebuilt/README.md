# vsibench_rebuilt

VSI-Bench eval rows exactly as `spatial_reasoning/finetuning/*/eval.py` builds them (`build_eval_dataset`),
with the benchmark's own keys kept so prediction files can be joined back to the benchmark.

- `vsibench_full.jsonl` — HF config `full`, 5130 rows, HF order (`--split full`).
- `vsibench_debiased_scannetpp.jsonl` — HF config `debiased` filtered to ScanNet++ videos, 752 rows (`--split debiased`).

Fields: `index` (row position = the `index` in `predictions_*_shard*.jsonl`), `id` / `dataset` / `scene_name`
(VSI-Bench columns; `id` has gaps), `question_type`, `question` (the prompt text the model sees, lmms-eval
default suffixes), `options`, `ground_truth`, `video` (local path resolved by lmms-eval).

Rebuild: `python build_vsibench_rebuilt.py` in the `vsibench_eval_full` env with `HF_HUB_OFFLINE=1`.
