"""Dump the VSI-Bench eval rows exactly as finetuning/*/eval.py builds them, with the benchmark keys kept.

One jsonl per split. `index` is the row position our predictions files use; `id`, `dataset`,
`scene_name` are VSI-Bench's own columns; `question` is the prompt text the model sees.
  python build_vsibench_rebuilt.py
"""
import json, sys
from pathlib import Path
FT = Path("/scratch/ducpham/Working/spatial_reasoning/finetuning")
sys.path.insert(0, str(FT / "common"))
from datasets import load_dataset
from data import LMMS_DEFAULT_VSIBENCH_KW, vsibench_doc_to_text, vsibench_doc_to_visual, DEFAULT_HF_HOME

SPLITS = {"full": ("full", False), "debiased_scannetpp": ("debiased", True)}  # eval.py SPLIT_CONFIG
for name, (config, scannetpp_only) in SPLITS.items():
    ds = load_dataset("nyu-visionx/VSI-Bench", config, cache_dir=DEFAULT_HF_HOME)["test"]
    rows, skipped = [], 0
    for ex in ds:
        paths = vsibench_doc_to_visual(ex)
        if not paths:
            skipped += 1
            continue
        if scannetpp_only and "scannetpp" not in str(paths[0]).lower():
            continue
        rows.append({
            "index": len(rows),
            "id": ex["id"], "dataset": ex["dataset"], "scene_name": ex["scene_name"],
            "question_type": ex["question_type"],
            "question": vsibench_doc_to_text(ex, lmms_eval_specific_kwargs=LMMS_DEFAULT_VSIBENCH_KW),
            "options": ex.get("options"),
            "ground_truth": str(ex["ground_truth"]),
            "video": str(paths[0]),
        })
    out = Path(f"vsibench_{name}.jsonl")
    with out.open("w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    print(f"{out}: {len(rows)} rows (config {config}, {skipped} rows without video skipped)")
    assert skipped == 0, "eval.py would drop these rows too; index alignment with predictions breaks"
