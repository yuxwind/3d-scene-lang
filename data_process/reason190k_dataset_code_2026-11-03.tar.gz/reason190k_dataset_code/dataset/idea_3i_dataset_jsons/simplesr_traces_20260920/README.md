# SimpleSR reasoning traces

Verified reasoning traces for the 190k spatial VQA pool, one record per question that could be annotated.

## Format

One JSON object per line, in the same schema as `vqa_train_190k_es_clean.jsonl`. The only field that differs is the
assistant turn, which carries the trace instead of the bare answer. The human turn is copied verbatim, so the question
the model sees is unchanged.

```json
{"task": "vqa",
 "video": "<same path as in the source file>",
 "conversations": [{"from": "human", "value": "These are frames of a video.\n<question>"},
                   {"from": "gpt",   "value": "<opener>\n<scene>[...]</scene>\n<think>...</think>\nAnswer: <answer>"}],
 "question_type": "...", "source": "vlm3r|vsi590k",
 "meta": {"i": <line index in the source file>, "dataset": "...", "scene": "...", "unit": "...",
          "attempt": 1|2, "answer": "<original answer>", "boxes": [<box ids used>], "tokens": <generated>}}
```

`meta` is ours; a loader that ignores unknown keys is unaffected. `video` is copied unchanged from the source file, so
it points at the same place as the original data; rewrite that one field if the data sits elsewhere.

## The target

```
Let me look at the 3D scene and locate the objects this question is about.
<scene>
[
    {"label": "keyboard", "bbox_3d": [2.12, 1.14, -1.06, 0.55, 0.58, 0.8]},
    {"label": "monitor",  "bbox_3d": [3.33, 1.57, -0.56, 0.57, 0.13, 0.42]}
]
</scene>
<think>
... arithmetic over the numbers above ...
</think>
Answer: 0.7
```

`bbox_3d` is `[x, y, z, w, d, h]` in metres, two decimals: centre and full extents. The origin is the camera of the
first of the 64 sampled frames; the axes follow the room and z points up, so every box is upright and axis-aligned.
Objects are listed in the order in which they first appear in the video, and repeated labels are numbered
("chair 1", "chair 2"). Only the objects the question needs are listed.

## What "verified" means

Each trace was written by Gemma-4-26B-A4B-it from the question and the scene block alone: no video, no answer, no
tools. A trace is in this file only if it passed every check:

- the conclusion matches the reference answer (exact option, or mean relative accuracy >= 0.8 for a number);
- every equation was re-evaluated on both sides, and every number comes from the scene block, from an earlier verified
  result, or from a conversion factor stated in the prompt;
- no mention of identifiers, tools or the reference answer.

Traces that failed were dropped, never repaired. Questions that failed once were given one more blind attempt by
sampling; `meta.attempt` says which attempt produced the trace.

Questions whose boxes could not reproduce the reference answer are absent: they were never annotated.

## Files

- `train_traces.jsonl` - the full set
- `sample_60.jsonl` - 60 records spread over the question types, to check the format first
- `statistics.txt` - counts by dataset and question type
- `full_statistics.txt` - the annotation funnel: questions, verified, attempted, kept, by dataset, type, source and unit
