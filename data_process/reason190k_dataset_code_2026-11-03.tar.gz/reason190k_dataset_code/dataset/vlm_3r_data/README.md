---
license: apache-2.0
---

# VLM-3R Training Data

Training QA data for VLM-3R: `vsibench_train/` (VSI-Bench-style tasks) and
`vstibench_train/` (VSTI-Bench tasks over ScanNet train split).

## Erratum (2026-07-13): corrected camera-position ground truth

A bug in the QA generation pipeline (reported by
[Jacob Yeung](https://jacobyeung.org/), CMU) extracted
the camera center from camera-to-world poses using `-R.T @ t` instead of
`pose[:3, 3]`. Answers in five `vstibench_train` files depended on the camera's
world position and have been corrected in place; items whose corrected
geometry violates the generators' validity filters (distance range, option
ambiguity margin, minimum object distance) were removed and are listed in
`vstibench_train/erratum_dropped_items.json`.

Affected files: `qa_camera_displacement.json`, `qa_camera_obj_abs_dist.json`,
`qa_camera_obj_rel_dist_v1/v2/v3.json`. All other files (camera movement
direction, object-object relative position, and all `vsibench_train` files)
do not depend on the camera position bug and are unchanged.

Models fine-tuned on the pre-correction files learned a systematically biased
target for these question types; retraining on this revision is recommended.
Pre-correction files remain available in the git history. The corrected
generation code and correction scripts are in the
[VLM-3R repository](https://github.com/VITA-Group/VLM-3R)
(`vlm_3r_data_process/scripts/vstibench/`).

The corresponding evaluation benchmark was corrected in the same way; see the
erratum in [Journey9ni/vstibench](https://huggingface.co/datasets/Journey9ni/vstibench).
