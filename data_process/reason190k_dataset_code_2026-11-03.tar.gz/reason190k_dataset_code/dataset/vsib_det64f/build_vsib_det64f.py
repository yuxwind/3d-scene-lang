"""det.json + meta.json per VSI-Bench-Debiased ScanNet scene, posed-64f style (build_posed64f.py), no frames written.

The 86 VSI-Bench ScanNet scenes are ScanNet val = EmbodiedScan TEST split: the pkl has poses but no instances, so GT
boxes come from Chat-Scene's scannet_val_attributes.pt (ScanNet GT AABBs in the axis-aligned mesh frame, verified:
aligned camera centres fall inside the object extents, raw ones do not). Visibility = frustum test of the box corners
in the 64 selected posed frames (EmbodiedScan's depth-checked visible_instance_ids are not available for test scenes).
Frames: 64 uniform over the EmbodiedScan-posed frames with mp4 idx (== posed id) < mp4 length, frame00 = camera 0.
Boxes: 9-DoF ZXY in camera 0 exactly as build_posed64f.py (scipy as_euler('ZXY') on g2c[:3,:3] @ I).

python build_vsib_det64f.py [scene ...]   ->  vsib_det64f/scannet/<scene>/{det.json,meta.json} + stats.json
Extra scene args are added to the debiased list: the VSI-Bench full split adds scene0208_00 scene0598_02.
"""
import json, os, pickle, sys
from collections import Counter
import numpy as np, pandas as pd, torch
import cv2  # noqa: F401  (import before decord)
import decord
from scipy.spatial.transform import Rotation

W = "/scratch/ducpham/Working"
JZ = "/lustre/fsn1/projects/rech/btf/uff48lg"
PARQUET = f"{W}/dataset/vsib/VSI-Bench-extended/test_debiased_scannet.parquet"
PKL = f"{W}/dataset/embodiedscan/embodiedscan/embodiedscan_infos_test.pkl"
ATTR = (f"{W}/cache/hub/datasets--ZzZZCHS--Chat-Scene/snapshots/230e8b58cb0638aca3d62e6821a529fc9394d99c/"
        "annotations/scannet_val_attributes.pt")
MP4 = f"{W}/dataset/vsib/vsibench/scannet"
OUT = f"{W}/dataset/vsib_det64f/scannet"
N_FRAMES, FPS, HW = 64, 30.0, (968, 1296)      # cam2img is for the 1296x968 posed images
EXCLUDE = {"wall", "ceiling", "floor", "object"}
CORNER = np.array([[sx, sy, sz] for sx in (-.5, .5) for sy in (-.5, .5) for sz in (-.5, .5)])


def visible(center, size, Ts, K):
    pts = np.r_[center[None], center + CORNER * size]                    # centre + 8 corners, world
    for T in Ts:
        p = (np.linalg.inv(T) @ np.c_[pts, np.ones(len(pts))].T)[:3]     # cam
        z = p[2]; uv = (K @ p)[:2] / np.where(z > 0, z, 1)
        if np.any((z > 0.05) & (uv[0] >= 0) & (uv[0] < HW[1]) & (uv[1] >= 0) & (uv[1] < HW[0])):
            return True
    return False


def build(sc, s, att):
    A = np.array(s["axis_align_matrix"]); ims = s["images"]; K = np.array(s["cam2img"])[:3, :3]
    pid = np.array([int(im["img_path"].split("/")[-1][:-4]) for im in ims]); assert pid[0] == 0, sc
    total = len(decord.VideoReader(f"{MP4}/{sc}.mp4", num_threads=2))
    pool = np.flatnonzero(pid < total)
    sel = pool[np.unique(np.linspace(0, len(pool) - 1, N_FRAMES).round().astype(int))]
    Ts = [A @ np.array(ims[p]["cam2global"]) for p in sel]; cam0 = Ts[0]; g2c = np.linalg.inv(cam0)
    frames = [{"frame": j, "mp4_idx": int(pid[p]), "time_s": float(pid[p] / FPS), "posed_id": f"{pid[p]:05d}",
               "img_path": ims[p]["img_path"], "cam2global": T.tolist()} for j, (p, T) in enumerate(zip(sel, Ts))]
    locs = att["locs"].numpy(); boxes = []; n_all = 0
    for k, (lab, loc) in enumerate(zip(att["objects"], locs)):
        if lab in EXCLUDE:
            continue
        n_all += 1
        if not visible(loc[:3], loc[3:], Ts, K):
            continue
        c = (g2c @ np.r_[loc[:3], 1])[:3]
        rot = Rotation.from_matrix(g2c[:3, :3]).as_euler("ZXY")
        boxes.append({"bbox_3d": [float(v) for v in np.r_[c, loc[3:], rot]], "label": lab, "instance_id": k})
    assert boxes, sc
    row = {"task": "det", "scene": sc, "video": f"{JZ}/dataset/vsib/vsibench/scannet/{sc}.mp4", "n_frames": len(sel),
           "boxes": boxes}
    meta = {"source": "scannet", "scene": sc, "mp4": row["video"], "mp4_local": f"{MP4}/{sc}.mp4", "fps": FPS,
            "mp4_num_frames": int(total), "n_posed": len(ims), "n_posed_in_clip": int(len(pool)), "n_frames": len(sel),
            "frames": frames, "cam0_cam2global": cam0.tolist(), "n_boxes": len(boxes), "n_boxes_before_visibility": n_all,
            "box_source": "ZzZZCHS/Chat-Scene scannet_val_attributes.pt (ScanNet GT AABB, axis-aligned frame)",
            "visibility": "frustum: centre or a corner inside one of the 64 frames"}
    os.makedirs(f"{OUT}/{sc}", exist_ok=True)
    json.dump(row, open(f"{OUT}/{sc}/det.json", "w")); json.dump(meta, open(f"{OUT}/{sc}/meta.json", "w"))
    return meta


def main():
    scenes = sorted(set(pd.read_parquet(PARQUET).scene_name) | set(sys.argv[1:]))
    ES = {s["sample_idx"].split("/")[-1]: s for s in pickle.load(open(PKL, "rb"))["data_list"] if s["sample_idx"].startswith("scannet/")}
    ATT = torch.load(ATTR, weights_only=False)
    missing = [sc for sc in scenes if sc not in ES or sc not in ATT]
    metas = {sc: build(sc, ES[sc], ATT[sc]) for sc in scenes if sc not in missing}
    pct = lambda v: dict(zip(["min", "p50", "max"], np.percentile(v, [0, 50, 100]).round(2).tolist()))
    ms = list(metas.values())
    stats = {"scenes": len(scenes), "built": len(metas), "missing": missing, "n_frames": pct([m["n_frames"] for m in ms]),
             "boxes": pct([m["n_boxes"] for m in ms]), "boxes_before_visibility": pct([m["n_boxes_before_visibility"] for m in ms]),
             "dropped_by_visibility": int(sum(m["n_boxes_before_visibility"] - m["n_boxes"] for m in ms)),
             "n_posed_in_clip": pct([m["n_posed_in_clip"] for m in ms]), "frames_hist": dict(sorted(Counter(m["n_frames"] for m in ms).items()))}
    json.dump(stats, open(f"{OUT}/stats.json", "w"), indent=1); print(json.dumps(stats, indent=1))
    assert not missing, missing


if __name__ == "__main__":
    main()
