"""Validate the VSI-Bench det_es caches (scannet 86 / scannetpp 49, eval only): frames present at the LLM size, json parses,
labels in the 288 vocab, finite 9-DoF boxes / poses, frame 0 == camera 0. Writes vsib_det64f/<source>/stats_eval.json and one
montage per source (N scenes x 8 frames, det.json boxes projected) to vsib_det64f/_viz/montage_<source>.jpg.

python check_det_es.py [--source scannet scannetpp] [--montage 6] [--extra_scenes sc ...]
--extra_scenes are checked on top of the debiased list (full split: --source scannet --extra_scenes scene0208_00 scene0598_02).
"""
import argparse, json, os, pickle, sys
from collections import Counter
import cv2, numpy as np, pandas as pd
from PIL import Image

W = "/scratch/ducpham/Working"
sys.path.insert(0, f"{W}/spatial_reasoning/finetuning/viz_posed64f")
from labelmap import VOCAB_SET  # noqa: E402
from grid_video_utils import load_scene, draw_frame, tile, header, TILE, WHITE, RED  # noqa: E402

ROOT, OUT = f"{W}/dataset/vsib/vsibench", f"{W}/dataset/vsib_det64f"
LLM_WH = (384, 256)
ES_PKL = f"{W}/dataset/embodiedscan/embodiedscan/embodiedscan_infos_test.pkl"   # ScanNet det_es meta has no cam2img/native_hw


def scenes_of(source):
    return sorted(set(pd.read_parquet(f"{W}/dataset/vsib/VSI-Bench-extended/test_debiased_{source}.parquet").scene_name))


def check(source, extra=()):
    errs, metas, nbytes, unk = [], {}, 0, Counter()
    scenes = sorted(set(scenes_of(source)) | set(extra))
    for sc in scenes:
        d = f"{ROOT}/{source}/{sc}/det_es"
        if not os.path.exists(f"{d}/det.json"):
            errs.append(f"{sc}: not built"); continue
        meta, row = json.load(open(f"{d}/meta.json")), json.load(open(f"{d}/det.json"))
        fr, n = meta["frames"], meta["n_frames"]
        files = sorted(os.listdir(f"{d}/frames"))
        if len(fr) != n or files != [f"frame{j:02d}.jpg" for j in range(n)] or row["n_frames"] != n:
            errs.append(f"{sc}: {len(files)} frame files / {len(fr)} frames meta / n_frames {n}")
        bad = [f for f in files if Image.open(f"{d}/frames/{f}").size != LLM_WH]
        if bad:
            errs.append(f"{sc}: {len(bad)} frames not {LLM_WH}, e.g. {bad[0]}")
        nbytes += sum(os.path.getsize(f"{d}/{x}") for x in ("meta.json", "det.json")) + sum(os.path.getsize(f"{d}/frames/{f}") for f in files)
        if not row["boxes"]:
            errs.append(f"{sc}: zero boxes")
        for b in row["boxes"]:
            v = np.asarray(b["bbox_3d"], float)
            if b["label"] not in VOCAB_SET:
                unk[b["label"]] += 1
            if v.shape != (9,) or not np.isfinite(v).all() or (v[3:6] <= 0).any():
                errs.append(f"{sc}: bad box {b}")
        poses = np.array([f["cam2global"] for f in fr], float)
        if poses.shape != (n, 4, 4) or not np.isfinite(poses).all():
            errs.append(f"{sc}: poses not finite / wrong shape")
        if fr[0]["frame"] != 0 or fr[0]["mp4_idx"] != 0 or not np.allclose(fr[0]["cam2global"], meta["cam0_cam2global"]):
            errs.append(f"{sc}: frame 0 != camera 0")
        metas[sc] = meta
    ms = list(metas.values()); nb = [m["n_boxes"] for m in ms]
    stats = {"source": source, "scenes": len(scenes), "built": len(ms), "errors": len(errs), "error_list": errs[:50],
             "frames_hist": dict(sorted(Counter(m["n_frames"] for m in ms).items())),
             "boxes_per_scene": {"min": min(nb), "median": float(np.median(nb)), "max": max(nb)} if nb else {},
             "boxes_total": int(sum(nb)), "labels_not_in_vocab": {"boxes": sum(unk.values()), "top": unk.most_common(20)},
             "bytes_on_disk": nbytes, "llm_wh": LLM_WH}
    json.dump(stats, open(f"{OUT}/{source}/stats_eval.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in stats.items() if k != "error_list"}), flush=True)
    for e in errs[:20]:
        print("FAIL", e)
    return stats


def montage(source, n_scenes, path):
    """n_scenes rows (evenly spaced over the source) x 8 frames, boxes projected as grid_video_utils."""
    scenes = scenes_of(source); scenes = [scenes[i] for i in np.linspace(0, len(scenes) - 1, n_scenes).round().astype(int)]
    es = {}
    if source == "scannet":
        es = {s["sample_idx"].split("/")[-1]: s for s in pickle.load(open(ES_PKL, "rb"))["data_list"] if s["sample_idx"].startswith("scannet/")}
    rows = []
    for sc in scenes:
        d = f"{ROOT}/{source}/{sc}/det_es"
        if not os.path.exists(f"{d}/det.json"):
            continue
        meta, row, frames, boxes, poses = load_scene(d)
        if source == "scannet":                                  # EmbodiedScan K is for the posed jpg size
            meta["native_hw"] = Image.open(f"{W}/dataset/{meta['frames'][0]['img_path']}").size[::-1]
            for f in meta["frames"]:
                f["cam2img"] = np.array(es[sc]["cam2img"])[:3, :3].tolist()
        sel = np.linspace(0, len(frames) - 1, 8).round().astype(int)
        tiles = [tile(draw_frame(frames[i], meta, meta["frames"][i], boxes, poses[i]), TILE) for i in sel]
        bar = header(8 * TILE[0], [(f"{source} {sc} n_frames={len(frames)}", WHITE if len(frames) >= 64 else RED),
                                   (f"boxes={len(boxes)} frames {sel.tolist()}", WHITE)])
        rows.append(np.vstack([bar, np.hstack(tiles)]))
    cv2.imwrite(path, np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 90]); print("montage ->", path)


def main():
    p = argparse.ArgumentParser(); p.add_argument("--source", nargs="+", default=["scannet", "scannetpp"])
    p.add_argument("--montage", type=int, default=6); p.add_argument("--extra_scenes", nargs="+", default=[]); a = p.parse_args()
    os.makedirs(f"{OUT}/_viz", exist_ok=True)
    for src in a.source:
        check(src, a.extra_scenes)
        if a.montage:
            montage(src, a.montage, f"{OUT}/_viz/montage_{src}.jpg")


if __name__ == "__main__":
    main()
