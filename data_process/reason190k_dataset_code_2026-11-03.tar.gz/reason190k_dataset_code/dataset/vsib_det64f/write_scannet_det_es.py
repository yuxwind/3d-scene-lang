"""det_es for the 86 VSI-Bench-Debiased ScanNet scenes (eval only): vsib_det64f/scannet/<scene>/{det,meta}.json copied unchanged
next to the VSI-Bench mp4 + frames/frameNN.jpg from the EmbodiedScan posed_images pixels, resized as build_posed64f.build_es.

python write_scannet_det_es.py [--workers 16] [--scenes sc ...]  ->  dataset/vsib/vsibench/scannet/<scene>/det_es/{frames/, meta.json, det.json}
"""
import argparse, json, os, shutil, sys
from collections import Counter
from multiprocessing import Pool
from PIL import Image

W = "/scratch/ducpham/Working"
sys.path.insert(0, f"{W}/spatial_reasoning/finetuning/legacy/idea_3i_130k_joint_cached_64f")   # graph_vgllm, as build_posed64f_scannetpp.py
sys.path.insert(0, f"{W}/dataset/vgllm_data/det64f_posed_mp4")
from build_posed64f import smart_resize, FACTOR, MIN_PIXELS, MAX_PIXELS  # noqa: E402

SRC, OUT = f"{W}/dataset/vsib_det64f/scannet", f"{W}/dataset/vsib/vsibench/scannet"


def build_one(sc):
    d = f"{OUT}/{sc}/det_es"; os.makedirs(f"{d}/frames", exist_ok=True)
    meta = json.load(open(f"{SRC}/{sc}/meta.json"))
    for j, f in enumerate(meta["frames"]):
        assert f["frame"] == j, (sc, j)
        a = Image.open(f"{W}/dataset/{f['img_path']}").convert("RGB")
        h, w = smart_resize(a.height, a.width, FACTOR, MIN_PIXELS, MAX_PIXELS)
        a.resize((w, h)).save(f"{d}/frames/frame{j:02d}.jpg", "JPEG", quality=95)   # == build_es
    for fn in ("meta.json", "det.json"):
        shutil.copyfile(f"{SRC}/{sc}/{fn}", f"{d}/{fn}")
    return sc, len(meta["frames"]), (h, w)


def main():
    p = argparse.ArgumentParser(); p.add_argument("--workers", type=int, default=16)
    p.add_argument("--scenes", nargs="+", help="only these (default: every scene built in vsib_det64f/scannet)"); a = p.parse_args()
    scenes = a.scenes or sorted(sc for sc in os.listdir(SRC) if os.path.isdir(f"{SRC}/{sc}"))
    with Pool(a.workers) as pool:
        res = pool.map(build_one, scenes)
    print(len(res), "scenes; frames", dict(sorted(Counter(n for _, n, _ in res).items())), "llm_hw", Counter(hw for *_, hw in res))


if __name__ == "__main__":
    main()
