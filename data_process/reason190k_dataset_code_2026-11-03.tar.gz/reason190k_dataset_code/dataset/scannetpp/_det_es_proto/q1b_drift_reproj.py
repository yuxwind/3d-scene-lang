"""Q1b: (i) ARKit aligned_pose relative-motion error vs COLMAP as a function of the frame gap (proxy for accuracy inside COLMAP holes);
(ii) reprojection error in pixels of mesh points at registered frames: (COLMAP pose, COLMAP K+dist) vs (aligned_pose, ARKit K) / (aligned_pose, COLMAP K+dist)."""
import json, sys, numpy as np, cv2
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/finetuning/viz_posed64f")
from prep_scene import read_colmap
import open3d as o3d
D = "/scratch/ducpham/Working/dataset/scannetpp/data"
def m44(p): return np.vstack([np.array(p, float), [0, 0, 0, 1]]) if len(p) == 3 else np.array(p, float)
def rot_err(Ra, Rb): return np.degrees(np.arccos(np.clip((np.trace(Ra.T @ Rb) - 1) / 2, -1, 1)))
out = {}
for sc in sys.argv[1:]:
    j = json.load(open(f"{D}/{sc}/iphone/pose_intrinsic_imu.json")); K, dist, colmap, W, H = read_colmap(f"{D}/{sc}/iphone/colmap")
    reg = sorted(colmap); ark = {int(k.split("_")[1]): m44(v["aligned_pose"]) for k, v in j.items()}
    Ka = {int(k.split("_")[1]): (lambda a: a if a.shape == (3, 3) else np.vstack([a, [0, 0, 1]]))(np.array(v["intrinsic"], float)) for k, v in j.items()}
    # (i) relative motion over gaps g (in frames): COLMAP pair (i, i+g) vs ARKit pair
    rel = {}
    for g in (10, 50, 100, 300, 600, 1200):
        errs = []
        for i in reg:
            if i + g in colmap and i in ark and i + g in ark:
                Rc = np.linalg.inv(colmap[i]) @ colmap[i + g]; Ra = np.linalg.inv(ark[i]) @ ark[i + g]
                errs.append((rot_err(Rc[:3, :3], Ra[:3, :3]), np.linalg.norm(Rc[:3, 3] - Ra[:3, 3])))
        if errs:
            e = np.array(errs); rel[g] = {"n": len(e), "rot_p50_p95": np.percentile(e[:, 0], [50, 95]).round(3).tolist(), "trans_p50_p95_m": np.percentile(e[:, 1], [50, 95]).round(4).tolist()}
    # (ii) reprojection of mesh points (visible-ish: in front, in image under COLMAP) at every 5th registered frame
    V = np.asarray(o3d.io.read_triangle_mesh(f"{D}/{sc}/scans/mesh_aligned_0.05.ply").vertices); rng = np.random.default_rng(0); P = V[rng.choice(len(V), 20000, replace=False)]
    px = {"arkit_pose_arkit_K": [], "arkit_pose_colmap_K": []}
    for i in reg[::5]:
        if i not in ark: continue
        w2c = np.linalg.inv(colmap[i]); c = (w2c[:3, :3] @ P.T + w2c[:3, 3:4]).T; ok = (c[:, 2] > 0.3) & (c[:, 2] < 6)
        rv, _ = cv2.Rodrigues(w2c[:3, :3]); p0, _ = cv2.projectPoints(P[ok], rv, w2c[:3, 3], K, dist); p0 = p0.reshape(-1, 2)
        inimg = (p0[:, 0] > 0) & (p0[:, 0] < W) & (p0[:, 1] > 0) & (p0[:, 1] < H)
        if inimg.sum() < 50: continue
        w2a = np.linalg.inv(ark[i]); rva, _ = cv2.Rodrigues(w2a[:3, :3])
        p1, _ = cv2.projectPoints(P[ok], rva, w2a[:3, 3], Ka[i], None); p2, _ = cv2.projectPoints(P[ok], rva, w2a[:3, 3], K, dist)
        px["arkit_pose_arkit_K"].append(np.median(np.linalg.norm(p1.reshape(-1, 2)[inimg] - p0[inimg], axis=1)))
        px["arkit_pose_colmap_K"].append(np.median(np.linalg.norm(p2.reshape(-1, 2)[inimg] - p0[inimg], axis=1)))
    r = {"rel_motion_err_by_gap": rel, "reproj_px_median_per_frame_p50_p95_max@1920": {k: np.percentile(v, [50, 95, 100]).round(1).tolist() for k, v in px.items()},
         "json_MB": round(__import__("os").path.getsize(f"{D}/{sc}/iphone/pose_intrinsic_imu.json") / 1e6, 1), "n_json": len(j), "mkv_frames_in_json_first_last": [min(ark), max(ark)]}
    out[sc] = r; print(sc, json.dumps(r), flush=True)
json.dump(out, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q1b_drift_reproj.json", "w"), indent=1)
