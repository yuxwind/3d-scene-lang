"""Q4: labelmap coverage over the 856 VSI-590K scannetppv2 train scenes' segments_anno.json."""
import json, os, sys, numpy as np
from collections import Counter
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/finetuning/viz_posed64f")
from labelmap import to_vocab, EXCLUDE, VOCAB_SET
D = "/scratch/ducpham/Working/dataset/scannetpp/data"
ids = [f[:-4] for f in os.listdir("/scratch/ducpham/Working/dataset/vsi_590k/VSI-590K/scannetppv2") if f.endswith(".mp4")]
tot = Counter(); unm = Counter(); exc = Counter(); per_scene = []; raw_labels = Counter(); mapped_to = Counter(); missing = []
for sc in ids:
    p = f"{D}/{sc}/scans/segments_anno.json"
    if not os.path.exists(p):
        missing.append(sc); continue
    g = json.load(open(p))["segGroups"]
    n_ok = 0
    for x in g:
        l = x["label"].strip().lower(); raw_labels[l] += 1
        tot["instances"] += 1
        if l in EXCLUDE:
            tot["excluded"] += 1; exc[l] += 1; continue
        v = to_vocab(l)
        if v is None:
            tot["unmapped"] += 1; unm[l] += 1
        else:
            tot["mapped"] += 1; mapped_to[v] += 1; n_ok += 1
            tot["mapped_exact"] += (l in VOCAB_SET)
    per_scene.append(n_ok)
pct = lambda v: dict(zip(["min", "p5", "p25", "p50", "p75", "p95", "max"], np.percentile(v, [0, 5, 25, 50, 75, 95, 100]).round(1).tolist()))
res = {"scenes": len(ids), "missing_anno": missing, **tot, "frac_mapped_of_all": round(tot["mapped"] / tot["instances"], 4),
       "frac_mapped_of_nonexcluded": round(tot["mapped"] / (tot["instances"] - tot["excluded"]), 4),
       "excluded_by_label": dict(exc.most_common()), "n_raw_labels": len(raw_labels), "n_unmapped_labels": len(unm),
       "top_unmapped": unm.most_common(60), "boxes_per_scene_all_instances_mapped": pct(per_scene),
       "scenes_lt5": int(sum(np.array(per_scene) < 5)), "scenes_lt10": int(sum(np.array(per_scene) < 10)),
       "n_vocab_used": len(mapped_to), "top_mapped": mapped_to.most_common(30)}
json.dump(res, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q4_labels.json", "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k not in ("top_unmapped", "top_mapped")}))
print("TOP UNMAPPED", res["top_unmapped"][:40])
