"""Q4b: visibility (frustum + mesh-depth, >=30 of <=300 instance vertices) over 64 posed-uniform COLMAP frames for all 856 train scenes.
Records per-instance visible-frame counts + extents so k-frame / size filters can be applied post hoc."""
import json, os, sys, numpy as np
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/finetuning/viz_posed64f")
from prep_scene import read_colmap, MeshDepth
from labelmap import to_vocab
D = "/scratch/ducpham/Working/dataset/scannetpp/data"; OUT = "/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/vis856"
NPTS, DW, DH, DTOL = 300, 480, 360, 0.10
stats = json.load(open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q1c_colmap_stats.json"))

def one(sc):
    import open3d as o3d
    o = f"{OUT}/{sc}.json"
    if os.path.exists(o): return sc
    try:
        rng = np.random.default_rng(0)
        K, dist, colmap, W, H = read_colmap(f"{D}/{sc}/iphone/colmap"); reg = np.array(sorted(colmap)); n_mkv = stats[sc]["mp4_frames"]
        V = np.asarray(o3d.io.read_triangle_mesh(f"{D}/{sc}/scans/mesh_aligned_0.05.ply").vertices)
        render = MeshDepth(f"{D}/{sc}/scans/mesh_aligned_0.05.ply", K, W, H, DW, DH)
        inst = []
        for g in json.load(open(f"{D}/{sc}/scans/segments_anno.json"))["segGroups"]:
            lab = to_vocab(g["label"])
            if lab is None: continue
            seg = np.array(g["segments"]); P = V[seg if len(seg) <= NPTS else rng.choice(seg, NPTS, replace=False)]
            inst.append({"id": g["id"], "label": lab, "e": [round(float(v), 3) for v in g["obb"]["axesLengths"]], "n_seg": int(len(seg)), "P": P})
        pool = reg[reg < n_mkv]; sel = pool[np.unique(np.linspace(0, len(pool) - 1, 64).round().astype(int))]
        Kd = K * np.array([[DW / 1920], [DH / 1440], [1]]); nvis = np.zeros(len(inst), int); nfr = np.zeros(len(inst), int)
        for f in sel:
            T = colmap[int(f)]; depth = render(T); w2c = np.linalg.inv(T)
            for k, x in enumerate(inst):
                c = (w2c[:3, :3] @ x["P"].T + w2c[:3, 3:4]).T; z = c[:, 2]; ok = z > 0.1
                u = Kd[0, 0] * c[:, 0] / np.where(ok, z, 1) + Kd[0, 2]; v = Kd[1, 1] * c[:, 1] / np.where(ok, z, 1) + Kd[1, 2]
                inf = ok & (u >= 0) & (u < DW) & (v >= 0) & (v < DH)
                if inf.sum() >= 30: nfr[k] += 1
                if inf.sum() < 30: continue
                d = depth[v[inf].astype(int), u[inf].astype(int)] / 1000.0
                if (((d == 0) | (z[inf] <= d + DTOL)).sum()) >= 30: nvis[k] += 1
        json.dump({"scene": sc, "n_frames": len(sel), "first_frame": int(sel[0]), "sel": sel.tolist(),
                   "inst": [{k: v for k, v in x.items() if k != "P"} | {"n_frustum_frames": int(a), "n_visible_frames": int(b)} for x, a, b in zip(inst, nfr, nvis)]}, open(o, "w"))
    except Exception as e:
        json.dump({"scene": sc, "error": repr(e)}, open(o, "w"))
    return sc

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    from multiprocessing import Pool
    ids = sorted(stats)
    with Pool(12) as p:
        for n, sc in enumerate(p.imap_unordered(one, ids, chunksize=2)):
            if n % 50 == 0: print(n, sc, flush=True)
    print("done")
