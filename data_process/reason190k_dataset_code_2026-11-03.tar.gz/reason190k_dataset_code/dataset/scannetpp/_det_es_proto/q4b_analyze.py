import json, os, numpy as np
from collections import Counter
D = "/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/vis856"
pct = lambda v: dict(zip(["min", "p5", "p25", "p50", "p75", "p95", "max"], np.percentile(v, [0, 5, 25, 50, 75, 95, 100]).round(1).tolist())) if len(v) else {}
R = [json.load(open(f"{D}/{f}")) for f in sorted(os.listdir(D))]
err = [r for r in R if "error" in r]; R = [r for r in R if "inst" in r]
rules = {"all_mapped": lambda x: True, "frustum>=1f": lambda x: x["n_frustum_frames"] >= 1, "visible>=1f": lambda x: x["n_visible_frames"] >= 1,
         "visible>=2f": lambda x: x["n_visible_frames"] >= 2, "visible>=3f": lambda x: x["n_visible_frames"] >= 3,
         "visible>=1f & maxext>=0.1m": lambda x: x["n_visible_frames"] >= 1 and max(x["e"]) >= 0.1,
         "visible>=1f & maxext>=0.2m": lambda x: x["n_visible_frames"] >= 1 and max(x["e"]) >= 0.2,
         "visible>=2f & maxext>=0.2m": lambda x: x["n_visible_frames"] >= 2 and max(x["e"]) >= 0.2}
out = {"scenes_done": len(R), "errors": [e["scene"] for e in err], "first_frame": pct([r["first_frame"] for r in R]), "first_frame_gt0": sum(r["first_frame"] > 0 for r in R), "n_frames": dict(Counter(r["n_frames"] for r in R))}
for name, f in rules.items():
    c = [sum(f(x) for x in r["inst"]) for r in R]
    out[name] = {**pct(c), "scenes_0": int(sum(np.array(c) == 0)), "scenes_lt5": int(sum(np.array(c) < 5)), "scenes_gt64": int(sum(np.array(c) > 64)), "total": int(sum(c))}
labs = Counter(x["label"] for r in R for x in r["inst"] if x["n_visible_frames"] >= 1)
out["top_labels_visible"] = labs.most_common(25)
out["frac_instances_visible"] = round(sum(x["n_visible_frames"] >= 1 for r in R for x in r["inst"]) / sum(len(r["inst"]) for r in R), 4)
out["visible_frames_per_instance"] = pct([x["n_visible_frames"] for r in R for x in r["inst"]])
json.dump(out, open("q4b_summary.json", "w"), indent=1); print(json.dumps(out, indent=1))
