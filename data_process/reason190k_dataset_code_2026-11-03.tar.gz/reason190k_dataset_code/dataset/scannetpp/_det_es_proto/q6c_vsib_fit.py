import json, numpy as np, cv2, decord
D = "/scratch/ducpham/Working/dataset/scannetpp/data"
def small(a): return cv2.resize(a, (64, 48)).astype(float).ravel()
def corr(a, b): return float(np.corrcoef(a, b)[0, 1])
out = {}
for sc in ["0d2ee665be", "286b55a2bf", "5eb31827b7"]:
    vk = decord.VideoReader(f"{D}/{sc}/iphone/rgb.mkv", num_threads=2); vm = decord.VideoReader(f"/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/{sc}.mp4", num_threads=2)
    nm, nk = len(vm), len(vk); pts = []
    for i in [20, nm // 4, nm // 2, 3 * nm // 4, nm - 20]:
        m = small(vm[i].asnumpy()); lo, hi = max(0, 2 * i - 60), min(nk, 2 * i + 20)
        ks = vk.get_batch(list(range(lo, hi))).asnumpy(); cs = [corr(small(k), m) for k in ks]
        j = lo + int(np.argmax(cs)); pts.append({"i": i, "best_j": j, "best_corr": round(max(cs), 3), "j_minus_2i": j - 2 * i, "corr_at_2i": round(cs[2 * i - lo], 3)})
    a, b = np.polyfit([p["i"] for p in pts], [p["best_j"] for p in pts], 1)
    out[sc] = {"mkv": nk, "mp4": nm, "mkv_fps": float(vk.get_avg_fps()), "mp4_fps": float(vm.get_avg_fps()), "fit_j=a*i+b": [round(a, 5), round(b, 2)], "pts": pts}
    print(sc, json.dumps(out[sc]), flush=True)
json.dump(out, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q6c_vsib_fit.json", "w"), indent=1)
