"""Q1: ARKit pose_intrinsic_imu.json (pose / aligned_pose) vs COLMAP iphone poses on registered frames."""
import json, sys, numpy as np
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/finetuning/viz_posed64f")
from prep_scene import read_colmap
D = "/scratch/ducpham/Working/dataset/scannetpp/data"

def umeyama(src, dst, scale=False):
    mu_s, mu_d = src.mean(0), dst.mean(0); S, T = src - mu_s, dst - mu_d
    U, sv, Vt = np.linalg.svd(T.T @ S / len(src)); d = np.sign(np.linalg.det(U @ Vt))
    R = U @ np.diag([1, 1, d]) @ Vt
    c = (sv * [1, 1, d]).sum() / (S ** 2).sum() * len(src) if scale else 1.0
    return c, R, mu_d - c * R @ mu_s

def rot_err(Ra, Rb):
    return np.degrees(np.arccos(np.clip((np.trace(Ra.T @ Rb) - 1) / 2, -1, 1)))

def m44(p):
    return np.vstack([np.array(p, float), [0, 0, 0, 1]]) if len(p) == 3 else np.array(p, float)

out = {}
for sc in sys.argv[1:]:
    j = json.load(open(f"{D}/{sc}/iphone/pose_intrinsic_imu.json"))
    K, dist, colmap, W, H = read_colmap(f"{D}/{sc}/iphone/colmap")
    reg = sorted(colmap)
    n_frames = len(j)
    idx = [i for i in reg if f"frame_{i:06d}" in j]
    Tc = np.array([colmap[i] for i in idx])
    Ta = np.array([m44(j[f"frame_{i:06d}"]["aligned_pose"]) for i in idx])
    Tr = np.array([m44(j[f"frame_{i:06d}"]["pose"]) for i in idx])
    r = {"n_json_frames": n_frames, "n_colmap": len(reg), "n_common": len(idx), "first_colmap": reg[0], "last_colmap": reg[-1],
         "max_hole_frames": int(np.diff(reg).max()), "ints": [float(v) for v in j["frame_000000"]["intrinsic"][0][:1] + j["frame_000000"]["intrinsic"][0][2:3]], "K_colmap": [K[0, 0], K[0, 2], K[1, 2]]}
    # (a) aligned_pose directly vs colmap
    r["aligned_vs_colmap"] = {"rot_deg": np.percentile([rot_err(a[:3, :3], c[:3, :3]) for a, c in zip(Ta, Tc)], [50, 95, 100]).round(3).tolist(),
                              "trans_m": np.percentile(np.linalg.norm(Ta[:, :3, 3] - Tc[:, :3, 3], axis=1), [50, 95, 100]).round(4).tolist()}
    # (b) raw ARKit pose -> colmap via Umeyama on camera centres, scale=1 and free
    for name, sc_flag in (("umeyama_s1", False), ("umeyama_free", True)):
        c, R, t = umeyama(Tr[:, :3, 3], Tc[:, :3, 3], sc_flag)
        A = np.eye(4); A[:3, :3] = c * R; A[:3, 3] = t
        Tf = A @ Tr; Tf[:, :3, :3] /= c
        r[name] = {"scale": round(float(c), 5),
                   "rot_deg": np.percentile([rot_err(a[:3, :3], b[:3, :3]) for a, b in zip(Tf, Tc)], [50, 95, 100]).round(3).tolist(),
                   "trans_m": np.percentile(np.linalg.norm(Tf[:, :3, 3] - Tc[:, :3, 3], axis=1), [50, 95, 100]).round(4).tolist()}
        if not sc_flag:
            # is aligned_pose == A @ pose (one global rigid)?  compare
            r["aligned_is_global_rigid_of_pose"] = {"rot_deg_max": round(float(max(rot_err(a[:3, :3], b[:3, :3]) for a, b in zip(Tf, Ta))), 4),
                                                   "trans_m_max": round(float(np.linalg.norm(Tf[:, :3, 3] - Ta[:, :3, 3], axis=1).max()), 5)}
            # leave-half-out: fit on even registered frames, test on odd (generalisation to the holes)
            ev, od = slice(0, None, 2), slice(1, None, 2)
            c2, R2, t2 = umeyama(Tr[ev, :3, 3], Tc[ev, :3, 3], False); A2 = np.eye(4); A2[:3, :3] = R2; A2[:3, 3] = t2
            Tf2 = A2 @ Tr[od]
            r["umeyama_s1_holdout_odd"] = {"rot_deg": np.percentile([rot_err(a[:3, :3], b[:3, :3]) for a, b in zip(Tf2, Tc[od])], [50, 95, 100]).round(3).tolist(),
                                           "trans_m": np.percentile(np.linalg.norm(Tf2[:, :3, 3] - Tc[od, :3, 3], axis=1), [50, 95, 100]).round(4).tolist()}
    # (c) drift: worst residual as function of gap to nearest colmap frame is n/a here (all common); instead residual over time
    err_t = np.linalg.norm(Ta[:, :3, 3] - Tc[:, :3, 3], axis=1)
    r["aligned_trans_err_by_quarter"] = [round(float(v), 4) for v in np.array_split(err_t, 4).__iter__().__next__()[:0].tolist()] or [round(float(q.mean()), 4) for q in np.array_split(err_t, 4)]
    out[sc] = r
    print(sc, json.dumps(r))
json.dump(out, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q1_arkit_vs_colmap.json", "w"), indent=1)
