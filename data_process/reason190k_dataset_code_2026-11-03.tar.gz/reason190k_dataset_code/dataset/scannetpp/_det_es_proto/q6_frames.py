"""Q6: rgb.mkv vs VSI-590K / VSI-Bench mp4 frame identity + smart_resize sizes."""
import json, sys, numpy as np, cv2, decord
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/Qwen3-VL/qwen-vl-utils/src")
from qwen_vl_utils.vision_process import smart_resize
D = "/scratch/ducpham/Working/dataset/scannetpp/data"
MP4 = {"39f36da05b": "/scratch/ducpham/Working/dataset/vsi_590k/VSI-590K/scannetppv2/39f36da05b.mp4",
       "0d2ee665be": "/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/0d2ee665be.mp4",
       "286b55a2bf": "/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/286b55a2bf.mp4",
       "bcd2436daf": "/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/bcd2436daf.mp4"}
def corr(a, b):
    a = cv2.resize(a, (64, 48)).astype(float).ravel(); b = cv2.resize(b, (64, 48)).astype(float).ravel()
    return float(np.corrcoef(a, b)[0, 1])
out = {}
for sc, mp4 in MP4.items():
    vk = decord.VideoReader(f"{D}/{sc}/iphone/rgb.mkv", num_threads=2); vm = decord.VideoReader(mp4, num_threads=2)
    nk, nm = len(vk), len(vm); fk, fm = float(vk.get_avg_fps()), float(vm.get_avg_fps())
    probes = [0, 1, nm // 3, nm // 2, nm - 1]
    r = {"mkv_frames": nk, "mkv_fps": fk, "mkv_hw": list(vk[0].shape[:2]), "mp4_frames": nm, "mp4_fps": fm, "mp4_hw": list(vm[0].shape[:2]), "probes": []}
    for i in probes:
        m = vm[i].asnumpy(); same = corr(vk[i].asnumpy(), m)
        alt = {d: corr(vk[min(max(i + d, 0), nk - 1)].asnumpy(), m) for d in (-2, -1, 1, 2)}
        best = max(range(max(0, i - 30), min(nk, i + 31)), key=lambda j: corr(vk[j].asnumpy(), m)) if i in (nm // 2,) else None
        r["probes"].append({"i": i, "corr_same": round(same, 4), "corr_pm": {k: round(v, 3) for k, v in alt.items()}, "best_j_in_pm30": best})
    r["smart_resize_mp4"] = smart_resize(r["mp4_hw"][0], r["mp4_hw"][1], 64, 64 * 32 * 32, 128 * 32 * 32)
    r["smart_resize_mkv"] = smart_resize(r["mkv_hw"][0], r["mkv_hw"][1], 64, 64 * 32 * 32, 128 * 32 * 32)
    r["smart_resize_mp4_factor32"] = smart_resize(r["mp4_hw"][0], r["mp4_hw"][1], 32, 64 * 32 * 32, 128 * 32 * 32)
    out[sc] = r; print(sc, json.dumps(r), flush=True)
json.dump(out, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q6_frames.json", "w"), indent=1)
