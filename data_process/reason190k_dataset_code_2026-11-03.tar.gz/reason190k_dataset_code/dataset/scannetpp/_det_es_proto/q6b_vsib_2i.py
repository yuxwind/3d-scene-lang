import json, numpy as np, cv2, decord
D = "/scratch/ducpham/Working/dataset/scannetpp/data"
def corr(a, b):
    a = cv2.resize(a, (64, 48)).astype(float).ravel(); b = cv2.resize(b, (64, 48)).astype(float).ravel()
    return float(np.corrcoef(a, b)[0, 1])
out = {}
for sc in ["0d2ee665be", "286b55a2bf", "bcd2436daf", "5eb31827b7"]:
    vk = decord.VideoReader(f"{D}/{sc}/iphone/rgb.mkv", num_threads=2); vm = decord.VideoReader(f"/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/{sc}.mp4", num_threads=2)
    nm, nk = len(vm), len(vk); r = {"mkv": nk, "mp4": nm, "ratio": nk / nm, "probes": []}
    for i in [5, nm // 3, nm // 2, 2 * nm // 3, nm - 1]:
        m = vm[i].asnumpy()
        cand = {f"2i{d:+d}": corr(vk[min(nk - 1, max(0, 2 * i + d))].asnumpy(), m) for d in (-2, -1, 0, 1, 2)}
        r["probes"].append({"i": i, **{k: round(v, 3) for k, v in cand.items()}})
    out[sc] = r; print(sc, json.dumps(r), flush=True)
json.dump(out, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q6b_vsib_2i.json", "w"), indent=1)
