"""ARKit aligned_pose overlay at frames INSIDE the biggest COLMAP hole of 286b55a2bf (no COLMAP pose exists there)."""
import json, sys, numpy as np, cv2, decord
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/finetuning/viz_posed64f")
from prep_scene import read_colmap, MeshDepth
from labelmap import to_vocab
import open3d as o3d
D = "/scratch/ducpham/Working/dataset/scannetpp/data"; OUT = "/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto"
sc = sys.argv[1]
K, dist, colmap, W, H = read_colmap(f"{D}/{sc}/iphone/colmap"); reg = np.array(sorted(colmap)); g = np.diff(reg); h = int(np.argmax(g)); hole = (int(reg[h]), int(reg[h + 1]))
j = json.load(open(f"{D}/{sc}/iphone/pose_intrinsic_imu.json")); ark = {int(k.split("_")[1]): np.array(v["aligned_pose"], float) for k, v in j.items()}
V = np.asarray(o3d.io.read_triangle_mesh(f"{D}/{sc}/scans/mesh_aligned_0.05.ply").vertices); render = MeshDepth(f"{D}/{sc}/scans/mesh_aligned_0.05.ply", K, W, H, 480, 360)
rng = np.random.default_rng(0); inst = []
for x in json.load(open(f"{D}/{sc}/scans/segments_anno.json"))["segGroups"]:
    lab = to_vocab(x["label"]); 
    if lab is None: continue
    o = x["obb"]; seg = np.array(x["segments"]); inst.append((np.array(o["centroid"]), np.array(o["normalizedAxes"]).reshape(3, 3).T, np.array(o["axesLengths"]), lab, V[seg if len(seg) <= 300 else rng.choice(seg, 300, replace=False)]))
vk = decord.VideoReader(f"{D}/{sc}/iphone/rgb.mkv", num_threads=2)
E = [(0, 1), (0, 2), (1, 3), (2, 3), (4, 5), (4, 6), (5, 7), (6, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
S = np.array([[i, j_, k] for i in (-1, 1) for j_ in (-1, 1) for k in (-1, 1)])
for f in [hole[0] + (hole[1] - hole[0]) // 4, hole[0] + (hole[1] - hole[0]) // 2, hole[0] + 3 * (hole[1] - hole[0]) // 4]:
    T = ark[f]; w2c = np.linalg.inv(T); rv, _ = cv2.Rodrigues(w2c[:3, :3]); depth = render(T); im = vk[f].asnumpy().copy(); Kd = K * np.array([[0.25], [0.25], [1]]); n = 0
    for c, R, e, lab, P in inst:
        pc = (w2c[:3, :3] @ P.T + w2c[:3, 3:4]).T; z = pc[:, 2]; ok = z > 0.1; u = Kd[0, 0] * pc[:, 0] / np.where(ok, z, 1) + Kd[0, 2]; v = Kd[1, 1] * pc[:, 1] / np.where(ok, z, 1) + Kd[1, 2]
        inf = ok & (u >= 0) & (u < 480) & (v >= 0) & (v < 360)
        if inf.sum() < 30: continue
        d = depth[v[inf].astype(int), u[inf].astype(int)] / 1000.0
        if (((d == 0) | (z[inf] <= d + 0.1)).sum()) < 30: continue
        C = (R @ (S * e / 2).T).T + c; Cc = (w2c[:3, :3] @ C.T + w2c[:3, 3:4]).T
        if (Cc[:, 2] <= 0.05).any(): continue
        p, _ = cv2.projectPoints(C, rv, w2c[:3, 3], K, dist); p = p.reshape(-1, 2)
        for a, b in E: cv2.line(im, tuple(p[a].astype(int)), tuple(p[b].astype(int)), (0, 255, 0), 2)
        cv2.putText(im, lab, tuple(p[0].astype(int)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2); n += 1
    cv2.imwrite(f"{OUT}/overlay_{sc}_ARKIT_IN_HOLE_mkv{f}.jpg", cv2.cvtColor(cv2.resize(im, (960, 720)), cv2.COLOR_RGB2BGR)); print(sc, "hole", hole, "frame", f, "boxes drawn", n)
