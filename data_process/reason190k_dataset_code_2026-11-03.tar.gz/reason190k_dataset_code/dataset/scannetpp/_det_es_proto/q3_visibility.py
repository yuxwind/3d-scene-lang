"""Q3/Q5: GT-instance visibility over 64 frames (frustum / frustum+mesh-depth) for 3 frame-selection rules; OBB convention check; overlays."""
import json, os, sys, numpy as np, cv2, decord
from collections import Counter
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/finetuning/viz_posed64f")
from prep_scene import read_colmap, MeshDepth
from labelmap import to_vocab
import open3d as o3d
D = "/scratch/ducpham/Working/dataset/scannetpp/data"; OUT = "/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto"
VID = {"39f36da05b": ("/scratch/ducpham/Working/dataset/vsi_590k/VSI-590K/scannetppv2/39f36da05b.mp4", lambda i: i),          # train: mp4 i == mkv i
       "0d2ee665be": ("/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/0d2ee665be.mp4", lambda i: max(0, 2 * i - 3)),  # VSI-Bench: mp4 i == mkv 2i-3
       "286b55a2bf": ("/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/286b55a2bf.mp4", lambda i: max(0, 2 * i - 3)),
       "bcd2436daf": ("/scratch/ducpham/Working/dataset/vsib/vsibench/scannetpp/bcd2436daf.mp4", lambda i: max(0, 2 * i - 3))}
NPTS, DW, DH, DTOL = 300, 480, 360, 0.10
rng = np.random.default_rng(0)

def collator_idx(video):
    vr = decord.VideoReader(video, num_threads=1); n, fps = len(vr), float(vr.get_avg_fps())
    ns = int(np.clip(round(n / fps * 1.0), 1, 64)); return np.linspace(0, n - 1, ns).round().astype(int), n, fps

def m44(p): return np.vstack([np.array(p, float), [0, 0, 0, 1]]) if len(p) == 3 else np.array(p, float)

def visible_counts(pts_list, K, T_wc, depth):
    """per instance: (n_in_frustum, n_depth_ok)"""
    w2c = np.linalg.inv(T_wc); res = []
    Kd = K * np.array([[DW / 1920], [DH / 1440], [1]])
    for P in pts_list:
        c = (w2c[:3, :3] @ P.T + w2c[:3, 3:4]).T; z = c[:, 2]
        ok = z > 0.1; u = Kd[0, 0] * c[:, 0] / np.where(ok, z, 1) + Kd[0, 2]; v = Kd[1, 1] * c[:, 1] / np.where(ok, z, 1) + Kd[1, 2]
        inf = ok & (u >= 0) & (u < DW) & (v >= 0) & (v < DH)
        if not inf.any():
            res.append((0, 0)); continue
        d = depth[v[inf].astype(int), u[inf].astype(int)] / 1000.0
        dok = (d == 0) | (z[inf] <= d + DTOL)
        res.append((int(inf.sum()), int(dok.sum())))
    return res

def obb_edges(c, R, e):
    s = np.array([[i, j, k] for i in (-1, 1) for j in (-1, 1) for k in (-1, 1)]) * e / 2
    C = (R @ s.T).T + c
    E = [(0, 1), (0, 2), (1, 3), (2, 3), (4, 5), (4, 6), (5, 7), (6, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
    return C, E

def overlay(img, K, dist, T_wc, boxes, path):
    w2c = np.linalg.inv(T_wc); rvec, _ = cv2.Rodrigues(w2c[:3, :3]); im = img.copy()
    for c, R, e, lab in boxes:
        C, E = obb_edges(c, R, e); Cc = (w2c[:3, :3] @ C.T + w2c[:3, 3:4]).T
        if (Cc[:, 2] <= 0.05).any(): continue
        p, _ = cv2.projectPoints(C, rvec, w2c[:3, 3], K, dist); p = p.reshape(-1, 2)
        if ((p < -2000) | (p > 4000)).any(): continue
        for a, b in E: cv2.line(im, tuple(p[a].astype(int)), tuple(p[b].astype(int)), (0, 255, 0), 2)
        cv2.putText(im, lab, tuple(p[0].astype(int)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
    cv2.imwrite(path, cv2.cvtColor(cv2.resize(im, (960, 720)), cv2.COLOR_RGB2BGR))

res_all = {}
for sc, (video, to_mkv) in VID.items():
    K, dist, colmap, W, H = read_colmap(f"{D}/{sc}/iphone/colmap"); reg = np.array(sorted(colmap))
    mesh = o3d.io.read_triangle_mesh(f"{D}/{sc}/scans/mesh_aligned_0.05.ply"); V = np.asarray(mesh.vertices)
    render = MeshDepth(f"{D}/{sc}/scans/mesh_aligned_0.05.ply", K, W, H, DW, DH)
    groups = json.load(open(f"{D}/{sc}/scans/segments_anno.json"))["segGroups"]
    inst, conv = [], {"T": [], "noT": []}
    for g in groups:
        lab = to_vocab(g["label"])
        if lab is None: continue
        o = g["obb"]; c, e = np.array(o["centroid"]), np.array(o["axesLengths"])
        RT = np.array(o["normalizedAxes"]).reshape(3, 3).T; Rn = np.array(o["normalizedAxes"]).reshape(3, 3)
        seg = np.array(g["segments"]); P = V[seg if len(seg) <= NPTS else rng.choice(seg, NPTS, replace=False)]
        for k, R in (("T", RT), ("noT", Rn)):
            loc = (P - c) @ R; conv[k].append(float((np.abs(loc) <= e / 2 * 1.05 + 0.02).all(1).mean()))
        inst.append({"id": g["id"], "label": lab, "raw": g["label"], "c": c, "R": RT, "e": e, "P": P, "n_seg": len(seg)})
    pts_list = [x["P"] for x in inst]
    r = {"n_groups": len(groups), "n_mapped": len(inst), "n_reg": len(reg), "obb_inside_frac_mean": {k: round(float(np.mean(v)), 4) for k, v in conv.items()},
         "obb_inside_frac_p10": {k: round(float(np.percentile(v, 10)), 4) for k, v in conv.items()}}
    ark = None
    pj = f"{D}/{sc}/iphone/pose_intrinsic_imu.json"
    if os.path.exists(pj):
        j = json.load(open(pj)); ark = {int(k.split("_")[1]): m44(v["aligned_pose"]) for k, v in j.items()}
    vk = decord.VideoReader(f"{D}/{sc}/iphone/rgb.mkv", num_threads=2); n_mkv = len(vk)
    cidx, n_vid, fps = collator_idx(video); mk = np.array([min(n_mkv - 1, to_mkv(int(i))) for i in cidx])
    d = np.abs(reg[None, :] - mk[:, None]); snap = reg[d.argmin(1)]; gap = d.min(1)
    pool = reg[reg < n_mkv]; sel = pool[np.unique(np.linspace(0, len(pool) - 1, 64).round().astype(int))]
    r["video"] = {"n_frames": int(n_vid), "fps": fps, "n_sampled": len(cidx), "mkv_frames": n_mkv}
    r["collator_snap_gap_frames"] = {"p50": float(np.median(gap)), "p90": float(np.percentile(gap, 90)), "max": int(gap.max()), "n_gt15": int((gap > 15).sum()), "n_unique": int(len(np.unique(snap))), "gap0": int(gap[0])}
    sets = {"S1_posed_uniform": [(int(f), colmap[int(f)]) for f in sel],
            "S2_collator_snap": [(int(s_), colmap[int(s_)]) for s_ in snap]}
    if ark: sets["S3_collator_arkit"] = [(int(f), ark[int(f)]) for f in mk]
    r["sets"] = {}
    for name, frames in sets.items():
        per_frame = []; union = {"frustum10": set(), "frustum30": set(), "depth10": set(), "depth30": set(), "depth_frac10": set()}
        for f, T in frames:
            depth = render(T); vc = visible_counts(pts_list, K, T, depth)
            pf = Counter()
            for x, (nf, nd) in zip(inst, vc):
                n = len(x["P"])
                if nf >= 10: union["frustum10"].add(x["id"]); pf["frustum10"] += 1
                if nf >= 30: union["frustum30"].add(x["id"]); pf["frustum30"] += 1
                if nd >= 10: union["depth10"].add(x["id"]); pf["depth10"] += 1
                if nd >= 30: union["depth30"].add(x["id"]); pf["depth30"] += 1
                if nd >= max(5, 0.1 * n): union["depth_frac10"].add(x["id"]); pf["depth_frac10"] += 1
            per_frame.append(dict(pf))
        r["sets"][name] = {"n_frames": len(frames), "first_frame": frames[0][0], "all": len(inst),
                           "union": {k: len(v) for k, v in union.items()},
                           "per_frame_median": {k: float(np.median([p.get(k, 0) for p in per_frame])) for k in union},
                           "union_ids": {k: sorted(v) for k, v in union.items()}}
        print(sc, name, {k: v for k, v in r["sets"][name].items() if k != "union_ids"}, flush=True)
    # overlays: S1 frame 0 (COLMAP), S3 frame 0 and mid (ARKit aligned) with boxes visible in that frame (depth10)
    for name in sets:
        for k in (0, len(sets[name]) // 2):
            f, T = sets[name][k]; depth = render(T); vc = visible_counts(pts_list, K, T, depth)
            boxes = [(x["c"], x["R"], x["e"], x["label"]) for x, (nf, nd) in zip(inst, vc) if nd >= 30]
            overlay(vk[f].asnumpy(), K, dist, T, boxes, f"{OUT}/overlay_{sc}_{name}_k{k}_mkv{f}.jpg")
    del r["sets"]  # keep summary light; ids below
    r["sets"] = {n: {k: v for k, v in s.items() if k != "union_ids"} for n, s in r.items() if False} or {}
    res_all[sc] = r
    # re-store with ids for later
    res_all[sc] = r
json.dump(res_all, open(f"{OUT}/q3_visibility.json", "w"), indent=1)
