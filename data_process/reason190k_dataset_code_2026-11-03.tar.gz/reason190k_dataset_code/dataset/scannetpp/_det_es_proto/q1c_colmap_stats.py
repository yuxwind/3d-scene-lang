"""Q1/Q2: COLMAP registration coverage + mp4 header over the 856 train scenes; collator-rule snap gaps."""
import json, os, sys, numpy as np
import cv2, decord
from collections import Counter
D = "/scratch/ducpham/Working/dataset/scannetpp/data"
V = "/scratch/ducpham/Working/dataset/vsi_590k/VSI-590K/scannetppv2"
ids = sorted(f[:-4] for f in os.listdir(V) if f.endswith(".mp4"))
def reg_ids(sc):
    p = f"{D}/{sc}/iphone/colmap/images.txt"
    if not os.path.exists(p): return None
    return np.array(sorted(int(l.split()[9].split("_")[1].split(".")[0]) for l in open(p) if not l.startswith("#") and len(l.split()) == 10))
rows = {}
def one(sc):
    import cv2, decord
    vr = decord.VideoReader(f"{V}/{sc}.mp4", num_threads=1)
    n, fps = len(vr), float(vr.get_avg_fps()); hw = tuple(int(v) for v in vr[0].shape[:2])
    n_s = int(np.clip(round(n / fps * 1.0), 1, 64)); idx = np.linspace(0, n - 1, n_s).round().astype(int)   # collator rule
    reg = reg_ids(sc)
    r = {"mp4_frames": n, "fps": fps, "hw": hw, "n_sampled": n_s}
    if reg is not None and len(reg):
        d = np.abs(reg[None, :] - idx[:, None]); gap = d.min(1); snap = reg[d.argmin(1)]
        r.update(n_reg=int(len(reg)), first_reg=int(reg[0]), last_reg=int(reg[-1]), max_hole=int(np.diff(reg).max()) if len(reg) > 1 else 0,
                 reg_stride_mode=int(Counter(np.diff(reg).tolist()).most_common(1)[0][0]) if len(reg) > 1 else 0,
                 frame0_reg=bool(reg[0] == 0), gap0=int(gap[0]), gap_max=int(gap.max()), gap_med=float(np.median(gap)),
                 n_gap_gt15=int((gap > 15).sum()), n_gap_gt30=int((gap > 30).sum()), n_unique_snap=int(len(np.unique(snap))),
                 mkv_len_vs_lastreg=int(n - reg[-1]), n_posed_within_clip=int((reg < n).sum()))
    return sc, r
from multiprocessing import Pool
with Pool(12) as pool:
    for k, (sc, r) in enumerate(pool.imap_unordered(one, ids)):
        rows[sc] = r
        if k % 100 == 0: print(k, sc, r, flush=True)
json.dump(rows, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q1c_colmap_stats.json", "w"))
pct = lambda v: dict(zip(["min", "p5", "p25", "p50", "p75", "p95", "max"], np.percentile(v, [0, 5, 25, 50, 75, 95, 100]).round(2).tolist()))
R = [r for r in rows.values() if "n_reg" in r]
s = {"scenes": len(ids), "with_colmap": len(R), "fps": dict(Counter(r["fps"] for r in rows.values())), "hw": dict(Counter(str(r["hw"]) for r in rows.values())),
     "mp4_frames": pct([r["mp4_frames"] for r in rows.values()]), "n_sampled": pct([r["n_sampled"] for r in rows.values()]), "n_sampled_lt64": sum(r["n_sampled"] < 64 for r in rows.values()),
     "n_reg": pct([r["n_reg"] for r in R]), "n_reg_lt64": sum(r["n_reg"] < 64 for r in R), "n_reg_lt8": sum(r["n_reg"] < 8 for r in R),
     "frame0_reg": sum(r["frame0_reg"] for r in R), "first_reg": pct([r["first_reg"] for r in R]), "stride_mode": dict(Counter(r["reg_stride_mode"] for r in R)),
     "max_hole_frames": pct([r["max_hole"] for r in R]), "scenes_hole_gt60": sum(r["max_hole"] > 60 for r in R), "scenes_hole_gt600": sum(r["max_hole"] > 600 for r in R),
     "gap0_frames": pct([r["gap0"] for r in R]), "gap0_gt15": sum(r["gap0"] > 15 for r in R),
     "gap_max_frames": pct([r["gap_max"] for r in R]), "gap_med_frames": pct([r["gap_med"] for r in R]),
     "frames_gap_gt15_per_scene": pct([r["n_gap_gt15"] for r in R]), "scenes_any_gap_gt15": sum(r["n_gap_gt15"] > 0 for r in R), "scenes_any_gap_gt30": sum(r["n_gap_gt30"] > 0 for r in R),
     "n_unique_snap": pct([r["n_unique_snap"] for r in R]), "mp4len_minus_lastreg": pct([r["mkv_len_vs_lastreg"] for r in R]), "lastreg_beyond_mp4": sum(r["mkv_len_vs_lastreg"] <= 0 for r in R)}
json.dump(s, open("/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/q1c_colmap_summary.json", "w"), indent=1)
print(json.dumps(s, indent=1))
