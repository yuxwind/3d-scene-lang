#!/bin/bash
# 4 parallel official downloaders (colmap + mesh + anno for the det64f scenes), each retried until "Download successful!".
# Existing files are skipped by the downloader; stray partial .zip files of the shard's scenes are removed before a retry.
cd /scratch/ducpham/Working/dataset/scannetpp
PY=/scratch/ducpham/conda/envs/vsibench_eval_full/bin/python
run_shard() {
  k=$1; yml=data_download/download_det64f_$k.yml; log=data_download/det64f_download_$k.log
  for attempt in 1 2 3 4 5 6 7 8; do
    $PY -c "import yaml,sys,glob,os
for s in yaml.safe_load(open('$yml'))['download_scenes']:
    for z in glob.glob(f'data/{s}/**/*.zip', recursive=True): os.remove(z); print('removed', z)"
    echo "== shard $k attempt $attempt $(date)" >> $log
    echo y | $PY data_download/download_scannetpp.py $yml >> $log 2>&1
    grep -q "Download successful!" $log && { echo "shard $k done $(date)"; return 0; }
    sleep 30
  done
  echo "shard $k FAILED after 8 attempts"; return 1
}
for k in 0 1 2 3; do run_shard $k & done
wait
for k in 0 1 2 3; do sed 's/token=[A-Za-z0-9]*/token=X/g' data_download/det64f_download_$k.log | tr '\r' '\n' | grep -v "it/s\]" ; done > data_download/det64f_download.log
du -sh data >> data_download/det64f_download.log
echo ALL_DONE >> data_download/det64f_download.log
