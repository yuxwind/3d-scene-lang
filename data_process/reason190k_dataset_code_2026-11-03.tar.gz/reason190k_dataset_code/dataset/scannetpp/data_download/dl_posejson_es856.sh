#!/bin/bash
# iphone_pose_intrinsic_imu.json for all 856 nvs_sem_train scenes, 4 parallel official downloaders (existing files skipped).
# Token read from download_token.txt (first 64 chars) into the shard ymls only.
cd /scratch/ducpham/Working/dataset/scannetpp
PY=/scratch/ducpham/conda/envs/vsibench_eval_full/bin/python
TOKEN=$(head -c 64 download_token.txt)
$PY - <<PYEOF
import yaml
ids = open('splits/nvs_sem_train.txt').read().split()
cfg = yaml.safe_load(open('data_download/dl_posejson_es20.yml'))
cfg['token'] = '$TOKEN'
for k in range(4):
    cfg['download_scenes'] = ids[k::4]
    yaml.safe_dump(cfg, open(f'data_download/dl_posejson_es_{k}.yml', 'w'), sort_keys=False)
PYEOF
run_shard() {
  k=$1; yml=data_download/dl_posejson_es_$k.yml; log=data_download/dl_posejson_es_$k.log
  for attempt in 1 2 3 4 5 6 7 8; do
    $PY -c "import yaml,glob,os
for s in yaml.safe_load(open('$yml'))['download_scenes']:
    for z in glob.glob(f'data/{s}/iphone/*.zip'): os.remove(z); print('removed', z)"
    echo "== shard $k attempt $attempt $(date)" >> $log
    echo y | $PY data_download/download_scannetpp.py $yml >> $log 2>&1
    grep -q "Download successful!" $log && { echo "shard $k done $(date)"; return 0; }
    sleep 30
  done
  echo "shard $k FAILED after 8 attempts"; return 1
}
for k in 0 1 2 3; do run_shard $k & done
wait
n=0; for s in $(cat splits/nvs_sem_train.txt); do [ -f data/$s/iphone/pose_intrinsic_imu.json ] && n=$((n+1)); done
echo "pose json present: $n/856 $(date)"; echo ALL_DONE
