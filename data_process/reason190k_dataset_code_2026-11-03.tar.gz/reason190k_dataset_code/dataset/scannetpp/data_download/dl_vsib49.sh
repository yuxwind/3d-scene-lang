#!/bin/bash
# The 49 VSI-Bench-Debiased ScanNet++ val scenes: iphone pose json + colmap, mesh, segments + anno (no rgb.mkv / depth.bin),
# 4 parallel official downloaders, each retried until "Download successful!" (existing files skipped by the downloader).
# Token read from download_token.txt (first 64 chars) into the shard ymls only; logs are token-scrubbed into dl_vsib49.log.
cd /scratch/ducpham/Working/dataset/scannetpp
PY=/scratch/ducpham/conda/envs/vsibench_eval_full/bin/python
TOKEN=$(head -c 64 download_token.txt)
$PY - <<PYEOF
import yaml, pandas as pd
ids = sorted(set(pd.read_parquet('../vsib/VSI-Bench-extended/test_debiased_scannetpp.parquet').scene_name))
cfg = yaml.safe_load(open('data_download/download_det64f_0.yml'))
cfg['token'] = '$TOKEN'
cfg['download_assets'] = ['iphone_pose_intrinsic_imu_path', 'iphone_colmap_dir', 'scan_mesh_path', 'scan_mesh_segs_path', 'scan_anno_json_path']
for k in range(4):
    cfg['download_scenes'] = ids[k::4]
    yaml.safe_dump(cfg, open(f'data_download/dl_vsib49_{k}.yml', 'w'), sort_keys=False)
PYEOF
run_shard() {
  k=$1; yml=data_download/dl_vsib49_$k.yml; log=data_download/dl_vsib49_$k.raw.log
  for attempt in 1 2 3 4 5 6 7 8; do
    $PY -c "import yaml,glob,os
for s in yaml.safe_load(open('$yml'))['download_scenes']:
    for z in glob.glob(f'data/{s}/**/*.zip', recursive=True): os.remove(z); print('removed', z)"
    echo "== shard $k attempt $attempt $(date)" >> $log
    echo y | $PY data_download/download_scannetpp.py $yml >> $log 2>&1
    grep -q "Download successful!" $log && { echo "shard $k done $(date)"; return 0; }
    sleep 30
  done
  echo "shard $k FAILED after 8 attempts"; return 1
}
for k in 0 1 2 3; do run_shard $k & done
wait
for k in 0 1 2 3; do sed "s/token=[A-Za-z0-9]*/token=X/g; s/$TOKEN/X/g" data_download/dl_vsib49_$k.raw.log | tr '\r' '\n' | grep -v "it/s\]"; rm data_download/dl_vsib49_$k.raw.log; done > data_download/dl_vsib49.log
echo ALL_DONE >> data_download/dl_vsib49.log
