# ScanNet++ `det_es` options report (2026-09-13)

Goal: a ScanNet++ twin of `det_es` (64 posed frames/video + one scene-level `det.json`, GT 3D boxes in the camera-0 frame,
VG-LLM 9-DoF ZXY, 288-label EmbodiedScan vocabulary) for the 856 VSI-590K `scannetppv2` videos, with pixels from the iPhone
`rgb.mkv` stream (= the VSI-590K / VSI-Bench frames). Everything below is measured; prototypes and raw outputs live in
`/scratch/ducpham/Working/dataset/scannetpp/_det_es_proto/` (scripts `q*.py`, results `q*.json`, overlays `overlay_*.jpg`).
Reference builder: `/scratch/ducpham/Working/dataset/vgllm_data/det64f_posed_mp4/build_posed64f.py` (ScanNet/ARKit det_es).

## TL;DR

- **Use ARKit `aligned_pose`, not COLMAP, not Procrustes.** `iphone/pose_intrinsic_imu.json` has an `aligned_pose` 4x4 for
  **every** mkv frame that is already in the mesh/GT frame (median 0.2-0.45 deg / 0.7-1.4 cm from COLMAP on the frames COLMAP
  has, p95 0.7-3.4 deg / 3-5.5 cm, 7 scenes; a global Umeyama of the raw `pose` is 2-3x worse). No holes, frame 0 always posed.
  Cost 2.4 KB/frame -> 20.7 GB for all 856 (fast: 3 scenes in 2 s); keep only the 64 needed poses and delete the json.
- **Frames = collator rule** (`fps 1.0, cap 64, linspace` over the 60 fps mp4), exact same frames as the VQA rows, no snapping
  (option iii). Pixels from the VSI-590K mp4 (frame i == mkv frame i, corr 0.994-0.999); `rgb.mkv` not needed (saves ~250 GB).
- **Visibility = frustum + mesh-raycast depth test on the instance's own mesh vertices** (`segGroups[].segments`), union over
  the 64 frames. 96 % of mapped instances are seen in >= 1 of 64 frames (full 856 run), so the box count is set by
  the annotation density, not by visibility: **median ~65 mapped instances/scene** vs ScanNet det_es 26 / ARKit 17. A cap or
  a size/frame-count floor must be chosen (numbers in §4).
- Labels: `labelmap.py` maps 82.5 % of non-structure instances; `remove` (3,512 instances, an annotation artifact) must go to
  EXCLUDE; ~10 more synonyms recover most of the rest (§4).
- OBB convention verified: `normalizedAxes.reshape(3,3).T`, 100 % of instance vertices inside the box (67-86 % without `.T`);
  overlays look right. 9-DoF conversion = `to_camera` (`export_scannetpp_3dod.py`) == `build_posed64f.py` line for line.
- Split hygiene: 856 train == `nvs_sem_train`, 0 overlap with VSI-Bench (50) / ReVSI (48, subset of the 50); the 50 bench scenes
  are `nvs_sem_val` (GT + poses downloadable; VSI-Bench mp4 frame i == mkv frame 2i-3 at 30 fps).

## 1. Poses for the rgb.mkv frames

Local evidence: 856/856 train scenes have `iphone/colmap` (+ mesh + `segments_anno.json`); 7 scenes have
`pose_intrinsic_imu.json` (4 VSI-Bench val scenes 0d2ee665be / 286b55a2bf / 5eb31827b7 / bcd2436daf that were already on disk, and
39f36da05b / 00777c41d4 / 00a231a370 downloaded now, 14-24 MB each). Scripts `q1_arkit_vs_colmap.py`, `q1b_drift_reproj.py`,
`q1c_colmap_stats.py`.

### (a) COLMAP iPhone poses (`iphone/colmap/images.txt`)
Over the 856 train scenes (`q1c_colmap_summary.json`):
- stride 10 everywhere, n_registered min 104 / p50 771 / max 4705 (>= 64 in all scenes) -> **856/856 usable** with the
  det_es "posed-uniform" rule.
- **frame 0 registered in 742/856 (86.7 %)**; first registered frame p95 = 392, max = 6,610 frames (110 s!) -> with COLMAP the
  first selected frame is not the video's frame 0 in 114 scenes (111 have gap > 15 frames = the Boxer det64f drop).
- holes: max hole p50 170 frames (2.8 s), p95 1,412 (23.5 s), max 10,200; 694 scenes have a hole > 1 s, 129 a hole > 10 s.
- COLMAP is metric and in the `mesh_aligned` frame (= GT frame); intrinsics OPENCV 1920x1440 + 4 distortion coeffs.
- cost: 0 (already local, ~8 MB/scene).

### (b) ARKit `pose_intrinsic_imu.json`
Per frame: `pose` (raw ARKit cam2world), **`aligned_pose`** (4x4, cam2world, already transformed into the mesh/COLMAP frame),
`intrinsic` 3x3, `timestamp`, `imu`. One entry per mkv frame (n_json == mkv frames, first `frame_000000`), 2.39 KB/frame.
Measured against COLMAP on the registered frames (rotation geodesic deg / camera-centre m, p50 / p95 / max):

| scene | n common | `aligned_pose` vs COLMAP | Umeyama(scale=1) of raw `pose`, fit even / test odd frames | free scale |
|---|---|---|---|---|
| 0d2ee665be (val) | 418 | 0.39 / 3.43 / 6.7 deg; 1.4 / 5.5 / 25 cm | 1.00 / 3.81 / 6.3 deg; 7.0 / 20 / 25 cm | 0.940 |
| 286b55a2bf (val, 17 s hole) | 387 | 0.45 / 2.51 / 13.9; 0.8 / 5.0 / 34 cm | 1.44 / 3.14 / 15.1; 2.4 / 6.7 / 37 cm | 0.980 |
| 5eb31827b7 (val) | 643 | 0.19 / 1.20 / 8.8; 0.7 / 3.4 / 13 cm | 0.93 / 2.80 / 8.2; 2.6 / 5.7 / 14 cm | 0.992 |
| bcd2436daf (val) | 526 | 0.41 / 1.70 / 7.8; 0.9 / 4.4 / 26 cm | 1.53 / 3.04 / 7.4; 3.3 / 6.0 / 22 cm | 1.017 |
| 39f36da05b (train) | 947 | 0.25 / 0.95 / 4.7; 1.1 / 4.4 / 14 cm | 0.91 / 2.50 / 5.4; 3.3 / 9.3 / 16 cm | 0.989 |
| 00777c41d4 (train) | 919 | 0.18 / 0.72 / 7.9; 0.8 / 2.9 / 30 cm | 0.63 / 1.92 / 5.8; 4.3 / 10.8 / 34 cm | 0.991 |
| 00a231a370 (train) | 577 | 0.34 / 1.12 / 6.0; 1.3 / 5.1 / 19 cm | 0.97 / 2.89 / 3.7; 3.2 / 8.2 / 15 cm | 0.996 |

- `aligned_pose` is **not** one global rigid of `pose` (max diff 2.3-5 deg / 5-20 cm within a scene): ScanNet++ applied a
  drift-corrected alignment. It beats anything we could fit ourselves, so **no Procrustes/Umeyama step is needed**; a scale=1
  Umeyama would even be wrong for 0d2ee665be (ARKit scale 0.94).
- Inside COLMAP holes there is no reference, so `q1b` measures relative motion over gaps g between two registered frames
  (ARKit pair vs COLMAP pair): error is flat in g - rot p50 0.14-0.9 deg / p95 1.2-6 deg, trans p50 0.5-2.8 cm / p95 3-10 cm for
  g = 10 .. 1200 frames. `aligned_pose` does not drift across holes. Visual check: `overlay_286b55a2bf_ARKIT_IN_HOLE_mkv2447.jpg`
  (frame inside the 1,050-frame hole, boxes on the shower rod/hose line up).
- The max errors (4.7-13.9 deg) are 2-5 consecutive registered frames (e.g. 286b55a2bf 360-390, 5eb31827b7 7820-7850), i.e.
  local COLMAP or ARKit glitches; use a residual-vs-COLMAP flag per frame if needed (all reference frames available at no cost).
- Reprojection of mesh points at 1920 px (median px error per frame, p50 / p95 over frames): `aligned_pose` + COLMAP K+dist
  5-11 px / 38-51 px; `aligned_pose` + ARKit `intrinsic` 12-17 px / 57-1,789 px (ARKit K has no distortion and a few frames are
  way off) -> **use the COLMAP intrinsics + distortion with the ARKit poses.** (ARKit fx drifts 1427-1460 over a capture; COLMAP
  fx 1435-1445.)
- Usable: 856/856 (every mkv frame has a pose; frame 0 always). Cost: 20.7 GB json for 856 scenes (sum of 8.64 M frames x
  2.4 KB); download is fast (3 scenes / 2 s via the official downloader, `download_assets: [iphone_pose_intrinsic_imu_path]`).
  Extract the 64 poses per scene into `meta.json` and delete the json (or keep, 21 GB is inside the /scratch budget).

### (c) hybrid (COLMAP where registered, `aligned_pose` in holes)
Only buys the 0.3 deg / 1 cm median COLMAP-vs-aligned difference on the ~90 % of frames within 5 frames of a registered one, at
the price of a per-frame source switch and two intrinsic models. Not worth it; keep `aligned_pose` for all frames and record
`colmap_residual_deg/m` per frame in `meta.json` for auditing (cheap: COLMAP is local).

**Recommendation: (b).** 856/856 usable, frame 0 always posed, pixels stay the exact VQA frames.

## 2. Frame selection consistent with VSI-Bench / VSI-590K

Collator rule (`decode_video_frames`): `n = clip(round(len/avg_fps*1.0), 1, 64)`, `idx = linspace(0, len-1, n).round()`.
All 856 VSI-590K scannetppv2 mp4s are 640x480 **60 fps**, 1,787-50,261 frames (p50 8,752), so n = 64 for 839 and 30-63 for 17
short clips (< 64 s). VSI-Bench scannetpp mp4s are 640x480 **30 fps** (see §6).

| option | frames | pose source | measured |
|---|---|---|---|
| (i) posed-only uniform (det_es rule) | 64 uniform over registered COLMAP frames | COLMAP | 856/856 buildable, but frame00 != mp4 frame 0 in 114 scenes (first registered frame p95 392 frames / 6.5 s, max 110 s); frames differ from the VQA rows' cache |
| (ii) collator frames snapped to nearest COLMAP frame | collator idx -> nearest registered | COLMAP at the snapped frame, pixels at the collator frame | gap p50 = 3 frames (0.05 s; stride 10 at 60 fps -> max 5 frames = 0.083 s when registered); per-scene max gap p50 70 / p95 1,056 frames; **670/856 scenes have >= 1 frame with gap > 15 frames** (median 4 such frames/scene, p95 31, max 61); frame-0 gap > 15 in 111 scenes; unique snapped frames p5 47 |
| (iii) collator frames, per-frame `aligned_pose` | collator idx, exact | ARKit aligned | 856/856, 64 unique frames, gap 0, frame 0 posed; pose error vs COLMAP §1(b) |

**Recommendation: (iii).** Identical frames to the VQA rows (the frame-cache `win_` key / VGGT cache symlink plan in
`det64f-scene-rows.md` then applies unchanged), no snap tolerance logic, no drops. (i) is what det_es does for ScanNet/ARKit and
is a valid fallback if the ARKit json download is refused - it costs 114 scenes' frame-0 identity and 670 scenes' frame identity.

## 3. Visibility (ScanNet++ has no `visible_instance_ids`)

Prototype `q3_visibility.py` on 39f36da05b (train) + 0d2ee665be, 286b55a2bf, bcd2436daf (val): per instance, <= 300 random
vertices of its `segments` (mesh vertex ids of `mesh_aligned_0.05.ply`; max id + 1 == n_vertices), projected with COLMAP K
(no distortion, 480x360 grid) and tested against an open3d raycast depth of the mesh at 480x360 (`prep_scene.MeshDepth`),
tolerance 0.10 m. Rules: `frustum10/30` = >= 10 / 30 points in the image in front of the camera; `depth10/30` = additionally
pass the depth test. Union over the 64 frames of each frame set (S1 = posed uniform COLMAP, S2 = collator+snap COLMAP,
S3 = collator + aligned_pose):

| scene | mapped inst. | S1 frustum30 / depth30 | S2 | S3 | per-frame median visible (depth30) |
|---|---|---|---|---|---|
| 39f36da05b | 66 | 66 / 66 | 63 / 63 | 64 / 64 | 14 |
| 0d2ee665be | 86 | 86 / 86 | 86 / 86 | 86 / 86 | 14.5 |
| 286b55a2bf | 38 | 38 / 34 | 38 / 36 | 38 / 38 | 5 |
| bcd2436daf | 28 | 28 / 28 | 28 / 28 | 28 / 28 | 6 |

- "No visibility" (all mapped instances) and "visible in >= 1 of 64 frames" give the same rows in 3/4 scenes; 64 frames at
  1 fps cover the scan. The depth test removes 0-4 boxes/scene; the frustum-only test is nearly a no-op vs "all".
- So visibility is not the lever that brings boxes/video down; what matters is (a) EXCLUDE/label mapping and (b) an explicit
  floor (visible in >= k frames, min size) or cap. Full-856 numbers for these filters: §4.
- Cost: ~40 s/scene single-process (64 raycasts at 480x360 + mesh load), 856 scenes in ~50 min on 12 CPU workers.
- Frames/poses for the depth test in the recommended build = the collator frames with `aligned_pose` (S3), COLMAP K + dist.
  With `aligned_pose` the union is >= the COLMAP-based unions on all 4 scenes (no unposed frames).

## 4. Labels and boxes/video

`q4_labels.py` over the 856 train `segments_anno.json` (95,613 segGroups, 3,121 distinct raw labels):
- EXCLUDE (`labelmap.EXCLUDE` = wall/ceiling/floor/object/split/shower wall/shower floor/structure): 20,864 (21.8 %): object
  10,799, wall 6,754, ceiling 1,305, floor 967, split 612, structure 253, shower wall 138, shower floor 36.
- mapped to the 288 vocab: **61,688 = 64.5 % of all, 82.5 % of non-excluded** (38,193 exact matches, the rest via SYN /
  singular / last word); 244 of the 288 classes used.
- unmapped: 13,061 (1,427 labels). Top: **`remove` 3,512** (annotation artifact -> add to EXCLUDE), power sockets 430 (plural of a
  SYN key -> singularise before the SYN lookup), cable raceway 275, power strip 225, cloth 209, sofa 181 (-> couch), extension
  cord 154, power outlet 146 (-> socket), light switches 146 (-> switch), binder 144 (-> folder), painting 140 (-> picture),
  rug 131 (-> carpet), coax outlet 119, router 117, cable 115 (-> wire), phone charger 110, slippers 109 (-> shoe), trolley 94
  (-> cart), outlet 84 (-> socket), intercom 76, photograph 74 (-> picture), note 72 (-> paper), file binder 68, pc 66
  (-> computer), coat 64 (-> clothes), power outlets 62, lab equipment 61, thermos 60 (-> bottle), stovetop 47 (-> stove),
  dustbin 51 (-> bin). Applying these ~15 synonyms + `remove` -> EXCLUDE recovers ~2,300 instances (mapped ~86 % of
  non-excluded); the remaining tail is genuinely outside the vocabulary (cables, adapters, lab gear).
- **boxes/scene with all mapped instances (no visibility): min 6 / p5 22 / p25 41 / p50 65 / p75 88 / p95 154 / max 443**
  (0 scenes < 5, 3 scenes < 10) vs ScanNet det_es p50 26 (p95 61, max 130) and ARKit 17.

Full-856 visibility (`q4b_vis856.py`, S1 COLMAP posed-uniform frames, depth30 rule, `vis856/<scene>.json` keeps per-instance
visible-frame counts + OBB extents; summary `q4b_summary.json`):

| rule (union over 64 frames) | min / p5 / p25 / **p50** / p75 / p95 / max boxes per video | scenes > 64 boxes | scenes < 5 | total boxes |
|---|---|---|---|---|
| all mapped instances (no visibility) | 6 / 22 / 41 / **65** / 88 / 154 / 443 | 436 | 0 | 61,688 |
| frustum only (>= 30 pts in >= 1 frame) | 6 / 21 / 40 / **64** / 87 / 150 / 438 | 423 | 0 | 60,354 |
| frustum + depth, visible in >= 1 frame | 6 / 21 / 39 / **63** / 87 / 144 / 428 | 412 | 0 | 59,210 |
| visible in >= 2 frames | 6 / 20 / 38 / **61** / 84 / 137 / 383 | 397 | 0 | 57,146 |
| visible in >= 3 frames | 5 / 19 / 38 / **60** / 82 / 131 / 310 | 374 | 0 | 54,598 |
| visible >= 1 frame & max extent >= 0.1 m | 6 / 19 / 37 / **60** / 83 / 141 / 420 | 372 | 0 | 56,327 |
| visible >= 1 frame & max extent >= 0.2 m | 6 / 17 / 33 / **52** / 73 / 123 / 358 | 274 | 0 | 49,384 |
| visible >= 2 frames & max extent >= 0.2 m | 6 / 16 / 33 / **51** / 71 / 114 / 328 | 265 | 0 | 47,820 |

856/856 scenes ran (0 errors, 64 frames each); 96.0 % of all mapped instances are visible in >= 1 of the 64 frames; visible
frames per instance p5 1 / p50 9 / p95 21. Top visible labels: chair 3,713, box 3,118, lamp 2,139, book 1,979, table 1,968,
socket 1,959, cabinet 1,946, bottle 1,870, window 1,696, door 1,593, switch 1,347, doorframe 1,265. Even the strictest filter
above leaves a p50 of 51 (2x ScanNet det_es); reaching ~26-30 needs either a per-video cap (e.g. keep the N largest / most
visible, like `build_mix.py --max_boxes`) or a stricter size floor (0.3-0.4 m) - a training-side decision, recorded per instance
in `vis856/<scene>.json` (`n_visible_frames`, `e`) so any rule can be applied without re-running the raycast.

Note ScanNet++ boxes are denser because the annotation covers small objects (sockets, switches, pens, cups); a size floor is the
natural knob (EmbodiedScan also has those classes, but ScanNet scenes contain far fewer of them).

## 5. Coordinates / conventions

- GT frame = `mesh_aligned_0.05.ply` frame (z-up); COLMAP and `aligned_pose` are both in it (§1). `axis_align_matrix` = I.
- `segGroups[].obb`: `centroid`, `axesLengths`, `normalizedAxes` (9 floats). Correct parse: `R = reshape(3,3).T` (columns =
  box axes), as in `export_scannetpp_3dod.load_boxes` / `prep_scene.load_gt`. Verified on 4 scenes: with `.T` **100 %** of each
  instance's vertices lie inside its OBB (p10 = 100 %); without `.T` mean 67-86 %, p10 14-50 %. Projected overlays
  (`overlay_39f36da05b_S1_posed_uniform_k0_mkv0.jpg`, COLMAP pose + K + dist on mkv frame 0) fit chairs, bins, sockets.
- cam0 = `aligned_pose[idx[0]]` (idx[0] = mp4 frame 0 for every video), world2cam = inv(cam0); box -> camera via
  `o3d.OrientedBoundingBox(w2c @ c, w2c[:3,:3] @ R, extent)` -> `o3d_geo_to_9dof(..., "ZXY")`, i.e. `to_camera()` in
  `export_scannetpp_3dod.py` == the `build_posed64f.py` box loop (which builds the same geo from `embodiedscan_bbox_to_o3d_geo`).
  Only difference vs EmbodiedScan: ScanNet++ OBBs are full 3-DoF rotations (94 % have an axis within 5 deg of z), EmbodiedScan
  boxes are ZXY Euler in the axis-aligned frame; both go through the same 9-DoF conversion so no special casing.
- OpenCV camera (COLMAP `OPENCV`, x right / y down / z forward) for both COLMAP and `aligned_pose` (they agree to 0.3 deg).

## 6. Pixels / resize / storage

`q6_frames.py`, `q6c_vsib_fit.py`:
- VSI-590K scannetppv2 mp4 (train): 640x480, **60 fps**, frame count == mkv frame count (39f36da05b: 9,867 == 9,867),
  **mp4 frame i == mkv frame i** (corr 0.994-0.999 at mid-video probes vs 0.82-0.93 for i +- 1; ~0.98 at i = 0 where the camera
  is static). All 856 mp4s are 60 fps 640x480 (q1c).
- VSI-Bench scannetpp mp4 (val, `dataset/vsib/vsibench/scannetpp/<id>.mp4`): 640x480, **30 fps**, ~mkv/2 frames (2,700 vs
  5,396). **mp4 frame i == mkv frame 2i - 3** (fit over 5 probes x 3 scenes: slope 2.000, offset -3, corr 0.995-0.999 at the
  best match vs 0.66-0.99 at 2i). Frames 0/1 clamp to mkv 0.
- `smart_resize(480, 640, factor 64, 64..128 tokens)` -> **256x384** (same as ScanNet det_es); from the mkv 1440x1920 also
  256x384 (factor 32 would give 288x416). Using the mp4 pixels keeps the det frames byte-identical to the VQA frame cache.
- Storage: ScanNet det_es frames dirs average 1.93 MB/scene (64 JPEG q95 at 256x384) -> **856 scenes ~1.7 GB** (+ meta/det
  json ~50 KB/scene). rgb.mkv would be 200-380 MB/scene (~250 GB) and is **not needed**.
- Decode: 64 frames from a 60 fps 640x480 mp4 = 5.0 s (decord, 2 threads); from the 1920x1440 mkv 8.2 s.

## 7. Runtime / downloads for the full build

| item | per scene | 856 scenes |
|---|---|---|
| `iphone_pose_intrinsic_imu_path` download | 13-24 MB (2.4 KB/frame), ~1 s | 20.7 GB, ~15-30 min (official downloader, `head -c 64` token) |
| already local | colmap ~8 MB, mesh 14-48 MB, `segments_anno.json` 3-9 MB | done (det64f build) |
| mp4 decode + resize + JPEG | ~6 s | 1.5 CPU-h (16 workers -> 6 min) |
| visibility raycast (64 frames, 480x360) | ~40 s | ~10 CPU-h (12 workers -> 50 min, measured) |
| output | 1.9 MB frames + json | ~1.7 GB |

rgb.mkv: not needed (mp4 frame i == mkv frame i). depth.bin: not needed (mesh raycast). Optionally delete the pose json after
extracting the 64 poses (keeps 21 GB free).

## 8. Split hygiene / eval-side build

`q8_splits.json`: the 856 VSI-590K scannetppv2 ids == `nvs_sem_train` (856/856, 0 in val); overlap with VSI-Bench scannetppv2
(50) = **0**, with ReVSI ScanNetPPv2 (48, all inside the 50) = **0**. The 50 bench scenes are all `nvs_sem_val`, i.e. GT
(`segments_anno.json`, mesh) and iPhone poses (colmap + `pose_intrinsic_imu.json`) are downloadable (10 val scenes already have
mesh+anno locally, 4 have colmap + pose json + mkv). An eval-side det json for the 50 val scenes is therefore possible with the
same code; the only difference is the frame map (VSI-Bench mp4 30 fps, mp4 i -> mkv 2i-3, §6) and the collator run on the
30 fps mp4. Cost ~60 MB/scene (colmap + anno + mesh + pose json) = ~3 GB.

## Recommended option and build steps

**Option: collator frames + `aligned_pose` + COLMAP intrinsics + mesh-depth visibility, pixels from the VSI-590K mp4.**

1. Download `iphone_pose_intrinsic_imu_path` for the 856 ids (yml = `_det_es_proto/dl_posejson.yml` with the full list; token
   `head -c 64 download_token.txt`; `echo y |` for the size prompt) -> verify 856 files, `len(json) == mp4 frames` per scene.
2. Fix `labelmap.py`: `EXCLUDE |= {"remove"}`; singularise before the SYN lookup; add the synonyms listed in §4.
3. Build (script = `build_posed64f.py` with a `scannetpp` source, changes below), 16 workers, ~1 h.
4. Validate with `validate_posed64f.py` (--check_paths), plus: bench-id assert, `len(images) == n_sampled`, per-frame
   `colmap_residual` p95 < 5 deg, 9-DoF round trip, boxes histogram; eyeball 10 overlays (`export_scannetpp_3dod.draw_overlay`).
5. Decide the box floor/cap from the histogram (§4) before training; rsync `<scene>/det_es/` + `det_train.jsonl` to `$SCRATCH`.

Concrete changes vs `build_posed64f.py` (`source == "scannetpp"` branch of `build_one`):
- inputs: `PKL` -> none; per scene read `segments_anno.json` (`load_gt`-style parse with `.T`), `iphone/colmap/cameras.txt`
  (K, dist, 1920x1440 via `prep_scene.read_colmap`), `pose_intrinsic_imu.json` -> `aligned_pose` dict; `A = I`.
- frames: `idx = collator rule` on the mp4 (`len(vr)`, `get_avg_fps()` = 60), **not** `np.linspace` over a posed pool;
  `mp4_idx = idx`, `residual_s = 0`, `posed_id = f"frame_{idx:06d}"`, `cam2global = aligned_pose[idx]`,
  `cam2img = K_colmap * [640/1920, 480/1440, 1]` (store `dist` in meta; the collator does not undistort, the boxes are drawn
  on the raw frames, 5-11 px median reprojection at 1920).
- visibility: replace `visible_instance_ids` by the `q4b_vis856.py` test (instance `segments` vertices, <= 300, frustum +
  raycast depth at 480x360, tol 0.10 m, >= 30 points), union over the 64 frames, then the chosen floor/cap.
- labels: `labelmap.to_vocab` (fixed) instead of `CATS[...]`; drop `None`.
- boxes: `geo = o3d.OrientedBoundingBox(centroid, R, axesLengths)` in place of `embodiedscan_bbox_to_o3d_geo`, then the existing
  `g2c` loop and `o3d_geo_to_9dof(..., "ZXY")`; `bbox_3d` field = `[cx, cy, cz, dx, dy, dz] + R.flatten()` (world box for the
  round-trip check).
- pixels: `vr.get_batch(idx)` from the VSI-590K mp4, `smart_resize` (factor 64) -> 256x384, JPEG q95, `images` = JZ path
  `.../scannetppv2/<scene>/det_es/frames/frameNN.jpg`.
- meta extras: `pose_source: "arkit_aligned"`, per-frame `colmap_id` (nearest registered, gap) and `colmap_residual_deg/m`
  where available, `n_visible_frames` per instance, `label_raw`.
- drop the `MIN_POSED` / `offset` / `rot90` logic (ScanNet++ frames are upright, rot_k = 0).

Assumptions: the joint collator resizes ScanNet++ frames exactly as ScanNet (256x384, verified for the 640x480 input in §6);
the JZ VSI-590K mp4s are byte-identical to the local ones (same source, as for ScanNet); `aligned_pose` quality on the 849
unmeasured scenes matches the 7 measured (all 7 consistent; a per-scene `colmap_residual` p95 > 5 deg flag catches outliers).
