---
license: apache-2.0
language:
- en
pretty_name: VSI-590K
size_categories:
- 100K<n<1M
task_categories:
- visual-question-answering
- video-text-to-text
- image-to-text
---

# VSI-590K

**[Website](https://cambrian-mllm.github.io/cambrian-s/)** | **[Paper](https://arxiv.org/abs/2511.04670)** | **[GitHub](https://github.com/cambrian-mllm/cambrian-s)** | **[Models](https://huggingface.co/collections/nyu-visionx/cambrian-s-models)**

**Authors**: [Shusheng Yang*](https://github.com/vealocia), [Jihan Yang*](https://jihanyang.github.io/), [Pinzhi Huang†](https://pinzhihuang.github.io/), [Ellis Brown†](https://ellisbrown.github.io/), et al.

VSI-590K is a large-scale spatially-focused instruction-tuning dataset focusing on spatial reasoning. The dataset is curated from diverse sources and carefully annotated.

## Quick Start

```python
import json

# Load from JSONL file
with open('vsi_590k.jsonl', 'r') as f:
    for line in f:
        sample = json.loads(line.strip())
        print(sample)
        break
```

## Dataset Structure

Each line in `vsi_590k.jsonl` is a JSON object with this structure:

```python
{
    "conversations": [
        {"from": "human", "value": "<image>\nQuestion text..."},
        {"from": "gpt", "value": "Answer text"}
    ],
    "question_type": "relative_direction_object",  # e.g., "absolute_distance", "object_count"
    "image": "path/to/image.jpg",  # Optional: present if image sample
    "video": "path/to/video.mp4"   # Optional: present if video sample
}
```


## Usage Examples

```python
import json

def process_sample(sample):
    """Extract question and answer from conversation."""
    question = sample['conversations'][0]['value'].replace('<image>', '').strip()
    answer = sample['conversations'][1]['value']
    return {
        'question': question,
        'answer': answer,
        'question_type': sample['question_type'],
        'media_path': sample.get('image') or sample.get('video')
    }

# Process all samples
with open('vsi_590k.jsonl', 'r') as f:
    for line in f:
        sample = json.loads(line.strip())
        processed = process_sample(sample)
        # Use processed sample for training/inference
```

## Dataset Details

- **Total**: 590,667 QA pairs
- **Videos**: 5,963 unique videos
- **Images**: 44,858 unique images
- **Data Sources**: 10 diverse sources (annotated real videos, simulated data, unannotated real videos)

## Data Creation Pipeline
<img src="https://cdn-uploads.huggingface.co/production/uploads/65d14d80818f0593463fee32/IB2NVxw1vSYmNgqXb8toa.png" width="100%">

- **Annotated Real Videos**: As proposed in VSI-Bench, multimodal visual-spatial reasoning requires 3D geometric and spatial understanding. We re-purpose the training split of existing indoor scans and ego-vision datasets containing 3D instance-level annotations, including S3DIS, ScanNet, ScanNet++ V2, ARKitScenes, and Aria Digital Twin. For each dataset, the annotations are organized into meta-information files containing scene attributes (object counts, bounding boxes, room size, etc.), and question templates are automatically propagated to generate questions.

- **Simulated Data**: Given the scarce nature of 3D-annotated data, we leverage embodied simulators to programmatically generate spatially grounded video trajectories and QA pairs—rendering 625 video traversals through ProcTHOR scenes with diverse layouts, object placements, and appearances. We adapt the same methodology to Hypersim, sampling 5,113 images from 461 indoor scenes. Given instance-level bounding boxes, we construct supervision consistent with our annotated real-video setup.

- **Unannotated Real Videos**: Web-sourced videos provide rich diversity in room types, regions, and layouts. We web-crawled around 19K room tour videos from YouTube, and also sourced videos from the robotic learning datasets Open-X-Embodiment and AgiBot-World. Since these videos lack 3D annotations, we build a pseudo-annotation pipeline: we subsample and filter frames, applying powerful image detection, segmentation, and video reconstruction models to generate pseudo-annotated images. We generate pseudo-annotations on images instead of videos because pseudo-annotations from semantic extraction and reconstruction models on full videos are too noisy to serve as training data.

<div align="center" style="display: flex; justify-content: center; gap: 10px; width:100%">
  <img src="https://cdn-uploads.huggingface.co/production/uploads/65d14d80818f0593463fee32/3kAAxdXXu4u5gP4m6PNds.png" alt="vsi_piechart" width="45%">
  <img src="https://cdn-uploads.huggingface.co/production/uploads/65d14d80818f0593463fee32/cvd6kfR0Ouh9hWLz5ineg.png" width="45%">
</div>

## Citation

```bibtex
@article{yang2025cambrian,
  title={Cambrian-S: Towards Spatial Supersensing in Video},
  author={Yang, Shusheng and Yang, Jihan and Huang, Pinzhi and Brown, Ellis and Yang, Zihao and Yu, Yue and Tong, Shengbang and Zheng, Zihan and Xu, Yifan and Wang, Muhan and Lu, Danhao and Fergus, Rob and LeCun, Yann and Fei-Fei, Li and Xie, Saining},
  journal={arXiv preprint arXiv:2511.04670},
  year={2025}
}
```