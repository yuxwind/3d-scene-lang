"""ScanNet++ twin of det_es: 64 collator frames per VSI-590K scannetppv2 video + one scene-level VG-LLM det row.

Recipe (dataset/scannetpp/DET_ES_OPTIONS.md, recommended option):
  frames  = collator rule on the mp4 (n = round(frames/fps) capped 64, linspace) == the VQA rows' frames
  poses   = iphone/pose_intrinsic_imu.json `aligned_pose` per frame (already in the mesh/GT frame)
  K       = iphone/colmap/cameras.txt (OPENCV, 1920x1440 + 4 dist coeffs) scaled to the mp4 640x480
  GT      = scans/segments_anno.json OBBs (normalizedAxes.reshape(3,3).T), labels via labelmap.to_vocab, EXCLUDE + 'remove'
  visible = instance `segments` vertices (<=300) projected with the frame pose/K and depth-tested against an open3d
            raycast of mesh_aligned_0.05.ply at 480x360 (tol 0.1 m, >=30 points); instance kept if visible in >=1 frame
  boxes   = camera-0 (= frame00) 9-DoF ZXY via o3d_geo_to_9dof, same path as build_posed64f.py
  pixels  = mp4 frames, smart_resize (factor 64 -> 256x384), JPEG q95

Output: <VSI>/scannetppv2/<scene>/det_es/{frames/frameNN.jpg, meta.json, det.json}; aggregate det64f_posed_es/scannetpp/{det_train.jsonl, stats.json}
python build_posed64f_scannetpp.py --source scannetpp --scenes scannetpp_scenes20.txt [--workers 8] [--overlay 3]
--source scannetpp_vsib: same recipe for the VSI-Bench-Debiased val scenes (eval only, never a training mix): det_es next to
  dataset/vsib/vsibench/scannetpp/<scene>.mp4 (30 fps, mp4 frame i == mkv/pose frame 2i-3, DET_ES_OPTIONS.md §6), aggregate
  dataset/vsib_det64f/scannetpp/{det_eval.jsonl, stats.json}.
"""
import argparse, json, os, sys
from collections import Counter
from multiprocessing import get_context
from types import SimpleNamespace
import numpy as np
import cv2  # noqa: F401  (import before decord)
import decord
from PIL import Image
import open3d as o3d

W = "/scratch/ducpham/Working"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, f"{W}/spatial_reasoning/finetuning/legacy/idea_3i_130k_joint_cached_64f")   # graph_vgllm (moved to legacy/)
sys.path.insert(0, f"{os.path.dirname(HERE)}/det64f_posed_mp4")
sys.path.insert(0, f"{W}/spatial_reasoning/finetuning/viz_posed64f")
from build_posed64f import (VSI_LOCAL, VSI_JZ, BENCH_IDS, N_FRAMES, MIN_PIXELS, MAX_PIXELS, FACTOR,  # noqa: E402
                            smart_resize, create_question_answer, canonicalize, o3d_geo_to_9dof)
from prep_scene import read_colmap, MeshDepth, sample_indices  # noqa: E402
from labelmap import to_vocab, EXCLUDE, VOCAB  # noqa: E402

SPP = f"{W}/dataset/scannetpp/data"
SUB = "scannetppv2"                                   # VSI-590K folder name
JZ = "/lustre/fsn1/projects/rech/btf/uff48lg"
# per --source: mp4 dir (det_es is written next to the mp4), its Jean Zay twin, aggregate dir, mp4 idx -> pose json idx, bench?
SRC = {"scannetpp": dict(mp4=f"{VSI_LOCAL}/{SUB}", jz=f"{VSI_JZ}/{SUB}", agg=f"{HERE}/scannetpp", rows="det_train.jsonl",
                         viz=f"{HERE}/_viz", pose_idx=lambda i, n: i, bench=False),
       "scannetpp_vsib": dict(mp4=f"{W}/dataset/vsib/vsibench/scannetpp", jz=f"{JZ}/dataset/vsib/vsibench/scannetpp",
                              agg=f"{W}/dataset/vsib_det64f/scannetpp", rows="det_eval.jsonl", viz=f"{W}/dataset/vsib_det64f/_viz",
                              pose_idx=lambda i, n: min(max(2 * i - 3, 0), n - 1), bench=True)}
EXC = EXCLUDE | {"remove"}                            # 'remove' = annotation artifact (report §4)
# Extra synonyms from DET_ES_OPTIONS.md §4 (top unmapped labels), applied before labelmap.to_vocab; plurals of a SYN key too.
SYN = {"sofa": "couch", "power outlet": "socket", "outlet": "socket", "binder": "folder", "file binder": "folder",
       "painting": "picture", "photograph": "picture", "rug": "carpet", "cable": "wire", "slippers": "shoe", "trolley": "cart",
       "note": "paper", "pc": "computer", "coat": "clothes", "thermos": "bottle", "stovetop": "stove", "dustbin": "bin"}


def map_label(raw):
    """raw -> vocab label via SYN then to_vocab; 'power sockets' / 'light switches' style plurals retry singular."""
    lab = to_vocab(SYN.get(raw, raw))
    for sing in ([raw[:-1]] if raw.endswith("s") else []) + ([raw[:-2]] if raw.endswith("es") else []):
        lab = lab or to_vocab(SYN.get(sing, sing))
    return lab
NPTS, DW, DH, DTOL, MIN_VIS_PTS = 300, 480, 360, 0.10, 30


def visible_frames(P, poses, render, Kd):
    """Per instance: number of frames where >= MIN_VIS_PTS of its vertices are in the frustum and not occluded."""
    nvis = np.zeros(len(P), int)
    for T in poses:
        depth = render(T) / 1000.0; w2c = np.linalg.inv(T)
        for k, X in enumerate(P):
            c = X @ w2c[:3, :3].T + w2c[:3, 3]; z = c[:, 2]; ok = z > 0.1
            u = Kd[0, 0] * c[:, 0] / np.where(ok, z, 1) + Kd[0, 2]; v = Kd[1, 1] * c[:, 1] / np.where(ok, z, 1) + Kd[1, 2]
            inf = ok & (u >= 0) & (u < DW) & (v >= 0) & (v < DH)
            if inf.sum() < MIN_VIS_PTS:
                continue
            d = depth[v[inf].astype(int), u[inf].astype(int)]
            if ((d == 0) | (z[inf] <= d + DTOL)).sum() >= MIN_VIS_PTS:
                nvis[k] += 1
    return nvis


def build_one(job):
    source, sc = job; S = SRC[source]
    out = f"{S['mp4']}/{sc}/det_es"
    if os.path.exists(f"{out}/det.json"):
        return sc, "built", json.load(open(f"{out}/meta.json"))
    src = f"{SPP}/{sc}"
    vr = decord.VideoReader(f"{S['mp4']}/{sc}.mp4", num_threads=2)
    total, hfps = len(vr), float(vr.get_avg_fps())
    native_hw = tuple(int(v) for v in vr[0].shape[:2])
    idx = sample_indices(total, hfps)                                   # collator rule
    pj = json.load(open(f"{src}/iphone/pose_intrinsic_imu.json"))
    assert S["bench"] or len(pj) == total, (sc, len(pj), total)
    pidx = [S["pose_idx"](int(i), len(pj)) for i in idx]
    poses = []
    for i in pidx:
        T = np.array(pj[f"frame_{i:06d}"]["aligned_pose"], float)
        assert np.allclose(T[3], [0, 0, 0, 1], atol=1e-5), (sc, i); T[3] = [0, 0, 0, 1]
        poses.append(T)
    K, dist, _, cw, ch = read_colmap(f"{src}/iphone/colmap")
    Km = K * np.array([[native_hw[1] / cw], [native_hw[0] / ch], [1]])   # colmap 1920x1440 -> mp4 640x480
    cam0 = poses[0]

    # GT instances + visibility
    rng = np.random.default_rng(0)
    V = np.asarray(o3d.io.read_triangle_mesh(f"{src}/scans/mesh_aligned_0.05.ply").vertices)
    render = MeshDepth(f"{src}/scans/mesh_aligned_0.05.ply", K, cw, ch, DW, DH)
    inst, P = [], []
    for g in json.load(open(f"{src}/scans/segments_anno.json"))["segGroups"]:
        raw = g["label"].strip().lower(); lab = None if raw in EXC else map_label(raw)
        x = {"id": g["id"], "label_raw": g["label"], "label": lab, "status": "excluded" if raw in EXC else ("mapped" if lab else "unmapped"),
             "n_seg": len(g["segments"]), "center": g["obb"]["centroid"], "size": g["obb"]["axesLengths"],
             "rot": np.array(g["obb"]["normalizedAxes"], float).reshape(3, 3).T.tolist(), "n_visible_frames": 0,
             "via_syn": bool(lab) and to_vocab(raw) is None}
        inst.append(x)
        if lab:
            seg = np.array(g["segments"]); P.append(V[seg if len(seg) <= NPTS else rng.choice(seg, NPTS, replace=False)])
    mapped = [x for x in inst if x["status"] == "mapped"]
    for x, n in zip(mapped, visible_frames(P, poses, render, render.K)):
        x["n_visible_frames"] = int(n)
    keep = [x for x in mapped if x["n_visible_frames"] >= 1]
    g2c = np.linalg.inv(cam0); new = []
    for x in keep:                                                      # build_posed64f.py box loop, world OBB -> cam0 9-DoF
        c = g2c @ np.array([*x["center"], 1]).reshape(4, 1)
        geo_c = o3d.geometry.OrientedBoundingBox(c[:3].reshape(3), g2c[:3, :3] @ np.array(x["rot"]), np.array(x["size"], float))
        new.append(dict(instance_id=x["id"], label=x["label"], bbox_3d=[*map(float, x["center"]), *map(float, x["size"]), *np.ravel(x["rot"]).tolist()],
                        bbox_3d_in_cam=[float(v) for v in o3d_geo_to_9dof(geo_c, convention="ZXY")]))
    if not new:
        return sc, "zero_boxes", None

    os.makedirs(f"{out}/frames", exist_ok=True)
    h, w = smart_resize(native_hw[0], native_hw[1], FACTOR, MIN_PIXELS, MAX_PIXELS)
    for j, f in enumerate(vr.get_batch(idx).asnumpy()):
        Image.fromarray(f).resize((w, h)).save(f"{out}/frames/frame{j:02d}.jpg", "JPEG", quality=95)
    images = [f"{S['jz']}/{sc}/det_es/frames/frame{j:02d}.jpg" for j in range(len(idx))]
    q, a = create_question_answer(len(images), new, SimpleNamespace(reference_frame="first"))
    row = {"task": "det", "scene": sc, "video": f"{S['jz']}/{sc}.mp4", "n_frames": len(idx), "images": images,
           "graph": canonicalize(a), "conversations": [{"from": "human", "value": q}, {"from": "gpt", "value": a}],
           "boxes": [{"bbox_3d": x["bbox_3d_in_cam"], "label": x["label"]} for x in new]}
    frames_meta = [{"frame": j, "mp4_idx": int(i), "time_s": float(i / hfps), "posed_id": f"frame_{k:06d}", "residual_s": 0.0,
                    "cam2global": T.tolist(), "cam2img": Km.tolist(), "dist": dist.tolist()} for j, (i, k, T) in enumerate(zip(idx, pidx, poses))]
    meta = {"source": source, "scene": sc, "mp4": f"{S['jz']}/{sc}.mp4", "mp4_local": f"{S['mp4']}/{sc}.mp4",
            "mp4_header_fps": hfps, "fps": hfps, "mp4_num_frames": total, "native_hw": list(native_hw), "llm_hw": [h, w],
            "n_frames": len(idx), "frames": frames_meta, "cam0_cam2global": cam0.tolist(), "n_boxes": len(new),
            "instance_ids": [x["instance_id"] for x in new], "pixel_source": "mp4", "pose_source": "arkit_aligned",
            "colmap_hw": [ch, cw], "colmap_K": K.tolist(), "dist": dist.tolist(), "vis_hw": [DH, DW], "vis_tol_m": DTOL, "vis_min_pts": MIN_VIS_PTS,
            "n_inst": dict(Counter(x["status"] for x in inst)), "n_visible": len(keep),
            "instances": [{k: v for k, v in x.items() if k not in ("center", "size", "rot")} for x in inst]}
    json.dump(meta, open(f"{out}/meta.json", "w"))
    json.dump(row, open(f"{out}/det.json", "w"))
    return sc, "built", meta


def overlay(source, sc, path):
    """frame00 with the det.json cam0 boxes projected (K native -> llm_hw)."""
    from viz_det64f import draw, embodiedscan_bbox_to_o3d_geo
    d = f"{SRC[source]['mp4']}/{sc}/det_es"; meta, row = json.load(open(f"{d}/meta.json")), json.load(open(f"{d}/det.json"))
    (H, Wd), (h, w) = meta["native_hw"], meta["llm_hw"]; K = np.diag([w / Wd, h / H, 1]) @ np.array(meta["frames"][0]["cam2img"])
    boxes = [dict(label=b["label"], center=(g := embodiedscan_bbox_to_o3d_geo(b["bbox_3d"])).center, R=g.R, size=g.extent) for b in row["boxes"]]
    img = cv2.imread(f"{d}/frames/frame00.jpg"); img = cv2.resize(img, (w * 2, h * 2)); draw(img, boxes, np.eye(4), np.diag([2, 2, 1]) @ K, (0, 200, 0))
    cv2.imwrite(path, img)


def main():
    p = argparse.ArgumentParser(); p.add_argument("--source", default="scannetpp", choices=list(SRC))
    p.add_argument("--scenes", required=True, help="text file, one scene id per line"); p.add_argument("--workers", type=int, default=8)
    p.add_argument("--limit", type=int); p.add_argument("--overlay", type=int, default=3, help="write _viz/scannetpp_<id>.png for the first N scenes")
    a = p.parse_args(); S = SRC[a.source]
    ids = open(a.scenes).read().split()[:a.limit]
    b = json.load(open(BENCH_IDS)); bench = set(b["vsibench_videos"][SUB]) | set(b["revsi"]["ScanNetPPv2"])
    assert (set(ids) & bench) == (set(ids) if S["bench"] else set()), sorted(set(ids) ^ bench if S["bench"] else set(ids) & bench)
    drops, metas = Counter(), {}
    with get_context("spawn").Pool(a.workers) as pool:          # fork after `import open3d` deadlocks the raycast
        for n, (sc, status, meta) in enumerate(pool.imap_unordered(build_one, [(a.source, sc) for sc in ids], chunksize=1)):
            if status == "built":
                metas[sc] = meta
            else:
                drops[status] += 1
            print(n, sc, status, meta and f"{meta['n_boxes']} boxes", flush=True)
    rows = [json.load(open(f"{S['mp4']}/{sc}/det_es/det.json")) for sc in ids if sc in metas]
    agg = S["agg"]; os.makedirs(agg, exist_ok=True)
    with open(f"{agg}/{S['rows']}", "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    pct = lambda v: dict(zip(["min", "p5", "p25", "p50", "p75", "p95", "max"], np.percentile(v, [0, 5, 25, 50, 75, 95, 100]).round(3).tolist())) if len(v) else {}
    ms = [metas[sc] for sc in ids if sc in metas]
    n_inst = Counter(); unm = Counter(); n_syn = 0
    for m in ms:
        n_inst.update(m["n_inst"]); unm.update(x["label_raw"].strip().lower() for x in m["instances"] if x["status"] == "unmapped")
        n_syn += sum(x.get("via_syn", False) for x in m["instances"])
    stats = {"source": a.source, "pixel_source": "mp4", "pose_source": "arkit_aligned", "videos_total": len(ids), "built": len(rows), "dropped": dict(drops),
             "n_frames": N_FRAMES, "frames_per_video": pct([m["n_frames"] for m in ms]), "frames_hist": dict(sorted(Counter(m["n_frames"] for m in ms).items())),
             "boxes_per_video": pct([m["n_boxes"] for m in ms]), "boxes_hist": dict(sorted(Counter(m["n_boxes"] for m in ms).items())),
             "instances": dict(n_inst), "mapped_via_extra_syn": n_syn, "extra_syn": SYN, "visible": sum(m["n_visible"] for m in ms),
             "visible_fraction": sum(m["n_visible"] for m in ms) / max(1, n_inst["mapped"]),
             "visible_fraction_per_video": pct([m["n_visible"] / max(1, m["n_inst"].get("mapped", 0)) for m in ms]),
             "top_unmapped": unm.most_common(30), "vis_hw": [DH, DW], "vis_tol_m": DTOL, "vis_min_pts": MIN_VIS_PTS,
             "llm_hw": dict(Counter(str(m["llm_hw"]) for m in ms)), "native_hw": dict(Counter(str(m["native_hw"]) for m in ms)),
             "min_pixels": MIN_PIXELS, "max_pixels": MAX_PIXELS, "factor": FACTOR, "jpeg_quality": 95,
             "images_root": S["jz"], "categories": sorted(VOCAB), "bench_ids": sorted(bench)}
    json.dump(stats, open(f"{agg}/stats.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in stats.items() if k not in ("categories", "bench_ids", "boxes_hist")}, indent=1))
    os.makedirs(S["viz"], exist_ok=True)
    for sc in [sc for sc in ids if sc in metas][:a.overlay]:
        overlay(a.source, sc, f"{S['viz']}/scannetpp_{sc}.png")


if __name__ == "__main__":
    main()
