"""Fetch selected lowres_wide pngs from an Apple 3DOD Training zip with HTTP range reads (no full-zip download).
Central directory via plan_checks.arkit_zip_listing.RangeTail, then one range GET per member (local header + data).
fetch(scene, names, dst_dir) -> bytes downloaded. Skips pngs already in dst_dir."""
import io, os, struct, sys, time, urllib.request, zipfile, zlib
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/boxer/scannetpp_probe/plan_checks")
import arkit_zip_listing as azl
from arkit_zip_listing import URL, RangeTail


def get_range(url, lo, hi):
    for attempt in range(4):
        try:
            return urllib.request.urlopen(urllib.request.Request(url, headers={"Range": f"bytes={lo}-{hi}"}), timeout=60).read()
        except Exception as e:
            err = e; time.sleep(2 * (attempt + 1))
    raise err


def fetch(scene, names, dst_dir):
    todo = [n for n in names if not os.path.exists(f"{dst_dir}/{n}")]
    if not todo:
        return 0
    os.makedirs(dst_dir, exist_ok=True)
    url = URL.format(scene)
    for attempt in range(6):   # big zips have a central directory > 400 KB -> BadZipFile: grow the tail (also covers CDN hiccups)
        try:
            azl.TAIL = 400_000 * 2 ** attempt
            tail = RangeTail(url); zf = zipfile.ZipFile(io.BufferedReader(tail)); break
        except Exception as e:
            err = e; time.sleep(2)
    else:
        raise err
    infos = {zi.filename.split("/")[-1]: zi for zi in zf.infolist() if "/lowres_wide/" in zi.filename}
    nbytes = len(tail.data)
    for n in todo:
        zi = infos[n]
        # local header (30 B) + name + extra (bounded by 256 B) + compressed data, in one request
        blob = get_range(url, zi.header_offset, zi.header_offset + 30 + len(zi.filename) + 256 + zi.compress_size - 1)
        assert blob[:4] == b"PK\x03\x04", (scene, n)
        nlen, elen = struct.unpack("<HH", blob[26:30])
        raw = blob[30 + nlen + elen: 30 + nlen + elen + zi.compress_size]
        data = zlib.decompress(raw, -15) if zi.compress_type == zipfile.ZIP_DEFLATED else raw
        assert zi.compress_type in (0, 8) and zlib.crc32(data) & 0xFFFFFFFF == zi.CRC, (scene, n, zi.compress_type)
        tmp = f"{dst_dir}/.{n}.tmp"
        open(tmp, "wb").write(data); os.replace(tmp, f"{dst_dir}/{n}")
        nbytes += len(blob)
    return nbytes


if __name__ == "__main__":   # self-check: refetch 3 pngs of an extracted scene into /tmp and compare bytes
    import tempfile, filecmp
    sc = "42445697"; d = f"/scratch/ducpham/Working/dataset/embodiedscan_arkitscenes/arkitscenes/Training/{sc}/{sc}_frames/lowres_wide"
    names = sorted(os.listdir(d))[::len(os.listdir(d)) // 3][:3]
    with tempfile.TemporaryDirectory() as t:
        t0 = time.time(); nb = fetch(sc, names, t)
        print(names, "bytes", nb, "%.1fs" % (time.time() - t0), "identical:", [filecmp.cmp(f"{d}/{n}", f"{t}/{n}", shallow=False) for n in names])
