#!/bin/bash
# rsync <scene>/det_es/ dirs to the same paths on $SCRATCH, then the aggregate dir. Usage: sync_jz.sh scannet|arkitscenes
set -e
src=$1; V=/scratch/ducpham/Working/dataset/vsi_590k/VSI-590K; A=/scratch/ducpham/Working/dataset/vgllm_data/det64f_posed_es
JZ_V=/lustre/fsn1/projects/rech/btf/uff48lg/dataset/vsi_590k/VSI-590K; JZ_A=/lustre/fsn1/projects/rech/btf/uff48lg/dataset/vgllm_data/det64f_posed_es
cd $V && ls -d $src/*/det_es | sed 's#$#/#' > $A/$src/rsync_dirs.txt
rsync -ar --relative --stats --files-from=$A/$src/rsync_dirs.txt $V/ jeanzay:$JZ_V/ > $A/$src/rsync.log 2>&1
rsync -a --exclude 'slurm-*.out' --exclude '_viz' $A/ jeanzay:$JZ_A/ >> $A/$src/rsync.log 2>&1
tail -n 20 $A/$src/rsync.log | grep -E "Number of regular files transferred|Total transferred file size|total size"
