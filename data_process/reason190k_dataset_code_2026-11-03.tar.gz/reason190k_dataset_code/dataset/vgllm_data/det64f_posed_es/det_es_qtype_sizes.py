"""Question-type sizes of the det_es-covered part of the 180k VQA mix (~178.9k rows).

  python det_es_qtype_sizes.py [--root .../VSI-590K] [--mix .../vqa_train.jsonl]

Rows whose video has no det_es scene are skipped (same rule as det_es_coverage.py).
"""
import argparse
import json
from collections import Counter
from pathlib import Path

from det_es_coverage import SOURCES, W, exported_scenes


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, default=W / "dataset/vsi_590k/VSI-590K")
    p.add_argument("--mix", type=Path, default=W / "dataset/vgllm_data/joint180k_vlm3r/vqa_train.jsonl")
    args = p.parse_args()

    scenes = exported_scenes(args.root)
    total = Counter(); by_src = Counter(); by_origin = Counter()
    for line in open(args.mix):
        r = json.loads(line)
        v = Path(r["video"])
        if v.stem not in scenes.get(v.parent.name, {}):
            continue
        t = r.get("question_type", "?")
        total[t] += 1; by_src[t, v.parent.name] += 1; by_origin[t, r.get("source", "?")] += 1

    n = sum(total.values())
    origins = sorted({o for _, o in by_origin})
    head = f"{'question_type':28s} {'rows':>7s} {'%':>6s} " + " ".join(f"{s:>12s}" for s in SOURCES) \
        + " " + " ".join(f"{o:>9s}" for o in origins)
    print(f"det_es-covered rows: {n:,}\n\n{head}\n{'-' * len(head)}")
    for t in sorted(total, key=total.get, reverse=True):
        print(f"{t:28s} {total[t]:7,d} {100 * total[t] / n:5.1f}% "
              + " ".join(f"{by_src[t, s]:12,d}" for s in SOURCES) + " "
              + " ".join(f"{by_origin[t, o]:9,d}" for o in origins))
    print(f"{'total':28s} {n:7,d} {100.0:5.1f}% "
          + " ".join(f"{sum(by_src[t, s] for t in total):12,d}" for s in SOURCES) + " "
          + " ".join(f"{sum(by_origin[t, o] for t in total):9,d}" for o in origins))


if __name__ == "__main__":
    main()
