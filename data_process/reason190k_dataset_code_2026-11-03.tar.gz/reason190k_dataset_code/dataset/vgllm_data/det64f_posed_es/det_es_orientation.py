"""Which det_es scenes are upside down or sideways (from the frame poses), and how many VQA rows they carry.

  python det_es_orientation.py [--root .../VSI-590K] [--mix .../vqa_train.jsonl] [--arkit_per_rot 12] [--workers 16]

Pose rule, per frame (meta.json cam2global, OpenCV camera: x right, y down, z forward; world z up):
  u = world +z in camera coords = row 2 of the rotation. roll = atan2(u_x, -u_y) in degrees, 0 = world up is image up,
  +90 = world up points to the image's right edge.
  |roll| < 45 upright, 45..135 sideways (right if roll > 0, else left), > 135 upside down.
  |forward . z| > 0.9 or a non-finite pose -> undetermined, left out of the vote.
Scene rule: flagged when sideways + upside down > half of the determined frames; label = the most common off class.
mp4 check: for flagged scenes and some unflagged ARKit scenes (per rot90_k, plus every frame00_corr_mp4 < 0.8), decode the
  meta mp4_idx frames from the raw mp4 and pick the np.rot90 k (CCW) of the det_es frame that best correlates with it.
VQA rows: rows of --mix whose video scene has a det_es export (same rule as det_es_coverage.py).
Writes det_es_orientation.csv next to this file.
"""
import argparse
import csv
import json
import random
from collections import Counter, defaultdict
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import cv2  # noqa: F401  (import before decord)
import decord

from det_es_coverage import SOURCES, W, exported_scenes

HERE = Path(__file__).resolve().parent
ROOT = W / "dataset/vsi_590k/VSI-590K"
CLASSES = ("upright", "sideways_left", "sideways_right", "upside_down", "undetermined")
N_CHECK = 8                                   # frames per scene for the mp4 comparison


def classify(T):
    T = np.asarray(T, float)
    if not np.isfinite(T).all() or abs(T[2, 2]) > 0.9:
        return "undetermined", None
    roll = np.degrees(np.arctan2(T[2, 0], -T[2, 1]))
    if abs(roll) < 45:
        return "upright", roll
    if abs(roll) > 135:
        return "upside_down", roll
    return ("sideways_right" if roll > 0 else "sideways_left"), roll


def scene_poses(job):
    src, sc = job
    meta = json.load(open(ROOT / src / sc / "det_es/meta.json"))
    n, stats = Counter(), []
    for f in meta["frames"]:
        T = np.asarray(f["cam2global"], float)
        c, _ = classify(T)
        n[c] += 1
        if np.isfinite(T).all():               # world up . image up, |forward . z|, rotation orthonormality error
            stats.append((-T[2, 1], abs(T[2, 2]), np.abs(T[:3, :3].T @ T[:3, :3] - np.eye(3)).max()))
    return src, sc, meta["n_frames"], n, stats, meta.get("rot90_k"), meta.get("frame00_corr_mp4")


def norm(a):
    a = cv2.resize(cv2.cvtColor(a, cv2.COLOR_RGB2GRAY), (64, 64)).astype(float).ravel()
    return (a - a.mean()) / (a.std() + 1e-6)


def mp4_rotation(job):
    src, sc = job
    d = ROOT / src / sc / "det_es"
    fr = json.load(open(d / "meta.json"))["frames"]
    pick = sorted(set(np.linspace(0, len(fr) - 1, N_CHECK).round().astype(int)))
    vr = decord.VideoReader(str(ROOT / src / f"{sc}.mp4"), num_threads=1)
    mp4 = vr.get_batch([min(fr[j]["mp4_idx"], len(vr) - 1) for j in pick]).asnumpy()
    es = [cv2.cvtColor(cv2.imread(str(d / f"frames/frame{j:02d}.jpg")), cv2.COLOR_BGR2RGB) for j in pick]
    corr = [np.mean([norm(np.ascontiguousarray(np.rot90(e, k))) @ norm(m) / 4096 for e, m in zip(es, mp4)]) for k in range(4)]
    k = int(np.argmax(corr))
    return src, sc, 90 * k, corr[k], sorted(corr)[-2]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, default=ROOT)
    p.add_argument("--mix", type=Path, default=W / "dataset/vgllm_data/joint180k_vlm3r/vqa_train.jsonl")
    p.add_argument("--arkit_per_rot", type=int, default=12, help="unflagged ARKit scenes per rot90_k for the mp4 check")
    p.add_argument("--workers", type=int, default=16)
    args = p.parse_args()
    assert args.root == ROOT, "workers read ROOT"

    scenes = exported_scenes(args.root)
    jobs = [(src, sc) for src in SOURCES for sc in scenes[src]]
    with Pool(args.workers) as pool:
        res = pool.map(scene_poses, jobs, chunksize=8)

    # VQA rows per exported scene
    vqa = Counter(); origin = Counter(); by_type = Counter(); total = Counter()
    for line in open(args.mix):
        r = json.loads(line)
        v = Path(r["video"]); key = (v.parent.name, v.stem)
        if v.stem in scenes.get(v.parent.name, {}):
            vqa[key] += 1; origin[key, r.get("source", "?")] += 1; by_type[key, r.get("question_type", "?")] += 1
            total[r.get("question_type", "?")] += 1
    n_es = sum(vqa.values())

    rows, flagged, border = {}, [], []
    print("== pose sanity per source (determined + undetermined frames with finite poses)")
    for src in SOURCES:
        st = np.array([s for r in res if r[0] == src for s in r[4]])
        nf = sum(r[2] for r in res if r[0] == src); nfin = len(st)
        cls = sum((r[3] for r in res if r[0] == src), Counter())
        print(f"  {src:12s} frames {nf:,} (non-finite {nf - nfin}), up.z median {np.median(st[:, 0]):.3f} "
              f"p5 {np.percentile(st[:, 0], 5):.3f}, |fwd.z| median {np.median(st[:, 1]):.3f} p95 {np.percentile(st[:, 1], 95):.3f}, "
              f"max orthonormality err {st[:, 2].max():.1e}")
        print("    frames: " + ", ".join(f"{c} {cls[c]:,}" for c in CLASSES))
    for src, sc, nfr, n, _, rot_k, c0 in res:
        off = n["sideways_left"] + n["sideways_right"] + n["upside_down"]
        det = nfr - n["undetermined"]
        label = "undetermined" if det == 0 else "upright"
        if det and off > det / 2:
            label = max(("upside_down", "sideways_left", "sideways_right"), key=lambda c: n[c])
            flagged.append((src, sc))
        elif off >= 8:
            border.append((src, sc))
        rows[src, sc] = dict(source=src, scene=sc, n_frames=nfr, upright=n["upright"], sideways=n["sideways_left"] + n["sideways_right"],
                             upside_down=n["upside_down"], undetermined=n["undetermined"], scene_label=label,
                             mp4_rotation_vs_det_es="", vqa_rows=vqa[src, sc], _n=n, _rot_k=rot_k, _c0=c0)

    # mp4 check: flagged + per-rot90_k sample of unflagged ARKit + ARKit with a low builder frame00 correlation
    rnd = random.Random(0); ark = defaultdict(list)
    for (src, sc), r in rows.items():
        if src == "arkitscenes" and (src, sc) not in flagged:
            ark[r["_rot_k"]].append(sc)
    sample = [("arkitscenes", sc) for k in sorted(ark) for sc in rnd.sample(ark[k], min(args.arkit_per_rot, len(ark[k])))]
    lowc = [(s, sc) for (s, sc), r in rows.items() if s == "arkitscenes" and (s, sc) not in flagged and r["_c0"] is not None and r["_c0"] < 0.8]
    checks = list(dict.fromkeys(flagged + sample + lowc))
    with Pool(args.workers) as pool:
        rot = {(s, sc): (deg, c, c2) for s, sc, deg, c, c2 in pool.map(mp4_rotation, checks, chunksize=1)}
    for key, (deg, _, _) in rot.items():
        rows[key]["mp4_rotation_vs_det_es"] = deg

    def line(key):
        r = rows[key]; n = r["_n"]; m = rot.get(key)
        return (f"    {r['scene']:14s} {r['scene_label']:15s} n {r['n_frames']:2d}: up {n['upright']:2d} left {n['sideways_left']:2d} "
                f"right {n['sideways_right']:2d} upside {n['upside_down']:2d} undet {n['undetermined']:2d}"
                + (f"  rot90_k {r['_rot_k']}" if r["_rot_k"] is not None else "")
                + (f"  mp4 vs det_es {m[0]:3d} deg (corr {m[1]:.2f}, next {m[2]:.2f})" if m else "") + f"  vqa {r['vqa_rows']:,}")

    print("\n== flagged scenes (off > half of determined frames)")
    for src in SOURCES:
        f = [k for k in flagged if k[0] == src]
        print(f"  {src}: {len(f)} / {len(scenes[src])} scenes, labels {dict(Counter(rows[k]['scene_label'] for k in f))}")
        for k in f:
            print(line(k))
    print("\n== borderline (not flagged, >= 8 off frames)")
    for src in SOURCES:
        b = [k for k in border if k[0] == src]
        print(f"  {src}: {len(b)}")
        for k in b:
            print(line(k))

    print("\n== ARKit mp4 sample (unflagged; per rot90_k and frame00_corr_mp4 < 0.8)")
    for name, ks in (("per-rot90_k sample", sample), ("frame00_corr_mp4 < 0.8", lowc)):
        by = Counter((rows[k]["_rot_k"], rot[k][0]) for k in ks)
        print(f"  {name}: {len(ks)} scenes, (rot90_k, mp4 deg) counts {dict(sorted(by.items()))}")
        for k in ks:
            if rot[k][0] != 0 or rot[k][1] - rot[k][2] < 0.1:
                print(f"    {k[1]} rot90_k {rows[k]['_rot_k']} mp4 vs det_es {rot[k][0]} deg corr {rot[k][1]:.2f} next {rot[k][2]:.2f}")

    print(f"\n== VQA rows in flagged scenes ({args.mix.name} filtered to det_es scenes: {n_es:,} rows)")
    fl = sum(vqa[k] for k in flagged)
    print(f"  total {fl:,} ({100 * fl / n_es:.2f}% of the es mix)")
    for src in SOURCES:
        a = sum(vqa[k] for k in flagged if k[0] == src); b = sum(v for k, v in vqa.items() if k[0] == src)
        print(f"  {src:12s} {a:6,d} ({100 * a / n_es:.2f}% of mix, {100 * a / max(b, 1):.2f}% of its {b:,} rows)")
    fo = Counter(); ft = Counter()
    for (key, o), v in origin.items():
        fo[o] += v if key in flagged else 0
    for (key, t), v in by_type.items():
        ft[t] += v if key in flagged else 0
    print("  by mix source: " + ", ".join(f"{o} {fo[o]:,}" for o in sorted(fo)))
    print("  by question type (flagged / all es rows of the type):")
    for t in sorted(total, key=lambda t: -ft[t]):
        print(f"    {t:32s} {ft[t]:6,d} / {total[t]:6,d} ({100 * ft[t] / total[t]:.2f}%)")

    out = HERE / "det_es_orientation.csv"
    cols = ["source", "scene", "n_frames", "upright", "sideways", "upside_down", "undetermined", "scene_label", "mp4_rotation_vs_det_es", "vqa_rows"]
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, cols, extrasaction="ignore"); w.writeheader(); w.writerows(rows.values())
    print(f"\nwrote {out} ({len(rows)} scenes)")


if __name__ == "__main__":
    main()
