"""One-off: <scene>/{frames,meta.json,det.json} -> <scene>/det_mp4/..., rewrite images paths in det.json + det_train.jsonl,
rename aggregate dir det64f_posed -> det64f_posed_mp4. Idempotent, nothing deleted.
python move_to_det_mp4.py <VSI-590K root> <vgllm_data dir>"""
import json, os, sys
vsi, agg = sys.argv[1:3]
for src in ("scannet", "arkitscenes"):
    n_mv = n_rw = 0
    for sc in sorted(os.listdir(f"{vsi}/{src}")):
        d = f"{vsi}/{src}/{sc}"
        if not os.path.isdir(d):
            continue
        if os.path.exists(f"{d}/det.json"):
            os.makedirs(f"{d}/det_mp4", exist_ok=True)
            for f in ("frames", "meta.json", "det.json"):
                os.rename(f"{d}/{f}", f"{d}/det_mp4/{f}")
            n_mv += 1
        dj = f"{d}/det_mp4/det.json"
        if os.path.exists(dj):
            r = json.load(open(dj))
            if any(f"/{sc}/frames/" in x for x in r["images"]):
                r["images"] = [x.replace(f"/{sc}/frames/", f"/{sc}/det_mp4/frames/") for x in r["images"]]
                json.dump(r, open(dj, "w")); n_rw += 1
    print(src, "moved", n_mv, "det.json rewritten", n_rw, flush=True)
old, new = f"{agg}/det64f_posed", f"{agg}/det64f_posed_mp4"
if os.path.isdir(old) and not os.path.exists(new):
    os.rename(old, new)
for src in ("scannet", "arkitscenes"):
    p = f"{new}/{src}/det_train.jsonl"; rows = [json.loads(l) for l in open(p)]; n = 0
    for r in rows:
        sc = r["scene"]
        if any(f"/{sc}/frames/" in x for x in r["images"]):
            r["images"] = [x.replace(f"/{sc}/frames/", f"/{sc}/det_mp4/frames/") for x in r["images"]]; n += 1
    if n:
        with open(p, "w") as f:
            for r in rows:
                f.write(json.dumps(r) + "\n")
    print(src, "jsonl rows", len(rows), "rewritten", n, "sample", rows[0]["images"][0], flush=True)
