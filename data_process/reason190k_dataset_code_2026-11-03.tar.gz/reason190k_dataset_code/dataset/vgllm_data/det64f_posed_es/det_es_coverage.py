"""How many det_es scenes exist, and how much of the 180k VQA mix they cover.

  python det_es_coverage.py [--root .../VSI-590K] [--mix .../joint180k_vlm3r/vqa_train.jsonl]

A scene counts as exported when <root>/<source>/<scene>/det_es/ has det.json, meta.json and
at least one frame. A mix row is covered when its video's scene is exported.
"""
import argparse
import json
from collections import Counter
from pathlib import Path

W = Path("/scratch/ducpham/Working")
SOURCES = ("scannet", "arkitscenes", "scannetppv2")


def exported_scenes(root: Path):
    """source -> {scene: n_frames} for complete det_es dirs."""
    out = {}
    for src in SOURCES:
        out[src] = {}
        for d in sorted((root / src).glob("*/det_es")):
            n = len(list((d / "frames").glob("frame*.jpg")))
            if n and (d / "det.json").is_file() and (d / "meta.json").is_file():
                out[src][d.parent.name] = n
    return out


def pct(a, b):
    return f"{a:,}/{b:,} ({100 * a / b:.1f}%)" if b else "0/0"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, default=W / "dataset/vsi_590k/VSI-590K")
    p.add_argument("--mix", type=Path, default=W / "dataset/vgllm_data/joint180k_vlm3r/vqa_train.jsonl")
    args = p.parse_args()

    scenes = exported_scenes(args.root)
    print("== exported det_es scenes")
    for src in SOURCES:
        n = Counter(scenes[src].values())
        print(f"  {src:12s} {len(scenes[src]):5d} scenes, {n.get(64, 0)} with 64 frames, "
              f"{len(scenes[src]) - n.get(64, 0)} with fewer")
    print(f"  {'total':12s} {sum(len(v) for v in scenes.values()):5d}")

    rows = Counter(); cov = Counter(); vids = {s: set() for s in SOURCES}
    by_type = Counter(); by_type_cov = Counter(); by_origin = Counter(); by_origin_cov = Counter()
    for line in open(args.mix):
        r = json.loads(line)
        v = Path(r["video"]); src, scene = v.parent.name, v.stem
        hit = scene in scenes.get(src, {})
        rows[src] += 1; cov[src] += hit; vids.setdefault(src, set()).add(scene)
        by_type[r.get("question_type", "?")] += 1; by_type_cov[r.get("question_type", "?")] += hit
        by_origin[r.get("source", "?")] += 1; by_origin_cov[r.get("source", "?")] += hit

    print(f"\n== 180k mix coverage ({args.mix.name})")
    for src in sorted(rows):
        vcov = sum(s in scenes.get(src, {}) for s in vids[src])
        print(f"  {src:12s} rows {pct(cov[src], rows[src]):>26s}   videos {pct(vcov, len(vids[src]))}")
    tv = sum(len(v) for v in vids.values())
    tvc = sum(sum(s in scenes.get(src, {}) for s in vids[src]) for src in vids)
    print(f"  {'total':12s} rows {pct(sum(cov.values()), sum(rows.values())):>26s}   videos {pct(tvc, tv)}")
    print("\n  by mix source:", ", ".join(f"{k} {pct(by_origin_cov[k], by_origin[k])}" for k in sorted(by_origin)))
    print("  by question type:")
    for t in sorted(by_type, key=by_type.get, reverse=True):
        print(f"    {t:28s} {pct(by_type_cov[t], by_type[t])}")
    missing = sorted(f"{src}/{s}" for src in vids for s in vids[src] if s not in scenes.get(src, {}))
    print(f"\n  mix videos without det_es: {len(missing)}" + (f"  e.g. {missing[:8]}" if missing else ""))


if __name__ == "__main__":
    main()
