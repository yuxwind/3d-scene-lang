"""Validate det64f_posed det_train.jsonl (scene-level 64f det rows on EmbodiedScan-posed frames). Exit 1 on any failure.

python validate_posed64f.py --source scannet|arkitscenes [--rows ...] [--stats ...] [--check_paths]
--check_paths: every image path exists and len(images) == the scene meta.json n_frames
(Jean Zay paths; locally pass --images_root_local /scratch/ducpham/Working/dataset/vsi_590k/VSI-590K/<source>).
"""
import argparse, json, os, sys
import numpy as np

p = argparse.ArgumentParser()
here = os.path.dirname(os.path.abspath(__file__))
p.add_argument("--source", default="scannet")
p.add_argument("--rows")
p.add_argument("--stats")
p.add_argument("--check_paths", action="store_true")
p.add_argument("--images_root_local", help="check_paths off-cluster: replace stats images_root with this local root")
a = p.parse_args()
a.rows = a.rows or f"{here}/{a.source}/det_train.jsonl"; a.stats = a.stats or f"{here}/{a.source}/stats.json"

stats = json.load(open(a.stats))
cats, bench = set(stats["categories"]), set(stats["bench_ids"])
assert len(cats) == 288, len(cats)
rows = [json.loads(l) for l in open(a.rows)]
errs, nbox, scenes = [], [], set()
for r in rows:
    sc = r["scene"]
    if sc in scenes:
        errs.append(f"{sc}: duplicate")
    scenes.add(sc)
    if sc in bench:
        errs.append(f"{sc}: in VSI-Bench/ReVSI")
    if not r["boxes"]:
        errs.append(f"{sc}: zero boxes")
    nbox.append(len(r["boxes"]))
    for b in r["boxes"]:
        v = np.asarray(b["bbox_3d"], float)
        if b["label"] not in cats:
            errs.append(f"{sc}: label {b['label']!r} not in vocab")
        if v.shape != (9,) or not np.isfinite(v).all():
            errs.append(f"{sc}: bad box {b}")
        elif (v[3:6] <= 0).any():
            errs.append(f"{sc}: size<=0 {b}")
    if len(r["images"]) != r["n_frames"] or r["graph"].count('\t{"label": ') != len(r["boxes"]):
        errs.append(f"{sc}: images/n_frames/graph count mismatch")
    if a.check_paths:
        ims = [x.replace(stats["images_root"], a.images_root_local) for x in r["images"]] if a.images_root_local else r["images"]
        meta = json.load(open(os.path.join(os.path.dirname(os.path.dirname(ims[0])), "meta.json")))
        if meta["n_frames"] != len(r["images"]) or meta["scene"] != sc:
            errs.append(f"{sc}: scene meta n_frames {meta['n_frames']} / scene {meta['scene']} != {len(r['images'])}")
        missing = [x for x in ims if not os.path.exists(x)]
        if missing:
            errs.append(f"{sc}: {len(missing)} missing images e.g. {missing[0]}")
for e in errs[:50]:
    print("FAIL", e)
print(f"{a.source}: {len(rows)} rows, {len(errs)} errors, boxes/row min/median/max "
      f"{min(nbox)}/{int(np.median(nbox))}/{max(nbox)}, check_paths={a.check_paths}")
sys.exit(1 if errs else 0)
