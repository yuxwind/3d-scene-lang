"""Lowres_wide png timestamps (first/last/span) for every ARKit mix video, via the zip-central-directory
range-read trick (plan_checks/arkit_zip_listing.py). Output arkitscenes/arkit_lowres_ts.json; resumable."""
import json, os, sys
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, "/scratch/ducpham/Working/spatial_reasoning/boxer/scannetpp_probe/plan_checks")
from arkit_zip_listing import listing

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "arkitscenes/arkit_lowres_ts.json")
ids = json.load(open("/scratch/ducpham/Working/spatial_reasoning/boxer/scannetpp_probe/plan_checks/mix_ids.json"))["arkitscenes"]
done = json.load(open(OUT)) if os.path.exists(OUT) else {}
todo = [s for s in ids if s not in done]
print(len(ids), "videos,", len(todo), "to list", flush=True)

def one(sc):
    for attempt in range(3):
        try:
            return sc, listing(sc)
        except Exception as e:
            err = repr(e)
    return sc, {"error": err}

with ThreadPoolExecutor(8) as ex:
    for i, (sc, r) in enumerate(ex.map(one, todo)):
        done[sc] = r
        if i % 100 == 0 or i == len(todo) - 1:
            json.dump(done, open(OUT, "w")); print(i, sc, r, flush=True)
json.dump(done, open(OUT, "w"))
print("errors:", [s for s, r in done.items() if "error" in r])
