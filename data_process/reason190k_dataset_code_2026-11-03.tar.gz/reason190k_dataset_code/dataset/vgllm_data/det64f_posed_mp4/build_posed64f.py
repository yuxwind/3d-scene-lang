"""64 EmbodiedScan-POSED frames per VSI-590K ScanNet / ARKitScenes video + one scene-level VG-LLM det row.

Per video (next to the mp4):  <source>/<scene>/det_mp4/{frames/frameNN.jpg, meta.json, det.json}   (--pixel_source mp4)
                              <source>/<scene>/det_es/{...}  same frames/boxes, pixels from the EmbodiedScan images (--pixel_source embodiedscan;
                              ScanNet posed_images 1296x968, ARKit lowres_wide 256x192 range-fetched from the Apple zips, rotated by rot90_k)
Aggregate:                    det64f_posed_mp4/<source>/det_train.jsonl + stats.json   |   det64f_posed_es/<source>/...
Frame pool = EmbodiedScan posed frames only; 64 uniform over the pool (all if fewer).
  ScanNet: mp4 frame i == raw frame i (30 fps; header says 24), posed id == mp4 idx.
  ARKit:   mp4 = 30 fps, starts `lead` s before the first lowres png; off = lowres_span - mp4_duration (< 0),
           mp4_idx = round((png_ts - ts0 - off) * 30). mp4 frames are already upright (probe: (4-k_mp4)%4 ==
           pose-derived rot_k on 5/5), so K / cam2global are rotated by rot_k (rot90_cam rule), pixels are not.
Resize = collator budget (smart_resize, 64..128 tokens, factor 64 as in qwen-vl-utils 0.0.14 -> 256x384; PIL bicubic == process_vision_info).
Boxes = process_threedod line for line (union of visible ids, drop wall/ceiling/floor/object, cam0 = frame00).

python build_posed64f.py --source scannet|arkitscenes [--pixel_source mp4|embodiedscan] [--limit N] [--workers 16] [--scenes ID ...]
"""
import argparse, json, os, pickle, sys
from collections import Counter
from multiprocessing import Pool
from types import SimpleNamespace
import numpy as np
import cv2  # noqa: F401  (import before decord)
import decord
from PIL import Image

W = "/scratch/ducpham/Working"
sys.path.insert(0, f"{W}/spatial_reasoning/scene_graph_idea/VG-LLM/scripts/preprocess")
sys.path.insert(0, f"{W}/spatial_reasoning/finetuning/idea_3i_130k_joint_cached_64f")
sys.path.insert(0, f"{W}/spatial_reasoning/Qwen3-VL/qwen-vl-utils/src")
from utils import embodiedscan_bbox_to_o3d_geo, o3d_geo_to_9dof  # VG-LLM
from process_threedod import create_question_answer  # VG-LLM
from graph_vgllm import canonicalize
from qwen_vl_utils.vision_process import smart_resize
import open3d as o3d

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, f"{os.path.dirname(HERE)}/det64f_posed_es")
from arkit_fetch_pngs import fetch as fetch_arkit_pngs
VSI_LOCAL = f"{W}/dataset/vsi_590k/VSI-590K"
VSI_JZ = "/lustre/fsn1/projects/rech/btf/uff48lg/dataset/vsi_590k/VSI-590K"
PKL = {"scannet": f"{W}/dataset/embodiedscan/embodiedscan/embodiedscan_infos_{{}}.pkl",
       "arkitscenes": f"{W}/dataset/embodiedscan_arkitscenes/embodiedscan-v2/embodiedscan_infos_{{}}.pkl"}
ES_PREFIX = {"scannet": "scannet/", "arkitscenes": "arkitscenes/Training/"}
MIX_IDS = f"{W}/spatial_reasoning/boxer/scannetpp_probe/plan_checks/mix_ids.json"
BENCH_IDS = f"{W}/spatial_reasoning/boxer/scannetpp_probe/plan_checks/bench_ids.json"
LOWRES_TS = f"{HERE}/arkitscenes/arkit_lowres_ts.json"
N_FRAMES, MIN_POSED = 64, 8
FPS = 30.0                                   # true rate of both sources (ScanNet header says 24)
MIN_PIXELS, MAX_PIXELS = 64 * 32 * 32, 128 * 32 * 32   # collator._LLM_{MIN,MAX}_PIXELS
# qwen-vl-utils 0.0.14 (Jean Zay env) passes image_factor (16 x merge 2 = 32) to fetch_image as its patch size, so the
# per-frame smart_resize runs with factor 64: 480x640 -> 256x384 (== the joint130k frame_cache_64f llm_hw), and the
# later factor-32 pass is a no-op. The repo checkout here gives 288x416; training uses the pip version, so factor 64.
FACTOR = 64
EXCLUDE = {"wall", "ceiling", "floor", "object"}
ARKIT_OFF_CAL = 0.06
ARKIT_LOWRES_W = 256                         # EmbodiedScan ARKit cam2img is for the 256x192 lowres_wide pngs
SCANNET_HW = (968, 1296)                     # EmbodiedScan ScanNet cam2img is for the 1296x968 posed images
ARKIT_LOWRES_HW = (192, 256)
SCANNET_POSED = f"{W}/dataset/scannet/posed_images"
ARKIT_ROOT = f"{W}/dataset/embodiedscan_arkitscenes/arkitscenes/Training"
SUB = {"mp4": "det_mp4", "embodiedscan": "det_es"}
PIX = "mp4"                                  # --pixel_source, set in main before the fork

ES = {}   # scene -> EmbodiedScan sample (filled in the parent, inherited by forked workers)
CATS = {}
LOWRES = {}


def load_es(source):
    cats = None
    for sp in ("train", "val"):
        d = pickle.load(open(PKL[source].format(sp), "rb"))
        cats = cats or {v: k for k, v in d["metainfo"]["categories"].items()}
        for s in d["data_list"]:
            if s["sample_idx"].startswith(ES_PREFIX[source]):
                ES[s["sample_idx"].split("/")[-1]] = s
    CATS.update(cats)


def rot90_K_T(K, T, hw, k):
    # prep_scene.rot90_cam without the pixels: rot90 (CCW) about the camera z axis, k times
    H, Wd = hw
    for _ in range(k % 4):
        K = np.array([[K[1, 1], 0, K[1, 2]], [0, K[0, 0], Wd - 1 - K[0, 2]], [0, 0, 1.0]])
        R = np.eye(4); R[:3, :3] = [[0, -1, 0], [1, 0, 0], [0, 0, 1]]
        T = T @ R; H, Wd = Wd, H
    return K, T


def corr(a, b):
    a = cv2.resize(a, (64, 48)).astype(float).ravel(); b = cv2.resize(b, (64, 48)).astype(float).ravel()
    return float(np.corrcoef(a, b)[0, 1])


def build_es(source, sc, out):
    # same frames / boxes as det_mp4 (copied), pixels from the EmbodiedScan images, K = the EmbodiedScan intrinsics (unscaled)
    mp4_dir = f"{VSI_LOCAL}/{source}/{sc}/det_mp4"
    if not os.path.exists(f"{mp4_dir}/det.json"):
        return sc, "no_det_mp4", None
    meta, row = json.load(open(f"{mp4_dir}/meta.json")), json.load(open(f"{mp4_dir}/det.json"))
    s = ES[sc]; A = np.array(s["axis_align_matrix"]); by_path = {im["img_path"]: im for im in s["images"]}
    rot_k, nbytes = meta.get("rot90_k", 0), 0
    if source == "scannet":
        srcs = [f"{SCANNET_POSED}/{sc}/{f['posed_id']}.jpg" for f in meta["frames"]]
        hw_pre = Image.open(srcs[0]).size[::-1]        # 1296x968 for most scenes, 640x480 for 34 (cam2img matches either way)
    else:
        d = f"{ARKIT_ROOT}/{sc}/{sc}_frames/lowres_wide"
        srcs = [f"{d}/{f['posed_id']}.png" for f in meta["frames"]]; hw_pre = ARKIT_LOWRES_HW
        try:
            nbytes = fetch_arkit_pngs(sc, [os.path.basename(x) for x in srcs], d)
        except Exception as e:
            return sc, "png_fetch_failed", {"error": repr(e)}
    frames = []
    for f, x in zip(meta["frames"], srcs):
        im = by_path[f["img_path"]]
        K0 = np.array(s["cam2img"] if source == "scannet" else im["cam2img"])[:3, :3]
        K, T = rot90_K_T(K0, A @ np.array(im["cam2global"]), hw_pre, rot_k)
        assert np.allclose(T, f["cam2global"]), sc
        frames.append({**f, "cam2img": K.tolist(), "src_path": x})
    native_hw = hw_pre if rot_k % 2 == 0 else hw_pre[::-1]
    h, w = smart_resize(native_hw[0], native_hw[1], FACTOR, MIN_PIXELS, MAX_PIXELS)
    os.makedirs(f"{out}/frames", exist_ok=True)
    for j, x in enumerate(srcs):
        a = np.rot90(np.asarray(Image.open(x).convert("RGB")), rot_k)        # same upright rotation as the mp4 frames
        assert a.shape[:2] == tuple(native_hw), (sc, a.shape, native_hw)
        Image.fromarray(np.ascontiguousarray(a)).resize((w, h)).save(f"{out}/frames/frame{j:02d}.jpg", "JPEG", quality=95)
    c = corr(np.asarray(Image.open(f"{out}/frames/frame00.jpg").convert("RGB")), np.asarray(Image.open(f"{mp4_dir}/frames/frame00.jpg").convert("RGB")))
    row["images"] = [x.replace("/det_mp4/frames/", "/det_es/frames/") for x in row["images"]]
    assert all("/det_es/frames/" in x for x in row["images"]), sc
    meta = {**meta, "pixel_source": "embodiedscan", "native_hw": list(native_hw), "llm_hw": [h, w], "frames": frames,
            "mp4_native_hw": meta["native_hw"], "mp4_llm_hw": meta["llm_hw"], "frame00_corr_mp4": c, "png_bytes_fetched": nbytes}
    json.dump(meta, open(f"{out}/meta.json", "w"))
    json.dump(row, open(f"{out}/det.json", "w"))
    return sc, "built", meta


def build_one(job):
    source, sc = job
    out = f"{VSI_LOCAL}/{source}/{sc}/{SUB[PIX]}"
    if os.path.exists(f"{out}/det.json"):
        return sc, "built", json.load(open(f"{out}/meta.json"))
    if PIX == "embodiedscan":
        return build_es(source, sc, out)
    s = ES.get(sc)
    if s is None:
        return sc, "no_poses", None
    ims = s["images"]
    if len(ims) < MIN_POSED:
        return sc, "n_posed<%d" % MIN_POSED, None
    vr = decord.VideoReader(f"{VSI_LOCAL}/{source}/{sc}.mp4", num_threads=2)
    total, hfps = len(vr), float(vr.get_avg_fps())
    native_hw = tuple(int(v) for v in vr[0].shape[:2])
    A = np.array(s["axis_align_matrix"])
    extra = {}
    if source == "scannet":
        pid = np.array([int(im["img_path"].split("/")[-1][:-4]) for im in ims])
        assert pid[0] == 0, sc
        mp4_idx = pid.astype(float)                         # mp4 frame i == raw frame i
        ok = pid < total                                    # a few mp4s end before the last posed id
        K = np.array(s["cam2img"])[:3, :3].copy()
        K[0] *= native_hw[1] / SCANNET_HW[1]; K[1] *= native_hw[0] / SCANNET_HW[0]
        Ks = [K] * len(ims); rot_k = 0
        pid_key = [f"{p:05d}" for p in pid]
    else:
        lr = LOWRES.get(sc)
        if not lr or "error" in lr:
            return sc, "no_lowres_listing", None
        ts = np.array([float(im["img_path"].split("_")[-1][:-4]) for im in ims])
        # < 0: mp4 starts |off| s before the first png. First-to-last spans on both sides, plus a calibration
        # ponytail: +0.06 s fit by 1-frame pixel matching on 2 local scenes (rule alone lands ~3 frames late)
        off = lr["span"] - (total - 1) / FPS + ARKIT_OFF_CAL
        lead = -off
        if lead < -1 or lead > 3:
            return sc, "offset_implausible", {"lead_s": lead}
        mp4_idx = (ts - lr["first"] - off) * FPS
        ok = (mp4_idx > -0.5) & (mp4_idx < total - 0.5)
        # pose-derived upright rotation (prep_scene.main_embodiedscan): image-up with the largest world z
        Rw = np.array([(A @ np.array(im["cam2global"]))[:3, :3] for im in ims]); R1 = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]])
        upz = [float((Rw @ -np.linalg.matrix_power(R1, k)[:, 1])[:, 2].mean()) for k in range(4)]
        rot_k = int(np.argmax(upz))
        if (rot_k % 2 == 1) != (native_hw[0] > native_hw[1]):
            return sc, "rot_mismatch", {"rot_k": rot_k, "native_hw": native_hw, "upz": upz}
        sc_ = (native_hw[1] if rot_k % 2 == 0 else native_hw[0]) / ARKIT_LOWRES_W   # lowres -> mp4 pixels (pre-rotation)
        Ks = [np.array(im["cam2img"])[:3, :3] * [[sc_], [sc_], [1]] for im in ims]
        extra = {"offset_s": off, "offset_cal_s": ARKIT_OFF_CAL, "lead_s": lead, "lowres_first_ts": lr["first"], "lowres_span_s": lr["span"],
                 "rot90_k": rot_k, "image_up_z": upz}
        pid_key = [im["img_path"].split("/")[-1][:-4] for im in ims]
    pool = np.flatnonzero(ok)
    if len(pool) < MIN_POSED:
        return sc, "n_posed<%d" % MIN_POSED, None
    sel = pool[np.unique(np.linspace(0, len(pool) - 1, N_FRAMES).round().astype(int))]
    idx = np.clip(mp4_idx[sel].round(), 0, total - 1).astype(int)
    keep = np.flatnonzero(np.r_[True, np.diff(idx) > 0])    # drop posed frames that round to the same mp4 frame
    sel, idx = sel[keep], idx[keep]
    resid = (idx - mp4_idx[sel]) / FPS

    hw_pre = native_hw if rot_k % 2 == 0 else (native_hw[1], native_hw[0])   # shape before the upright rotation
    frames_meta, cam0 = [], None
    for j, (p, i) in enumerate(zip(sel, idx)):
        K, T = rot90_K_T(Ks[p], A @ np.array(ims[p]["cam2global"]), hw_pre, rot_k)
        cam0 = T if j == 0 else cam0
        frames_meta.append({"frame": j, "mp4_idx": int(i), "time_s": float(i / FPS), "posed_id": pid_key[p],
                            "img_path": ims[p]["img_path"], "residual_s": float(resid[j]),
                            "cam2global": T.tolist(), "cam2img": K.tolist()})
    # boxes: process_threedod.process_data_item, line for line, cam0 = frame00
    inst_ids = list(dict.fromkeys(i_ for p in sel for i_ in ims[p]["visible_instance_ids"]))
    inst = [dict(instance_id=k, **s["instances"][k]) for k in inst_ids]
    inst = [x for x in inst if CATS[x["bbox_label_3d"]] not in EXCLUDE]
    g2c = np.linalg.inv(cam0); new = []
    for x in inst:
        geo = embodiedscan_bbox_to_o3d_geo(x["bbox_3d"])
        c = g2c @ np.array([*geo.center, 1]).reshape(4, 1)
        geo_c = o3d.geometry.OrientedBoundingBox(c[:3].reshape(3), g2c[:3, :3] @ geo.R, geo.extent)
        new.append(dict(instance_id=x["instance_id"], label=CATS[x["bbox_label_3d"]], bbox_3d=list(map(float, x["bbox_3d"])),
                        bbox_3d_in_cam=[float(v) for v in o3d_geo_to_9dof(geo_c, convention="ZXY")]))
    if not new:
        return sc, "zero_boxes", None

    os.makedirs(f"{out}/frames", exist_ok=True)
    h, w = smart_resize(native_hw[0], native_hw[1], FACTOR, MIN_PIXELS, MAX_PIXELS)
    for j, f in enumerate(vr.get_batch(idx).asnumpy()):
        Image.fromarray(f).resize((w, h)).save(f"{out}/frames/frame{j:02d}.jpg", "JPEG", quality=95)  # == fetch_image
    images = [f"{VSI_JZ}/{source}/{sc}/det_mp4/frames/frame{j:02d}.jpg" for j in range(len(idx))]
    q, a = create_question_answer(len(images), new, SimpleNamespace(reference_frame="first"))
    row = {"task": "det", "scene": sc, "video": f"{VSI_JZ}/{source}/{sc}.mp4", "n_frames": len(idx), "images": images,
           "graph": canonicalize(a), "conversations": [{"from": "human", "value": q}, {"from": "gpt", "value": a}],
           "boxes": [{"bbox_3d": x["bbox_3d_in_cam"], "label": x["label"]} for x in new]}
    meta = {"source": source, "scene": sc, "mp4": f"{VSI_JZ}/{source}/{sc}.mp4", "mp4_local": f"{VSI_LOCAL}/{source}/{sc}.mp4",
            "mp4_header_fps": hfps, "fps": FPS, "mp4_num_frames": total, "native_hw": list(native_hw), "llm_hw": [h, w],
            "n_posed": len(ims), "n_posed_in_clip": int(len(pool)), "n_frames": len(idx), "frames": frames_meta,
            "cam0_cam2global": cam0.tolist(), "n_boxes": len(new), "instance_ids": [x["instance_id"] for x in new], **extra}
    json.dump(meta, open(f"{out}/meta.json", "w"))
    json.dump(row, open(f"{out}/det.json", "w"))
    return sc, "built", meta


def main():
    p = argparse.ArgumentParser(); p.add_argument("--source", required=True, choices=list(PKL))
    p.add_argument("--limit", type=int); p.add_argument("--workers", type=int, default=16); p.add_argument("--scenes", nargs="*")
    p.add_argument("--pixel_source", default="mp4", choices=list(SUB))
    a = p.parse_args()
    global PIX; PIX = a.pixel_source
    agg = HERE if PIX == "mp4" else f"{os.path.dirname(HERE)}/det64f_posed_es"
    ids = a.scenes or json.load(open(MIX_IDS))[a.source][:a.limit]
    bench = json.load(open(BENCH_IDS))
    bench = set(bench["vsibench_videos"][a.source]) | set(bench["revsi"]["ScanNetv2" if a.source == "scannet" else "ARKitScenes"])
    assert not (set(ids) & bench), sorted(set(ids) & bench)
    load_es(a.source)
    if a.source == "arkitscenes":
        LOWRES.update(json.load(open(LOWRES_TS)))
    drops, metas = Counter(), {}
    with Pool(a.workers) as pool:
        for n, (sc, status, meta) in enumerate(pool.imap_unordered(build_one, [(a.source, sc) for sc in ids], chunksize=4)):
            if status == "built":
                metas[sc] = meta
            else:
                drops[status] += 1; print("DROP", sc, status, meta, flush=True)
            if n % 200 == 0:
                print(n, sc, status, flush=True)
    rows = [json.load(open(f"{VSI_LOCAL}/{a.source}/{sc}/{SUB[PIX]}/det.json")) for sc in ids if sc in metas]
    if PIX == "embodiedscan":
        for r in rows:
            m = json.load(open(f"{VSI_LOCAL}/{a.source}/{r['scene']}/det_mp4/det.json"))
            assert (r["boxes"], r["graph"], r["conversations"], r["n_frames"]) == (m["boxes"], m["graph"], m["conversations"], m["n_frames"]), r["scene"]
        print("boxes/graph/conversations identical to det_mp4 for all", len(rows), "rows", flush=True)
    os.makedirs(f"{agg}/{a.source}", exist_ok=True)
    with open(f"{agg}/{a.source}/det_train.jsonl", "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    pct = lambda v: dict(zip(["min", "p5", "p25", "p50", "p75", "p95", "max"], np.percentile(v, [0, 5, 25, 50, 75, 95, 100]).round(3).tolist())) if len(v) else {}
    ms = list(metas.values())
    stats = {"source": a.source, "pixel_source": PIX, "videos_total": len(ids), "videos_with_poses": sum(sc in ES for sc in ids), "built": len(rows),
             "dropped": dict(drops), "n_frames": N_FRAMES, "min_posed": MIN_POSED,
             "frames_per_video": pct([m["n_frames"] for m in ms]), "frames_hist": dict(sorted(Counter(m["n_frames"] for m in ms).items())),
             "boxes_per_video": pct([m["n_boxes"] for m in ms]), "boxes_hist": dict(sorted(Counter(m["n_boxes"] for m in ms).items())),
             "n_posed": pct([m["n_posed"] for m in ms]), "residual_s_abs": pct([abs(f["residual_s"]) for m in ms for f in m["frames"]]),
             "llm_hw": {str(m["llm_hw"]): n for m, n in [(m, 0) for m in ms[:0]]} or dict(Counter(str(m["llm_hw"]) for m in ms)),
             "native_hw": dict(Counter(str(m["native_hw"]) for m in ms)),
             "min_pixels": MIN_PIXELS, "max_pixels": MAX_PIXELS, "factor": FACTOR, "jpeg_quality": 95,
             "images_root": f"{VSI_JZ}/{a.source}", "categories": sorted(CATS.values()), "bench_ids": sorted(bench)}
    if PIX == "embodiedscan":
        stats.update(frame00_corr_mp4=pct([m["frame00_corr_mp4"] for m in ms]), frame00_corr_mp4_lt_0p8=sum(m["frame00_corr_mp4"] < 0.8 for m in ms),
                     png_bytes_fetched=int(sum(m["png_bytes_fetched"] for m in ms)))
    if a.source == "arkitscenes":
        stats.update(arkit_lead_s=pct([m["lead_s"] for m in ms]), arkit_rot90_k=dict(Counter(m["rot90_k"] for m in ms)),
                     arkit_frame00_time_s=pct([m["frames"][0]["time_s"] for m in ms]))
    json.dump(stats, open(f"{agg}/{a.source}/stats.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in stats.items() if k not in ("categories", "bench_ids", "boxes_hist", "frames_hist")}, indent=1))


if __name__ == "__main__":
    main()
