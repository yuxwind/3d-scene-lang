ssh jeanzay 'bash -ls' <<'REMOTE' 2>&1 | grep -v -i warning
P=$WORK/miniconda3/envs/vsibench_eval_full/bin/python
$P - <<'PY'
import os, qwen_vl_utils, numpy as np, torch
from PIL import Image
from qwen_vl_utils import process_vision_info
from qwen_vl_utils.vision_process import smart_resize
print("qwen_vl_utils", qwen_vl_utils.__file__, "MODEL_SEQ_LEN", os.environ.get("MODEL_SEQ_LEN"))
for hw in [(480, 640), (640, 480), (288, 416), (416, 288)]:
    im = Image.fromarray(np.random.randint(0, 255, (*hw, 3), np.uint8))
    _, videos, _ = process_vision_info([{"role": "user", "content": [{"type": "video", "video": [im, im], "min_pixels": 65536, "max_pixels": 131072}]}], return_video_kwargs=True, image_patch_size=16)
    print(hw, "collator-style", tuple(videos[0].shape[-2:]), "smart_resize", smart_resize(*hw, 32, 65536, 131072))
PY
cat $SCRATCH/dataset/vgllm_data/joint130k/frame_cache_64f/00/0003f06e53cf2d08bb2269ecd1b1bd38384f80a5/meta.json | head -12
REMOTE
