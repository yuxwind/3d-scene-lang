ssh jeanzay 'bash -ls' <<'REMOTE' 2>&1 | grep -v -i warning
$WORK/miniconda3/envs/vsibench_eval_full/bin/python - <<'PY'
import numpy as np, torch
from PIL import Image
from qwen_vl_utils import process_vision_info
for hw in [(256, 384), (384, 256)]:
    im = Image.fromarray(np.random.randint(0, 255, (*hw, 3), np.uint8))
    _, videos, _ = process_vision_info([{"role": "user", "content": [{"type": "video", "video": [im] * 64, "min_pixels": 65536, "max_pixels": 131072}]}], return_video_kwargs=True, image_patch_size=16)
    v = videos[0][0].permute(1, 2, 0).clamp(0, 255).to(torch.uint8).numpy()
    print(hw, "-> collator", tuple(videos[0].shape[-2:]), "pixel-identical no-op:", np.array_equal(v, np.array(im)))
PY
REMOTE
