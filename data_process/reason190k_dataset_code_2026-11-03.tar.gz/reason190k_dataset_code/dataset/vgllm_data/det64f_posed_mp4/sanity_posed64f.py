"""Sanity for det64f_posed rows.
(1) --viz: project the cam0 9-DoF boxes of det.json onto the SAVED frame00.jpg (meta cam2img scaled native->llm_hw)
    -> _viz/<source>_<scene>.jpg.  Boxes must land on objects.
(2) --arkit_pixel: for the ARKit scenes with local lowres pngs, corr(mp4[mp4_idx] rotated back, lowres png of that
    posed frame) vs the +-2 png neighbours: the derived offset must pick the right png.
python sanity_posed64f.py --viz scannet:scene0000_00 arkitscenes:42897815 ...   |   --arkit_pixel
"""
import argparse, json, os, sys
import numpy as np, cv2, decord, open3d as o3d
from PIL import Image, ImageDraw
W = "/scratch/ducpham/Working"
sys.path.insert(0, f"{W}/spatial_reasoning/scene_graph_idea/VG-LLM/scripts/preprocess")
sys.path.insert(0, f"{W}/spatial_reasoning/finetuning/viz_posed64f")
from utils import embodiedscan_bbox_to_o3d_geo
from prep_scene import corr
VSI = f"{W}/dataset/vsi_590k/VSI-590K"; ARKIT = f"{W}/dataset/embodiedscan_arkitscenes/arkitscenes/Training"
here = os.path.dirname(os.path.abspath(__file__))
p = argparse.ArgumentParser(); p.add_argument("--viz", nargs="*"); p.add_argument("--arkit_pixel", action="store_true")
p.add_argument("--sub", default="det_mp4", help="det_mp4 | det_es"); p.add_argument("--out", default=f"{here}/_viz"); a = p.parse_args()

for item in a.viz or []:
    src, sc = item.split(":"); d = f"{VSI}/{src}/{sc}/{a.sub}"
    row, meta = json.load(open(f"{d}/det.json")), json.load(open(f"{d}/meta.json"))
    img = Image.open(f"{d}/frames/frame00.jpg").convert("RGB"); dr = ImageDraw.Draw(img)
    K = np.array(meta["frames"][0]["cam2img"]); (H, Wd), (h, w) = meta["native_hw"], meta["llm_hw"]
    K = np.diag([w / Wd, h / H, 1]) @ K; ndrawn = 0
    for b in row["boxes"]:
        P = np.asarray(o3d.geometry.LineSet.create_from_oriented_bounding_box(embodiedscan_bbox_to_o3d_geo(b["bbox_3d"])).points)
        if (P[:, 2] <= 0.1).any():
            continue
        uv = (K @ P.T).T; uv = uv[:, :2] / uv[:, 2:3]
        for i, j in np.asarray(o3d.geometry.LineSet.create_from_oriented_bounding_box(embodiedscan_bbox_to_o3d_geo(b["bbox_3d"])).lines):
            dr.line([tuple(uv[i]), tuple(uv[j])], fill=(255, 40, 40), width=1)
        dr.text(tuple(uv.min(0)), b["label"], fill=(255, 255, 0)); ndrawn += 1
    os.makedirs(a.out, exist_ok=True); img.save(f"{a.out}/{src}_{sc}.png")
    print(f"{src} {sc}: {ndrawn}/{len(row['boxes'])} boxes in front of cam0 drawn on {img.size}, frame00 = mp4 idx {meta['frames'][0]['mp4_idx']} posed {meta['frames'][0]['posed_id']}")

if a.arkit_pixel:
    for sc in sorted(os.listdir(ARKIT)):
        d = f"{VSI}/arkitscenes/{sc}/det_mp4"
        if not os.path.exists(f"{d}/meta.json"):
            print(sc, "not built"); continue
        meta = json.load(open(f"{d}/meta.json")); vr = decord.VideoReader(f"{VSI}/arkitscenes/{sc}.mp4", num_threads=1)
        pngs = sorted(os.listdir(f"{ARKIT}/{sc}/{sc}_frames/lowres_wide")); k_back = (4 - meta["rot90_k"]) % 4
        res = []
        for f in meta["frames"][:: max(1, len(meta["frames"]) // 6)]:
            fr = np.rot90(vr[f["mp4_idx"]].asnumpy(), k_back); j = pngs.index(f["posed_id"] + ".png")
            cs = [corr(fr, cv2.cvtColor(cv2.imread(f"{ARKIT}/{sc}/{sc}_frames/lowres_wide/{pngs[jj]}"), cv2.COLOR_BGR2RGB)) for jj in range(max(0, j - 2), min(len(pngs), j + 3))]
            res.append((f["mp4_idx"], round(cs[min(2, j)], 3), int(np.argmax(cs)) - min(2, j)))
        print(sc, "lead %.2fs" % meta["lead_s"], "rot_k", meta["rot90_k"], "(mp4_idx, corr with matched png, argmax neighbour offset):", res)
