# gemma_eval

gemma-4 VSI-Bench-Debiased eval reading frames from the det_es cache
(`<video_root>/<scene>/det_es/{det.json,meta.json,frames/frameNN.jpg}`, 384x256, no mp4 decode).
Prompts / extraction / scoring are imported from `../gemini_eval/det_vsibench_eval.py`; the `det_video`
prompt is identical to the gemini_eval det+video prompt.

`--dataset scannet` (935 questions, 86 scenes, default) or `--dataset scannetpp` (752, 49); it sets both the
question parquet and the cache root, and `--split_parquet` / `--video_root` override it. Ids are per-dataset,
so give each dataset its own `--out_dir`; every prediction row carries a `dataset` field.

```
# det list + frames (same prompt as gemini_eval --video)
python det_vsibench_eval.py --mode det_video --out_dir results/det_vsibench/x --subset_ids ids.json \
    --image_tokens 140 --num_frames 64 --no-thinking --max_new_tokens 4096
# ScanNet++: 20 questions per type into <out_dir>/subset/, then score them
python det_vsibench_eval.py --dataset scannetpp --mode det_video --out_dir results/det_vsibench/spp --subset_n 20
python det_vsibench_eval.py --dataset scannetpp --out_dir results/det_vsibench/spp --subset_n 20 --merge
# frames only
python det_vsibench_eval.py --mode video --out_dir results/det_vsibench/y --subset_ids ids.json
# det list only (text path)
python det_vsibench_eval.py --mode det --out_dir results/det_vsibench/z --subset_ids ids.json
```

Resume per question (append-only `predictions_shard<i>.jsonl`); `--num_shards/--shard_index` to split,
`--merge` to score the union; `--subset_ids`/`--subset_n --seed` write to `<out_dir>/subset/`.
Runner: `sbatching/dummy/det_vsibench_gemma_cache_local.sh <out_dir> [args]` inside an srun.
Compare: `python compare.py a=<preds.jsonl> b=<preds.jsonl> c=<preds.jsonl> > compare.txt` (common ids, per-category scores, identical preds between the last two).
