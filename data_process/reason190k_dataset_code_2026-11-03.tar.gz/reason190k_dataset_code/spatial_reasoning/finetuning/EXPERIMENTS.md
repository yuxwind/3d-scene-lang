# Experiment log (Jun – Sep 2026)

Pieced together from project notes and the merged eval results on Jean Zay (as of 2026-09-28).
Unless marked otherwise, scores are VSI-Bench full split (5,130 rows).

Two runs have no score yet:
- **VGGT-1B fork of text256:** trained all 743 steps, never evaluated.
- **4B twin of joint64f (Sep 12):** no eval found.

## Phase 1 (Jun – Aug): exploration and detection, local cluster

| date | experiment | result |
|---|---|---|
| Jun 14 | ac_grid_jepa (eb_jepa hackathon, ARC grids) | latent prediction works, decoder collapses to background |
| Jun 15 | GPT4Scene demo on VSI-Bench ScanNet++ | single-question demo only |
| Jun 30 – Jul 5 | idea_3j: distill VGGT→Utonia point features into the LLM (SSL head) | raw 0.77 cosine was mean-collapse; standardized targets overfit to 0.71; color-head variant added |
| Jul 3 | idea_3k / idea_3l: semantic labels on VGGT clouds (GT via ICP / Utonia seg head) | labels built; Utonia confuses wall/door/cabinet |
| Jul 11 | ScanEdit scene-graph generation (49 eval + 856 train scenes) | feeds idea_3a_scene_graph |
| Jul 21 | SpatialLM on VGGT point clouds | works with SpatialLM 1.0, transformers 4.x |
| Jul 22 | **idea_3i perceiver tuning** (Qwen3-VL-2B + VGGT-Omega + Perceiver) | debiased 0.506 vs 0.475 baseline |
| Jul 22 | PanSt3R setup; VG-LLM detection on ScanNet++ | set up; VG-LLM loops after ~40 boxes |
| Jul 23 – 28 | CA-1M corpora (metric TOON, VGGT-frame, Faro 64f, VG-LLM json); ASE viewer | 3,073 scenes, 218k boxes |
| Jul 29 – Aug 16 | idea_4a scene-graph detection via perceiver (ScanNet++ toon8, CA-1M top100, ScanNet-v2 vgjson, CA-1M vgjson LoRA) | overfits reach f1 0.97 / 0.83; held-out f1 ≈ 0 (repetition collapse) |
| Aug 12 | Text-only LLMs on ScanEdit scene graphs (gemma-4-26B, Qwen3.5-35B), debiased | graph only 0.682 / 0.642; adding video hurts |
| Aug 14 – 17 | idea_3i_spatialstack (local) | full 0.5785 vs perceiver 0.5701 |
| Aug 18 | idea_3i_vlm3r (local) | no result recorded |

## Phase 2 (Sep 8 – 19): Jean Zay, data mixes and scaling

| date | run | score |
|---|---|---|
| Sep 8 – 9 | 590k_256 @800 | 0.5669 |
| Sep 8 – 9 | 590k_joint @600 / @800 / @1000 | 0.5706 / 0.5640 / 0.5783 |
| Sep 9 | 590k_joint multiscale @600 | 0.5637 |
| Sep 10 – 11 | 130k joint cached @300 → @665 (det rows mis-keyed) | 0.5541 → 0.5701 |
| Sep 10 – 11 | same, with frame masking @665 | 0.5596 |
| Sep 10 – 11 | 200k joint @725 | 0.5703 |
| Sep 11 – 12 | 590k cached, continued from ckpt 1175, @1600 | 0.5865 |
| Sep 11 – 12 | vqa64f @300 → @508 | 0.5626 → 0.5720 |
| Sep 11 – 12 | joint64f @300 → @665 | 0.5688 → 0.5780 |
| Sep 12 | 4B twin of joint64f | no eval found |
| Sep 12 | joint130k + VLM-3R data @300 → @665 | 0.5677 → 0.5705 |
| Sep 12 | ReVSI 64f: joint64f / vqa64f | 44.68 / 45.17 |
| Sep 12 | 130k lat512 @508 | 0.5854 |
| Sep 13 | **180k lat512** @702 | **0.6034** (first run over 0.60) |
| Sep 13 | 3a_180k (plain Qwen, no VGGT) | 0.5987 |
| Sep 13 – 19 | 180k multiscale @702 | 0.6069 |
| Sep 14 – 18 | 180k det_es frames | cancelled at ckpt 375 (host out-of-memory) |
| Sep 18 – 19 | 190k es clean / 3a_190k (plain Qwen) | 0.6000 / 0.6014 |
| Sep 18 – 19 | 3a scene_lang (another session) | debiased 0.653, full ScanNet rows 0.699 |

## Phase 3 (Sep 20 – 22): 190k mix variants, reasoning, 4B, ReVSI

| date | run | score |
|---|---|---|
| Sep 20 | text256 @500 / @600 / @743 | 0.6030 / 0.6015 / **0.6060** |
| Sep 20 | lora128 | 0.6059 |
| Sep 20 | vlm3r 190k | 0.6013 |
| Sep 21 | **spatialstack 190k** | **0.6208** (best 2B) |
| Sep 21 | idea_4i (frame embedding + camera registers) | 0.6072 |
| Sep 21 – 22 | reason (SimpleSR traces) @513 | 0.4352 |
| Sep 21 – 22 | reason_cont @513 | 0.4174 (0.4841 on untruncated rows) |
| Sep 22 | reason_cont 16k @569, debiased | 0.3381 (text256 on same questions: 0.5404) |
| Sep 22 | **4B text256** @525 / @743 | 0.6691 / **0.6784** (best overall) |
| Sep 22 | ReVSI 64f, text256 @743 | **46.80** (best ReVSI) |
| Sep 22 | VGGT-1B fork of text256 | trained to 743, not evaluated |

## Takeaways

- **Model size:** the 4B model added +0.07 over its 2B twin, more than any VGGT-fusion change.
- **Fusion:** spatialstack's layered fusion is the only one that clearly beat the perceiver path (+0.015).
- **Data mix:** the 180k/190k mix moved scores from 0.57 to 0.60.
- **Reasoning traces:** they hurt, because of runaway generations and broken room-size answers.
