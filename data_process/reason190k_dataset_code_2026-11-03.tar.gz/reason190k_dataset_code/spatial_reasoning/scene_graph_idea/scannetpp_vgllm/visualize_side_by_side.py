"""Viser: a CA-1M scene and a ScanNet++ scene in the same VG-LLM format, one at a time.

Both are drawn at the origin in their own camera-0 frame, so flipping between them compares
the two exports' conventions directly -- if one pipeline had the rotation or the handedness
wrong, the two would not sit the same way relative to the axis marker.

  conda activate vsibench_eval_full
  python scannetpp_vgllm/visualize_side_by_side.py
  python scannetpp_vgllm/visualize_side_by_side.py --ca1m-scene 42444499 --scannetpp-scene 39f36da05b
"""

import argparse
import os
import sys

import numpy as np
import viser

ROOT = os.path.dirname(os.path.abspath(__file__))
IDEA = os.path.dirname(ROOT)
CA1M = os.path.join(IDEA, "ml-cubifyanything")
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(CA1M, "ca1m_vgllm"))

from export_scannetpp import read_colmap, read_ply_vertices, visible   # noqa: E402
from visualize import box_pose, label_color, load_cloud, read_graph, to_camera0  # noqa: E402


def load_scannetpp(scene, max_points):
    """Mesh vertices, frustum-culled to the 64 exported cameras and put in camera 0's frame."""
    cams = np.load(os.path.join(scene, "cams.npz"))
    K, RTs = cams["K"][0], cams["RT"]
    _, _, _, width, height = read_colmap(
        os.path.join(os.path.realpath(os.path.join(scene, "scans")), "..", "iphone", "colmap"))

    points, colors = read_ply_vertices(os.path.join(scene, "scans", "mesh_aligned_0.05.ply"))
    keep = visible(points, K, RTs, width, height)
    points, colors = points[keep], colors[keep]
    if len(points) > max_points:
        idx = np.random.default_rng(0).choice(len(points), max_points, replace=False)
        points, colors = points[idx], colors[idx]
    return to_camera0(points, RTs[0]).astype(np.float32), colors


def add_scene(server, name, points, colors, boxes, point_size):
    """Everything for one corpus under /<name>, so visibility flips as a unit."""
    cloud = server.scene.add_point_cloud(
        f"/{name}/cloud", points=points, colors=colors, point_size=point_size)
    handles, labels = [], []
    for i, box in enumerate(boxes):
        centre, wxyz, extent = box_pose(box["bbox_3d"])
        handles.append(server.scene.add_box(
            f"/{name}/box_{i}", color=label_color(box["label"]), dimensions=tuple(extent),
            wxyz=wxyz, position=centre, wireframe=True))
        labels.append(server.scene.add_label(f"/{name}/label_{i}", box["label"], position=centre))
    return {"cloud": cloud, "boxes": handles, "labels": labels,
            "points": points, "colors": colors}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ca1m-scene", default="42444499")
    p.add_argument("--scannetpp-scene", default="39f36da05b")
    p.add_argument("--ca1m-root", default=os.path.join(CA1M, "ca1m_vgllm", "train"))
    p.add_argument("--scannetpp-root", default=os.path.join(ROOT, "train"))
    p.add_argument("--port", type=int, default=8080)
    p.add_argument("--max-points", type=int, default=1_000_000)
    args = p.parse_args()

    ca1m_dir = os.path.join(args.ca1m_root, args.ca1m_scene)
    spp_dir = os.path.join(args.scannetpp_root, args.scannetpp_scene)

    ca1m_boxes = read_graph(os.path.join(ca1m_dir, "scene_graph.txt"))
    ca1m_points, ca1m_colors = load_cloud(ca1m_dir, 1, 10.0, args.max_points)
    spp_boxes = read_graph(os.path.join(spp_dir, "scene_graph.txt"))
    spp_points, spp_colors = load_scannetpp(spp_dir, args.max_points)
    print(f"CA-1M     {args.ca1m_scene}: {len(ca1m_boxes):4d} boxes, {len(ca1m_points)} points")
    print(f"ScanNet++ {args.scannetpp_scene}: {len(spp_boxes):4d} boxes, {len(spp_points)} points")

    server = viser.ViserServer(port=args.port)
    server.scene.add_frame("/camera0", axes_length=0.5, axes_radius=0.012)
    scenes = {
        "CA-1M": add_scene(server, "ca1m", ca1m_points, ca1m_colors, ca1m_boxes, 0.01),
        "ScanNet++": add_scene(server, "scannetpp", spp_points, spp_colors, spp_boxes, 0.01),
    }

    which = server.gui.add_dropdown("Scene", tuple(scenes), initial_value="CA-1M")
    show_cloud = server.gui.add_checkbox("Show cloud", True)
    show_labels = server.gui.add_checkbox("Show labels", True)
    solid = server.gui.add_checkbox("Solid boxes", False)
    opacity = server.gui.add_slider("Opacity", 0.05, 1.0, 0.05, 0.4)
    point_size = server.gui.add_slider("Point size", 0.001, 0.05, 0.001, 0.01)

    def restyle(_=None):
        for name, scene in scenes.items():
            on = name == which.value
            scene["cloud"].visible = on and show_cloud.value
            for handle in scene["boxes"]:
                handle.visible = on
                handle.wireframe = not solid.value
                handle.opacity = opacity.value if solid.value else None
            for label in scene["labels"]:
                label.visible = on and show_labels.value

    def resize(_=None):
        # viser 1.0 has no live point_size, so resizing means re-adding under the same name.
        for name, key in (("CA-1M", "ca1m"), ("ScanNet++", "scannetpp")):
            scene = scenes[name]
            scene["cloud"] = server.scene.add_point_cloud(
                f"/{key}/cloud", points=scene["points"], colors=scene["colors"],
                point_size=point_size.value)
        restyle()

    for control in (which, show_cloud, show_labels, solid, opacity):
        control.on_update(restyle)
    point_size.on_update(resize)
    restyle()

    print(f"serving on http://localhost:{args.port}")
    import time
    while True:
        time.sleep(1.0)


if __name__ == "__main__":
    main()
