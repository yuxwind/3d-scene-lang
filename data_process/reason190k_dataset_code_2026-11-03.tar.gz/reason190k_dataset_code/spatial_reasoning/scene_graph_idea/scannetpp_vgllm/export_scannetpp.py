"""One ScanNet++ scene -> the ca1m_vgllm format: 9-DoF boxes in camera 0's frame.

ScanNet++ already ships oriented boxes (`segments_anno.json` -> segGroups[].obb), so unlike
CA-1M there is nothing to fit -- centroid/axesLengths/normalizedAxes map straight onto
CA-1M's position/scale/R. `normalizedAxes` needs a .reshape(3,3).T: with the transpose 94%
of boxes have an axis within 5 deg of world z, without it 53%.

Same pipeline shape as ca1m_vgllm/export_vgllm.py, and it imports that module's to_camera /
to_vgllm and stage2_graph's count_inside so the two corpora cannot drift apart:

  frames   64 uniform COLMAP-registered frames, ffmpeg'd out of iphone/rgb.mkv
  cloud    mesh_aligned_0.05.ply vertices -- the geometry the annotation is tied to
  filter   VGLLM_EXCLUDE, then >=1 cloud point inside the box, counting only points
           that land in some chosen camera's frustum (CA-1M's "the scan saw it in the
           frames the model is shown", not merely "it exists in the scene")

  conda activate vsibench_eval_full
  python scannetpp_vgllm/export_scannetpp.py --scene-id 39f36da05b
  python scannetpp_vgllm/export_scannetpp.py --selftest
"""

import argparse
import json
import os
import subprocess
import sys

import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))
CA1M = os.path.join(os.path.dirname(ROOT), "ml-cubifyanything")
sys.path.insert(0, os.path.join(CA1M, "ca1m_vgllm"))
sys.path.insert(0, os.path.join(CA1M, "ca1m_toon_faro"))

from export_vgllm import to_camera, to_vgllm                      # noqa: E402
from stage2_graph import count_inside                             # noqa: E402
from visualize_ca1m_in_vggt import VGLLM_EXCLUDE                  # noqa: E402

DATA = "/scratch/ducpham/Working/dataset/scannetpp/data"


def read_ply_vertices(path):
    """xyz + rgb out of ScanNet++'s binary_little_endian mesh. The header is fixed
    (float x,y,z + uchar red,green,blue), so a structured dtype beats a ply library."""
    with open(path, "rb") as f:
        header, count = [], None
        while True:
            line = f.readline().decode()
            header.append(line)
            if line.startswith("element vertex"):
                count = int(line.split()[2])
            if line.startswith("end_header"):
                break
        dtype = np.dtype([("x", "<f4"), ("y", "<f4"), ("z", "<f4"),
                          ("r", "u1"), ("g", "u1"), ("b", "u1")])
        assert "property float x" in "".join(header), path
        raw = np.frombuffer(f.read(count * dtype.itemsize), dtype=dtype, count=count)
    xyz = np.stack([raw["x"], raw["y"], raw["z"]], axis=-1)
    rgb = np.stack([raw["r"], raw["g"], raw["b"]], axis=-1) / 255.0
    return xyz.astype(np.float32), rgb.astype(np.float32)


def quat_to_rot(q):
    """COLMAP stores (qw, qx, qy, qz)."""
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]])


def read_colmap(colmap_dir):
    """-> (frame names sorted, K, cam2world [N,4,4], width, height).

    images.txt holds world->camera (qvec, tvec); CA-1M's RT is camera->world, so invert.
    The OPENCV model's distortion is ignored -- it only matters at the frame edges and
    this K is used for a frustum test, not for reprojecting pixels.
    """
    line = next(l for l in open(os.path.join(colmap_dir, "cameras.txt"))
                if not l.startswith("#"))
    _, model, width, height, fx, fy, cx, cy, *_ = line.split()
    assert model == "OPENCV", model
    K = np.array([[float(fx), 0, float(cx)], [0, float(fy), float(cy)], [0, 0, 1]])

    poses = {}
    for line in open(os.path.join(colmap_dir, "images.txt")):
        if line.startswith("#") or not line.strip():
            continue
        parts = line.split()
        if len(parts) < 10:                       # the per-image 2D-point line
            continue
        rot = quat_to_rot([float(v) for v in parts[1:5]])
        t = np.array([float(v) for v in parts[5:8]])
        RT = np.eye(4)
        RT[:3, :3], RT[:3, 3] = rot.T, -rot.T @ t        # world->cam inverted
        poses[parts[9]] = RT

    names = sorted(poses)
    return names, K, np.stack([poses[n] for n in names]), int(width), int(height)


def visible(points, K, RTs, width, height):
    """Mask of points landing in front of, and inside, at least one camera's image."""
    seen = np.zeros(len(points), dtype=bool)
    for RT in RTs:
        cam = (points - RT[:3, 3]) @ RT[:3, :3]          # world -> this camera
        front = cam[:, 2] > 1e-6
        uv = cam[front] @ K.T
        uv = uv[:, :2] / uv[:, 2:3]
        inside = ((uv >= 0) & (uv < [width, height])).all(1)
        seen[np.flatnonzero(front)[inside]] = True
    return seen


def extract_frames(video, out_dir, frame_ids):
    """ffmpeg the chosen video frames straight out of rgb.mkv, in order.

    The COLMAP names are frame_%06d.jpg numbered from video frame 0 (prepare_iphone_data.py
    extracts with -start_number 0), so the name index IS the video frame index.
    """
    os.makedirs(out_dir, exist_ok=True)
    expr = "+".join(f"eq(n\\,{i})" for i in frame_ids)
    subprocess.run(
        ["ffmpeg", "-v", "error", "-y", "-i", video, "-vf", f"select='{expr}'",
         "-vsync", "0", os.path.join(out_dir, "%03d.png")], check=True)
    got = sorted(os.listdir(out_dir))
    assert len(got) == len(frame_ids), f"ffmpeg gave {len(got)} of {len(frame_ids)} frames"
    for i, name in enumerate(got):                        # ffmpeg numbers from 1
        os.rename(os.path.join(out_dir, name), os.path.join(out_dir, f"{i:03d}.png.tmp"))
    for i in range(len(got)):
        os.rename(os.path.join(out_dir, f"{i:03d}.png.tmp"), os.path.join(out_dir, f"{i:03d}.png"))


def build(scene_id, data_root, out_root, num_frames, min_points, ndigits, skip_frames=False):
    src = os.path.join(data_root, scene_id)
    dst = os.path.join(out_root, scene_id)
    os.makedirs(dst, exist_ok=True)

    names, K, RTs, width, height = read_colmap(os.path.join(src, "iphone", "colmap"))
    pick = np.linspace(0, len(names) - 1, num_frames).round().astype(int)
    assert len(set(pick)) == num_frames, f"only {len(names)} registered frames"
    names, RTs = [names[i] for i in pick], RTs[pick]

    if not skip_frames:
        extract_frames(os.path.join(src, "iphone", "rgb.mkv"), os.path.join(dst, "frames"),
                       [int(n.split("_")[1].split(".")[0]) for n in names])
    np.savez(os.path.join(dst, "cams.npz"), K=np.stack([K] * num_frames), RT=RTs)

    link = os.path.join(dst, "scans")
    if not os.path.islink(link):
        os.symlink(os.path.relpath(os.path.join(src, "scans"), dst), link)

    points, _ = read_ply_vertices(os.path.join(src, "scans", "mesh_aligned_0.05.ply"))
    points = points[visible(points, K, RTs, width, height)]

    world2cam = np.linalg.inv(RTs[0])
    rows, dropped = [], {"structural": 0, "empty": 0}
    groups = json.load(open(os.path.join(src, "scans", "segments_anno.json")))["segGroups"]
    for group in groups:
        if group["label"].lower() in VGLLM_EXCLUDE:
            dropped["structural"] += 1
            continue
        obb = group["obb"]
        centre = np.array(obb["centroid"], dtype=float)
        rot = np.array(obb["normalizedAxes"], dtype=float).reshape(3, 3).T
        extent = np.array(obb["axesLengths"], dtype=float)
        if count_inside(points, centre, rot, extent) < min_points:
            dropped["empty"] += 1
            continue
        rows.append((group["label"], to_camera(centre, rot, extent, world2cam)))

    text = to_vgllm(rows, ndigits)
    with open(os.path.join(dst, "scene_graph.txt"), "w") as f:
        f.write(text + "\n")
    return len(rows), len(groups), dropped, len(points)


def selftest():
    """The PLY reader, the COLMAP inversion and the frustum test each get one check."""
    # A camera at the origin looking down +z keeps only what is in front of it and in frame.
    K = np.array([[100.0, 0, 50], [0, 100.0, 50], [0, 0, 1]])
    RT = np.eye(4)
    pts = np.array([[0, 0, 1.0],        # dead centre  -> (50, 50)   visible
                    [0, 0, -1.0],       # behind                     hidden
                    [10, 0, 1.0]])      # u = 1050, off the right     hidden
    assert visible(pts, K, RT[None], 100, 100).tolist() == [True, False, False]

    # A camera translated +2 in x sees the point that sits at its own optical axis.
    RT2 = np.eye(4)
    RT2[:3, 3] = [2.0, 0, 0]
    assert visible(np.array([[2.0, 0, 1.0]]), K, RT2[None], 100, 100).tolist() == [True]

    # quat_to_rot must be a rotation, and match a known 90-deg turn about z.
    r = quat_to_rot([np.cos(np.pi / 4), 0, 0, np.sin(np.pi / 4)])
    assert np.allclose(r @ np.array([1.0, 0, 0]), [0, 1, 0], atol=1e-9), r
    assert np.allclose(r @ r.T, np.eye(3))
    print("selftest ok")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--scene-id", default="39f36da05b")
    p.add_argument("--data-root", default=DATA)
    p.add_argument("--out-root", default=os.path.join(ROOT, "train"))
    p.add_argument("--num-frames", type=int, default=64)
    p.add_argument("--min-points", type=int, default=1)
    p.add_argument("--ndigits", type=int, default=2)
    p.add_argument("--skip-frames", action="store_true", help="Reuse already-extracted PNGs.")
    p.add_argument("--selftest", action="store_true")
    args = p.parse_args()

    if args.selftest:
        return selftest()

    boxes, groups, dropped, visible_points = build(
        args.scene_id, args.data_root, args.out_root, args.num_frames,
        args.min_points, args.ndigits, args.skip_frames)
    print(f"{args.scene_id}: {boxes} boxes from {groups} segGroups, dropped {dropped}, "
          f"{visible_points} visible cloud points")


if __name__ == "__main__":
    main()
