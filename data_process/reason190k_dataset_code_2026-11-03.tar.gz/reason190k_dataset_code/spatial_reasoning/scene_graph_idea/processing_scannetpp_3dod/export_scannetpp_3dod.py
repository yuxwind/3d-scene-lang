"""One ScanNet++ scene -> the VG-LLM 3DOD json that process_threedod.py emits for ScanNet.

EmbodiedScan does not cover ScanNet++ (its infos pkl holds only matterport3d / scannet /
3rscan), so process_threedod.py cannot be pointed at it. Everything that pkl supplies is
however already in the ScanNet++ release, and this script substitutes it field for field:

  instances[].bbox_3d      -> segments_anno.json segGroups[].obb
  id2category[label_3d]    -> segGroups[].label, verbatim
  axis_align_matrix        -> identity; mesh_aligned_0.05.ply is already gravity-aligned
  images[].cam2global      -> iphone/colmap/images.txt, world->cam inverted
  cam2img                  -> iphone/colmap/cameras.txt (OPENCV)
  images[].img_path        -> frames ffmpeg'd out of iphone/rgb.mkv
  frame.visible_instance_ids -> NO equivalent. Replaced by a frustum + point-in-box test
                             over the window's own frames (see window_boxes).

The box maths is process_threedod.process_data_item's, called through VG-LLM's own
o3d_geo_to_9dof so the two corpora cannot drift: world OBB -> camera-0 -> 9-DoF ZXY.

`normalizedAxes` needs .reshape(3, 3).T -- with the transpose 94% of this scene's boxes
have an axis within 5 deg of world z, without it 53%.

  conda activate vsibench_eval_full
  python processing_scannetpp_3dod/export_scannetpp_3dod.py --selftest
  python processing_scannetpp_3dod/export_scannetpp_3dod.py --scene-id 39f36da05b
  python processing_scannetpp_3dod/export_scannetpp_3dod.py --scene-id 39f36da05b --overlay 0
"""

import argparse
import itertools
import json
import os
import random
import sys

import numpy as np
import open3d as o3d

ROOT = os.path.dirname(os.path.abspath(__file__))
SIBLING = os.path.join(os.path.dirname(ROOT), "scannetpp_vgllm")
VGLLM_PRE = os.path.join(os.path.dirname(ROOT), "VG-LLM", "scripts", "preprocess")
sys.path.insert(0, SIBLING)
sys.path.insert(0, VGLLM_PRE)

from export_scannetpp import extract_frames, read_colmap, read_ply_vertices, visible  # noqa: E402
from utils import o3d_geo_to_9dof                                                     # noqa: E402

DATA = "/scratch/ducpham/Working/dataset/scannetpp/data"
OUT = "/scratch/ducpham/Working/dataset/vgllm_data/scannetpp_3dod"
# process_threedod.py:58 drops these from every ScanNet window; keep the same set.
EXCLUDE = {"wall", "ceiling", "floor", "object"}


def load_boxes(scene_dir):
    """segments_anno.json -> [(label, centre, rot, extent)] in the mesh's world frame."""
    groups = json.load(open(os.path.join(scene_dir, "scans", "segments_anno.json")))["segGroups"]
    out = []
    for group in groups:
        if group["label"].lower() in EXCLUDE:
            continue
        obb = group["obb"]
        out.append((
            group["label"],
            np.array(obb["centroid"], dtype=float),
            np.array(obb["normalizedAxes"], dtype=float).reshape(3, 3).T,
            np.array(obb["axesLengths"], dtype=float),
        ))
    return out, len(groups)


def to_camera(centre, rot, extent, world2cam):
    """One world OBB -> 9-DoF [x,y,z,dx,dy,dz,yaw,roll,pitch] in world2cam's frame.

    process_threedod.process_data_item, line for line, via VG-LLM's own converter.
    """
    geo = o3d.geometry.OrientedBoundingBox(
        (world2cam @ np.array([*centre, 1.0]))[:3].reshape(3, 1),
        world2cam[:3, :3] @ rot,
        extent.reshape(3, 1),
    )
    return o3d_geo_to_9dof(geo, convention="ZXY")


def windows(n_frames, nframe, base_interval):
    """Every consecutive window, mirroring process_threedod's sliding start.

    COLMAP registers the iPhone stream at a fixed stride, so the sorted frame list is
    already the "consecutive" run process_threedod has to reconstruct by frame id.
    """
    span = nframe * base_interval
    # The window's last index is i + (nframe - 1) * base_interval, not i + span.
    return [list(range(i, i + span, base_interval))
            for i in range(0, n_frames - (nframe - 1) * base_interval)]


def window_boxes(boxes, points, K, RTs, width, height, min_points):
    """The boxes this window's frames actually saw.

    Stands in for EmbodiedScan's per-frame visible_instance_ids: a mesh vertex inside the
    box has to land in at least one of the window's images. No occlusion test, so a box
    behind a wall still counts when its geometry falls in frustum.
    """
    seen = points[visible(points, K, RTs, width, height)]
    if not len(seen):
        return []
    kept = []
    for label, centre, rot, extent in boxes:
        local = (seen - centre) @ rot
        inside = (np.abs(local) <= extent / 2).all(1).sum()
        if inside >= min_points:
            kept.append((label, centre, rot, extent))
    return kept


def make_row(labels_boxes, image_paths, K, RTs, nframe):
    """The exact dict process_threedod.process_data_item returns, for the val split."""
    world2cam = np.linalg.inv(RTs[0])
    nine = [(label, to_camera(centre, rot, extent, world2cam))
            for label, centre, rot, extent in labels_boxes]

    question = "".join(["<image>\n"] * nframe) + (
        "Detect the 3D bounding boxes in the camera coordinate system of the first frame.\n"
        'Output a json list where each entry contains the object name in "label" and its '
        '3D bounding box in "bbox_3d".\nThe 3D bounding box format should be '
        "[x_center, y_center, z_center, x_size, y_size, z_size, yaw, roll, pitch].")
    items = [json.dumps({"label": label, "bbox_3d": [round(v, 2) for v in box]})
             for label, box in nine]
    answer = "```json\n[\n\t" + ",\n\t".join(items) + "\n]```"

    cam2img = np.eye(4)
    cam2img[:3, :3] = K
    return {
        "conversations": [{"from": "human", "value": question},
                          {"from": "gpt", "value": answer}],
        "images": image_paths,
        "boxes": [{"bbox_3d": box, "label": label} for label, box in nine],
        "cam2img": cam2img.tolist(),
        "cam2global": [RT.tolist() for RT in RTs],
        # The ScanNet++ mesh ships gravity-aligned, so the extrinsic
        # process_threedod builds as axis_align_matrix @ cam2global is just cam2global.
        "axis_align_matrix": np.eye(4).tolist(),
    }


def box_corners(nine):
    """9-DoF -> (8, 3) corners, ordered so corners differing in one sign bit are an edge."""
    centre, extent, euler = np.array(nine[:3]), np.array(nine[3:6]), np.array(nine[6:])
    rot = o3d.geometry.OrientedBoundingBox.get_rotation_matrix_from_zxy(euler.reshape(3, 1))
    signs = np.array(list(itertools.product([-1, 1], repeat=3)), dtype=float)
    return centre + (signs * extent / 2) @ rot.T


EDGES = [(i, j) for i in range(8) for j in range(i + 1, 8)
         if bin(i ^ j).count("1") == 1]


def draw_overlay(row, frame_index, image_root, out_path):
    """Project the row's camera-0 boxes onto one of its frames and save a wireframe PNG.

    This is the check a 3D viewer cannot make: boxes, poses, intrinsics and the frame list
    all have to agree for the wireframes to land on the objects. A transposed rotation, the
    wrong Euler order or a frame/pose off-by-one all show up here and nowhere else.
    """
    from PIL import Image, ImageDraw

    K = np.array(row["cam2img"])[:3, :3]
    RTs = [np.array(m) for m in row["cam2global"]]
    cam_from_cam0 = np.linalg.inv(RTs[frame_index]) @ RTs[0]

    image = Image.open(os.path.join(image_root, row["images"][frame_index])).convert("RGB")
    draw = ImageDraw.Draw(image)
    drawn = 0
    for box in row["boxes"]:
        pts = box_corners(box["bbox_3d"])
        cam = pts @ cam_from_cam0[:3, :3].T + cam_from_cam0[:3, 3]
        if (cam[:, 2] <= 1e-6).any():          # clipping a partially-behind box needs more
            continue                            # than a wireframe; skip it instead
        uv = (cam @ K.T)[:, :2] / cam[:, 2:3]
        if not ((uv[:, 0] > -image.width) & (uv[:, 0] < 2 * image.width)).any():
            continue
        for i, j in EDGES:
            draw.line([tuple(uv[i]), tuple(uv[j])], fill=(0, 255, 0), width=3)
        draw.text(tuple(uv[:, :2].mean(0)), box["label"], fill=(255, 255, 0))
        drawn += 1
    image.save(out_path)
    return drawn


def build(args):
    scene_dir = os.path.join(args.data_root, args.scene_id)
    names, K, RTs, width, height = read_colmap(os.path.join(scene_dir, "iphone", "colmap"))
    boxes, n_groups = load_boxes(scene_dir)
    points, _ = read_ply_vertices(os.path.join(scene_dir, "scans", "mesh_aligned_0.05.ply"))

    picks = windows(len(names), args.nframe, args.base_interval)
    if not picks:
        raise SystemExit(f"{args.scene_id}: {len(names)} frames, too few for {args.nframe}")
    if args.max_per_scan and len(picks) > args.max_per_scan:
        picks = random.Random(args.seed).sample(picks, args.max_per_scan)
    picks.sort()

    frame_dir = os.path.join(args.out_root, "frames", args.scene_id)
    needed = sorted({i for pick in picks for i in pick})
    if not args.skip_frames:
        extract_frames(os.path.join(scene_dir, "iphone", "rgb.mkv"), frame_dir,
                       [int(names[i].split("_")[1].split(".")[0]) for i in needed])
        for slot, i in enumerate(needed):      # extract_frames numbers 000.png upward
            os.rename(os.path.join(frame_dir, f"{slot:03d}.png"),
                      os.path.join(frame_dir, names[i].replace(".jpg", ".png")))

    rows = []
    for pick in picks:
        window_RTs = RTs[pick]
        kept = window_boxes(boxes, points, K, window_RTs, width, height, args.min_points)
        if len(kept) < args.min_boxes:
            continue
        paths = [f"scannetpp_3dod/frames/{args.scene_id}/{names[i].replace('.jpg', '.png')}"
                 for i in pick]
        rows.append(make_row(kept, paths, K, window_RTs, args.nframe))

    out_json = os.path.join(
        args.out_root,
        f"scannetpp_det_{args.scene_id}_{args.nframe}frames_bi{args.base_interval}.json")
    os.makedirs(args.out_root, exist_ok=True)
    json.dump(rows, open(out_json, "w"), indent=2)
    counts = [len(r["boxes"]) for r in rows]
    print(f"{args.scene_id}: {len(rows)} rows from {len(picks)} windows, "
          f"{len(boxes)} boxes kept of {n_groups} segGroups, "
          f"per-row boxes min {min(counts)} mean {sum(counts)/len(counts):.1f} max {max(counts)}"
          if counts else f"{args.scene_id}: no rows survived")
    print(f"wrote {out_json}")
    return out_json, rows


def selftest():
    """Round-trip the box maths and the projection the overlay depends on."""
    # A world box, taken to a camera frame and back, must come out where it started.
    centre, extent = np.array([1.0, 2.0, 3.0]), np.array([0.4, 0.5, 0.6])
    rot = o3d.geometry.OrientedBoundingBox.get_rotation_matrix_from_zxy(
        np.array([0.3, -0.2, 1.1]).reshape(3, 1))
    cam2world = np.eye(4)
    cam2world[:3, :3] = o3d.geometry.OrientedBoundingBox.get_rotation_matrix_from_zxy(
        np.array([-0.7, 0.4, 0.2]).reshape(3, 1))
    cam2world[:3, 3] = [0.5, -1.0, 2.0]

    nine = to_camera(centre, rot, extent, np.linalg.inv(cam2world))
    back = cam2world @ np.array([*nine[:3], 1.0])
    assert np.allclose(back[:3], centre, atol=1e-9), back
    assert np.allclose(nine[3:6], extent, atol=1e-9), nine
    # ...and the corners it yields must agree with the box it came from.
    corners = box_corners(nine)
    assert np.allclose(corners.mean(0), nine[:3], atol=1e-9)
    assert np.allclose(np.linalg.norm(corners[0] - corners[4]), extent[0], atol=1e-9)

    # A unit box one metre down +z projects around the principal point, not off-image.
    K = np.array([[100.0, 0, 50], [0, 100.0, 50], [0, 0, 1]])
    pts = box_corners([0, 0, 1.0, 0.2, 0.2, 0.2, 0, 0, 0])
    proj = pts @ K.T
    uv = proj[:, :2] / proj[:, 2:3]
    assert (np.abs(uv - 50) < 30).all(), uv

    # Sliding windows must be consecutive, and start at every frame that fits.
    assert windows(5, 3, 1) == [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
    assert windows(5, 3, 2) == [[0, 2, 4]]
    assert windows(2, 3, 1) == []
    print("selftest ok")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--scene-id", default="39f36da05b")
    p.add_argument("--data-root", default=DATA)
    p.add_argument("--out-root", default=OUT)
    p.add_argument("--nframe", type=int, default=32)
    p.add_argument("--base_interval", type=int, default=1)
    p.add_argument("--max_per_scan", type=int, default=10,
                   help="0 = every window; 10 is what process_threedod keeps for val")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--min_points", type=int, default=1,
                   help="mesh vertices inside a box, among those the window's frames see")
    p.add_argument("--min_boxes", type=int, default=1)
    p.add_argument("--skip-frames", action="store_true", help="Reuse already-extracted PNGs.")
    p.add_argument("--overlay", type=int, default=None, metavar="FRAME",
                   help="After exporting, draw row 0's boxes on this frame index.")
    p.add_argument("--selftest", action="store_true")
    args = p.parse_args()

    if args.selftest:
        return selftest()

    out_json, rows = build(args)
    if args.overlay is not None and rows:
        out_png = os.path.join(args.out_root, f"overlay_{args.scene_id}_{args.overlay:02d}.png")
        # images[] paths are relative to the vgllm_data root, one level above out_root.
        drawn = draw_overlay(rows[0], args.overlay, os.path.dirname(args.out_root), out_png)
        print(f"overlay: {drawn}/{len(rows[0]['boxes'])} boxes drawn -> {out_png}")


if __name__ == "__main__":
    main()
