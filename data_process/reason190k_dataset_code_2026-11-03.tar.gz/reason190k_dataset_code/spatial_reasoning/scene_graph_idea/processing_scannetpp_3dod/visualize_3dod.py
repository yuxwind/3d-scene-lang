"""Viser view of one row of the exported ScanNet++ 3DOD json, in camera 0's frame.

The exporter's draw_overlay checks that boxes, poses and intrinsics agree by projecting
onto a frame. This checks the other half: how the boxes sit against real geometry, and how
much of the room a 32-frame window actually covers.

Everything is drawn in camera 0's frame -- the frame `bbox_3d` is written in, so the boxes
are shown exactly as the json states them, with no transform in between. The mesh is
frustum-culled to the row's own 32 cameras using the exporter's visible(), i.e. the same
point set the box filter ran on: a box floating with no cloud near it is one of the
through-the-wall cases the frustum test admits.

  conda activate vsibench_eval_full
  python processing_scannetpp_3dod/visualize_3dod.py --selftest
  python processing_scannetpp_3dod/visualize_3dod.py --index 0
"""

import argparse
import json
import os
import sys
import time

import numpy as np
import viser

ROOT = os.path.dirname(os.path.abspath(__file__))
IDEA = os.path.dirname(ROOT)
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(IDEA, "scannetpp_vgllm"))
sys.path.insert(0, os.path.join(IDEA, "ml-cubifyanything", "ca1m_vgllm"))

from export_scannetpp import read_colmap, read_ply_vertices, visible   # noqa: E402
from visualize import box_pose, label_color, to_camera0                # noqa: E402

# Deliberately NOT imported from export_scannetpp_3dod: that module pulls VG-LLM's utils,
# which imports open3d + shapely and costs ~2 min off Lustre. Nothing here needs them.
DATA = "/scratch/ducpham/Working/dataset/scannetpp/data"
OUT = "/scratch/ducpham/Working/dataset/vgllm_data/scannetpp_3dod"

_DEFAULT_JSON = os.path.join(OUT, "scannetpp_det_39f36da05b_32frames_bi1.json")


def scene_id_of(row):
    """images[] are '<corpus>/frames/<scene>/frame_xxxxxx.png'."""
    return row["images"][0].split("/")[-2]


def load_row(row, data_root, max_points, rng_seed=0):
    """-> (cloud, colors, camera-0-relative poses) for one exported row."""
    scene_dir = os.path.join(data_root, scene_id_of(row))
    K = np.array(row["cam2img"])[:3, :3]
    RTs = np.array([np.array(m) for m in row["cam2global"]])

    # The row carries K but not the sensor size the frustum test needs.
    _, _, _, width, height = read_colmap(os.path.join(scene_dir, "iphone", "colmap"))

    points, colors = read_ply_vertices(os.path.join(scene_dir, "scans", "mesh_aligned_0.05.ply"))
    keep = visible(points, K, RTs, width, height)
    points, colors = points[keep], colors[keep]
    if len(points) > max_points:
        idx = np.random.default_rng(rng_seed).choice(len(points), max_points, replace=False)
        points, colors = points[idx], colors[idx]

    # Each camera relative to camera 0, which is what the boxes are expressed against.
    rel = np.linalg.inv(RTs[0])[None] @ RTs
    return to_camera0(points, RTs[0]).astype(np.float32), colors, rel, K, width, height


def add_row(server, row, points, colors, rel, K, width, height, point_size, frustum_scale):
    from scipy.spatial.transform import Rotation

    cloud = server.scene.add_point_cloud(
        "/row/cloud", points=points, colors=colors, point_size=point_size)

    boxes, labels = [], []
    for i, box in enumerate(row["boxes"]):
        centre, wxyz, extent = box_pose(box["bbox_3d"])
        boxes.append(server.scene.add_box(
            f"/row/box_{i}", color=label_color(box["label"]), dimensions=tuple(extent),
            wxyz=wxyz, position=centre, wireframe=True))
        labels.append(server.scene.add_label(f"/row/label_{i}", box["label"], position=centre))

    fov = 2 * np.arctan(height / (2 * K[1, 1]))
    frusta = []
    for i, pose in enumerate(rel):
        x, y, z, w = Rotation.from_matrix(pose[:3, :3]).as_quat()
        frusta.append(server.scene.add_camera_frustum(
            f"/row/cam_{i}", fov=fov, aspect=width / height, scale=frustum_scale,
            wxyz=np.array([w, x, y, z]), position=pose[:3, 3],
            color=(255, 140, 0) if i else (0, 255, 0)))   # frame 0 green: it is the origin
    return {"cloud": cloud, "boxes": boxes, "labels": labels, "frusta": frusta,
            "points": points, "colors": colors}


def selftest():
    """The two things that would silently mis-draw the row."""
    from scipy.spatial.transform import Rotation

    from export_scannetpp_3dod import box_corners      # slow import, selftest only

    # box_pose's quaternion must reproduce the same corners the exporter's overlay drew,
    # or the viewer and the 2D check disagree about what the same 9 numbers mean.
    nine = [0.3, -0.4, 2.0, 0.6, 0.5, 0.4, 0.7, -0.2, 1.3]
    centre, wxyz, extent = box_pose(nine)
    rot = Rotation.from_quat([wxyz[1], wxyz[2], wxyz[3], wxyz[0]]).as_matrix()
    signs = np.array([[sx, sy, sz] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])
    mine = centre + (signs * extent / 2) @ rot.T
    assert np.allclose(np.sort(mine, axis=0), np.sort(box_corners(nine), axis=0), atol=1e-9)

    # Camera 0 relative to itself must be the identity, or the cloud and the boxes are in
    # different frames and every box will look uniformly displaced.
    RTs = np.stack([np.eye(4), np.eye(4)])
    RTs[0, :3, 3] = [1.0, 2.0, 3.0]
    RTs[1, :3, 3] = [1.5, 2.0, 3.0]
    rel = np.linalg.inv(RTs[0])[None] @ RTs
    assert np.allclose(rel[0], np.eye(4)), rel[0]
    assert np.allclose(rel[1][:3, 3], [0.5, 0, 0]), rel[1]

    # to_camera0 must agree with applying the same inverse as a matrix.
    pts = np.array([[1.0, 2.0, 3.0], [0.0, 0.0, 0.0]])
    manual = (np.linalg.inv(RTs[0]) @ np.c_[pts, np.ones(len(pts))].T).T[:, :3]
    assert np.allclose(to_camera0(pts, RTs[0]), manual, atol=1e-9)
    print("selftest ok")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--json", default=_DEFAULT_JSON, help="exported scannetpp_det_*.json")
    p.add_argument("--index", type=int, default=0, help="row of the json")
    p.add_argument("--data-root", default=DATA)
    p.add_argument("--port", type=int, default=8083)   # 8080-8082 are the other viewers
    p.add_argument("--max-points", type=int, default=1_000_000)
    p.add_argument("--point-size", type=float, default=0.01)
    p.add_argument("--frustum-scale", type=float, default=0.08)
    p.add_argument("--no-serve", action="store_true", help="Build and report, then exit.")
    p.add_argument("--selftest", action="store_true")
    args = p.parse_args()

    if args.selftest:
        return selftest()

    rows = json.load(open(args.json))
    row = rows[args.index]
    points, colors, rel, K, width, height = load_row(row, args.data_root, args.max_points)
    span = np.linalg.norm(rel[:, :3, 3] - rel[0, :3, 3], axis=1).max()
    print(f"row {args.index}/{len(rows)}: scene {scene_id_of(row)}, {len(row['boxes'])} boxes, "
          f"{len(points)} visible points, {len(rel)} frames, camera path spans {span:.2f} m")

    server = viser.ViserServer(port=args.port)
    server.scene.add_frame("/camera0", axes_length=0.5, axes_radius=0.012)
    scene = add_row(server, row, points, colors, rel, K, width, height,
                    args.point_size, args.frustum_scale)

    show_cloud = server.gui.add_checkbox("Show cloud", True)
    show_labels = server.gui.add_checkbox("Show labels", True)
    show_frusta = server.gui.add_checkbox("Show cameras", True)
    solid = server.gui.add_checkbox("Solid boxes", False)
    opacity = server.gui.add_slider("Opacity", 0.05, 1.0, 0.05, 0.4)

    def restyle(_=None):
        scene["cloud"].visible = show_cloud.value
        for handle in scene["boxes"]:
            handle.wireframe = not solid.value
            handle.opacity = opacity.value if solid.value else None
        for label in scene["labels"]:
            label.visible = show_labels.value
        for frustum in scene["frusta"]:
            frustum.visible = show_frusta.value

    for control in (show_cloud, show_labels, show_frusta, solid, opacity):
        control.on_update(restyle)
    restyle()

    if args.no_serve:
        return print("built ok, not serving")
    print(f"serving on http://localhost:{args.port}")
    while True:
        time.sleep(1.0)


if __name__ == "__main__":
    main()
