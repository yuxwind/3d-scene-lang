"""Full scannet_det export at an arbitrary --nframe / --base_interval.

process_threedod.py already does the windowing and the box transform; this only
adds what a 32-frame run needs: base_interval in the output filename (upstream
omits it, so two runs collide) and streaming json writing (119k x 32-frame rows
do not want to sit in a list first).

--max_per_scan reproduces what upstream does for val (process_threedod.py:152-154):
random.sample(items, 10) per scan, so the eval set is ~10 rows per room instead of
every window. Seeded, so the same corpus comes back on a re-run.

  python export_det_frames.py --split train --nframe 32 --base_interval 1
  python export_det_frames.py --split val --nframe 32 --max_per_scan 10 \
      --output_dir .../vgllm_data/evaluation/threedod/scannet
"""

import argparse
import json
import os
import pickle
import random
from types import SimpleNamespace

from tqdm import tqdm

from make_det_subset import windows
from process_threedod import process_data_item


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--embodiedscan", default="/scratch/ducpham/Working/dataset/embodiedscan/embodiedscan")
    p.add_argument("--split", default="train", choices=["train", "val"])
    p.add_argument("--nframe", type=int, default=32)
    p.add_argument("--base_interval", type=int, default=1)
    p.add_argument("--stride", type=int, default=1, help="keep every Nth window")
    p.add_argument("--max_per_scan", type=int, default=0,
                   help="randomly keep at most N windows per scan (0 = all); upstream uses 10 for val")
    p.add_argument("--seed", type=int, default=42, help="seed for --max_per_scan")
    p.add_argument("--reference_frame", default="first", choices=["first", "last"])
    p.add_argument("--include_cam_params", action="store_true")
    p.add_argument("--output_dir", default="/scratch/ducpham/Working/dataset/vgllm_data/train")
    p.add_argument("--out", default=None)
    args = p.parse_args()

    with open(os.path.join(args.embodiedscan, f"embodiedscan_infos_{args.split}.pkl"), "rb") as f:
        data = pickle.load(f)
    id2category = {v: k for k, v in data["metainfo"]["categories"].items()}

    item_args = SimpleNamespace(reference_frame=args.reference_frame, split=args.split,
                                include_cam_params=args.include_cam_params)

    scans = [s for s in data["data_list"] if s["sample_idx"].startswith("scannet")]
    out = args.out or os.path.join(
        args.output_dir,
        f"scannet_det_{args.split}_{args.nframe}frames_bi{args.base_interval}"
        f"{'' if args.stride == 1 else f'_s{args.stride}'}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)

    rng = random.Random(args.seed)
    n = 0
    empty_scans = 0
    with open(out, "w") as f:
        f.write("[\n")
        for scan in tqdm(scans):
            sels = windows(scan, args.nframe, args.base_interval)[:: args.stride]
            if not sels:
                # Scan has no run of nframe consecutive frames -- it contributes nothing.
                empty_scans += 1
                continue
            if args.max_per_scan and len(sels) > args.max_per_scan:
                sels = rng.sample(sels, args.max_per_scan)
            for sel in sels:
                if n:
                    f.write(",\n")
                json.dump(process_data_item(sel, scan, id2category, item_args), f, indent=2)
                n += 1
        f.write("\n]\n")
    print(f"{n} rows from {len(scans) - empty_scans}/{len(scans)} scans "
          f"({empty_scans} too short for {args.nframe} frames), "
          f"{os.path.getsize(out) / 1e6:.0f} MB -> {out}")


if __name__ == "__main__":
    main()
