"""Drop rows with an empty "boxes" list from a scannet_det json, in place.

Those rows come from windows where every visible instance was wall/ceiling/floor/
object and got filtered at process_threedod.py:58; they train the model to emit an
empty list.

  python drop_empty_boxes.py .../scannet_det_train_32frames_bi1.json
"""

import argparse
import json
import os


def main():
    p = argparse.ArgumentParser()
    p.add_argument("files", nargs="+")
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    for path in args.files:
        data = json.load(open(path))
        kept = [row for row in data if row["boxes"]]
        print(f"{os.path.basename(path)}: {len(data)} -> {len(kept)} rows "
              f"({len(data) - len(kept)} dropped)")
        if args.dry_run or len(kept) == len(data):
            continue
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(kept, f, indent=2)
        os.replace(tmp, path)


if __name__ == "__main__":
    main()
