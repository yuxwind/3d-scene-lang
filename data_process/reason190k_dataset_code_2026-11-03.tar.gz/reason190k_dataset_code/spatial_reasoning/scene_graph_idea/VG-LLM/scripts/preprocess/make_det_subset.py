"""Small scannet_det corpus for eyeballing a new --nframe / --base_interval setting.

Same windowing and box transform as process_threedod.py (its process_data_item is
imported, not reimplemented), but limited to the first --scenes scans and --per-scene
windows each, so a 32-frame config can be checked in seconds instead of an hour.

The windows are spread across the scan rather than taken consecutively: at
--base_interval 1 the first three windows differ by one frame and look identical.

  python make_det_subset.py --nframe 32 --base_interval 1
  python ../../visualize_scannet_det_gt.py --ann <out> --sample 0 --stride 4 --check
"""

import argparse
import json
import os
import pickle
from types import SimpleNamespace

from process_threedod import process_data_item
from utils import get_frame_id

SKIP = ("wall", "ceiling", "floor", "object")


def consecutive_runs(sample):
    """process_threedod's get_consecutive_frames: split where the frame index jumps."""
    last, runs, cur = -10, [], []
    for frame in sample["images"]:
        idx = get_frame_id(frame["img_path"])
        if idx == last + 10:
            cur.append(frame)
        else:
            runs.append(cur)
            cur = [frame]
        last = idx
    runs.append(cur)
    return runs


def windows(sample, nframe, base_interval):
    out = []
    for frames in consecutive_runs(sample):
        for i in range(len(frames) + 1):
            sel = frames[i : i + nframe * base_interval : base_interval]
            if len(sel) == nframe:
                out.append(sel)
    return out


def spread(items, k):
    """k items spread over the list, endpoints included."""
    if len(items) <= k:
        return items
    step = (len(items) - 1) / (k - 1) if k > 1 else 0
    return [items[round(i * step)] for i in range(k)]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--embodiedscan", default="/scratch/ducpham/Working/dataset/embodiedscan/embodiedscan")
    p.add_argument("--split", default="train", choices=["train", "val"])
    p.add_argument("--nframe", type=int, default=32)
    p.add_argument("--base_interval", type=int, default=1)
    p.add_argument("--scenes", type=int, default=5)
    p.add_argument("--per-scene", type=int, default=3, help="windows kept per scan")
    p.add_argument("--reference_frame", default="first", choices=["first", "last"])
    p.add_argument("--out", default=None)
    args = p.parse_args()

    with open(os.path.join(args.embodiedscan, f"embodiedscan_infos_{args.split}.pkl"), "rb") as f:
        data = pickle.load(f)
    id2category = {v: k for k, v in data["metainfo"]["categories"].items()}

    # process_data_item reads these off args; cam params are what the viewer needs.
    item_args = SimpleNamespace(reference_frame=args.reference_frame, split=args.split,
                                include_cam_params=True)

    scans = [s for s in data["data_list"] if s["sample_idx"].startswith("scannet")][: args.scenes]
    all_data = []
    for scan in scans:
        wins = windows(scan, args.nframe, args.base_interval)
        kept = spread(wins, args.per_scene)
        for sel in kept:
            all_data.append(process_data_item(sel, scan, id2category, item_args))
        n_boxes = [len(item["boxes"]) for item in all_data[-len(kept):]]
        print(f"{scan['sample_idx']}: {len(scan['images'])} frames, {len(wins)} windows, "
              f"kept {len(kept)}, boxes {n_boxes}")

    out = args.out or os.path.join(
        "/scratch/ducpham/Working/dataset/vgllm_data/train",
        f"scannet_det_{args.split}_{args.nframe}frames_bi{args.base_interval}_"
        f"{args.scenes}scenes.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        json.dump(all_data, f, indent=2)
    print(f"\n{len(all_data)} rows -> {out}")


if __name__ == "__main__":
    main()
