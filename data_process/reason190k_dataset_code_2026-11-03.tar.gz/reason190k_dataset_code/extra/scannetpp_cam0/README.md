# ScanNet++ poses for VSI-Bench: world origin -> first-frame camera

Goal: express the 1,458 VSI-Bench ScanNet++ questions (50 scenes, `full` split: arkitscenes 1601 + scannet 2071 +
scannetpp 1458 = 5130) in the camera frame of the first video frame instead of the ScanNet++ world / mesh frame.
Everything here was copied from `/scratch/ducpham/Working` on the source machine on 2026-10-27.

## TL;DR

1. First-frame camera = `aligned_pose` of `frame_000000` in `scannetpp/data/<scene>/iphone/pose_intrinsic_imu.json`.
   It is a 4x4 cam2world matrix already in the mesh / GT frame. `world2cam0 = inv(cam0)`.
2. Frame mapping: VSI-Bench ScanNet++ mp4s are 30 fps, the iPhone mkv (and the pose json) is 60 fps.
   `mp4 frame i == pose frame 2i - 3`, clamped to `[0, n-1]`, so mp4 frames 0 and 1 both map to pose frame 0.
3. GT geometry lives in `scans/segments_anno.json` (`segGroups[].obb`: `centroid`, `axesLengths`, `normalizedAxes`).
   Box axes = `normalizedAxes.reshape(3,3).T`. Map a box with `centre' = world2cam0 @ centre`,
   `axes' = world2cam0[:3,:3] @ axes`, extent unchanged.
4. `python cam0_convert.py` does exactly that for all 49 scenes on disk (numpy only), writing `cam0_boxes.jsonl`.
5. If you want the det_es-style result instead (visible instances only, 288-label vocabulary, 9-DoF ZXY in camera 0),
   it is already built: `prebuilt/det_es/<scene>/{meta.json,det.json}` and `prebuilt/vsib_det64f_scannetpp/det_eval.jsonl`.
   `meta.json["cam0_cam2global"]` is the same cam0 matrix.

The VSI-Bench rows themselves (`vsibench_scannetpp_1458.jsonl`) carry no coordinates, only question text and the
ground-truth value, so what gets converted is the per-scene instance geometry from which answers are re-derived.

## Why `aligned_pose` and not COLMAP

Measured in `notes/DET_ES_OPTIONS.md` (2026-09-13), sections 1 and 6:

- `aligned_pose` exists for every mkv frame, frame 0 included, and is already in the mesh frame. Median error vs
  COLMAP 0.2-0.45 deg / 0.7-1.4 cm, p95 0.7-3.4 deg / 3-5.5 cm (7 scenes). A global Umeyama of the raw `pose` is 2-3x worse.
- COLMAP (`iphone/colmap/images.txt`) is stride 10, leaves frame 0 unregistered in 13 % of scenes, and has holes
  (p50 2.8 s, p95 23 s). It is bundled as a fallback and for the intrinsics (`cameras.txt`, OPENCV 1920x1440 + 4 dist).
- Camera convention of both is COLMAP / OpenCV (x right, y down, z forward). For the 640x480 mp4 scale K by
  `[640/1920, 480/1440, 1]`.
- Frame fit: slope 2.000, offset -3, pixel correlation 0.995-0.999 at the matched frame (5 probes x 3 scenes).

## What is in this bundle

```
README.md                          this file
cam0_convert.py                    numpy-only converter (all instances, no visibility filter)
scenes_vsib_scannetpp.txt          the 50 VSI-Bench ScanNet++ scene ids
vsibench_scannetpp_1458.jsonl      the 1,458 rows of VSI-Bench test.jsonl with dataset == scannetpp
vsibench_rebuilt/                  eval rows as finetuning/*/eval.py builds them (README inside)
notes/DET_ES_OPTIONS.md            the measurement report behind every choice above
scannetpp/data/<scene>/
    iphone/pose_intrinsic_imu.json ARKit poses per mkv frame: timestamp, pose, aligned_pose, intrinsic, imu   (49 x ~20 MB)
    iphone/colmap/cameras.txt      OPENCV intrinsics
    iphone/colmap/images.txt       COLMAP poses, stride 10 (fallback)
    scans/segments_anno.json       instance labels + OBBs in the mesh frame
prebuilt/det_es/<scene>/           built 2026-09-17 with build_posed64f_scannetpp.py --source scannetpp_vsib
    meta.json                      cam0_cam2global, 64 sampled frame ids + per-frame cam2global / cam2img, pose_source=arkit_aligned
    det.json                       visible instances as 9-DoF ZXY boxes in camera 0, VG-LLM vocabulary
    frames/frameNN.jpg             the 64 collator frames (256x384), frame00 = the first mp4 frame
prebuilt/vsib_det64f_scannetpp/    det_eval.jsonl (49 rows), stats.json, build.log
code/det64f_posed_es/build_posed64f_scannetpp.py   the builder (recipe in its docstring)
code/det64f_posed_mp4/build_posed64f.py            reference builder: cam0 = frame00, g2c = inv(cam0), o3d_geo_to_9dof
code/export_scannetpp_3dod.py                      `to_camera(centre, rot, extent, world2cam)` -> 9-DoF
code/graph_vgllm.py                                VG-LLM box format / metric helpers imported by the builders
code/det_es_proto/q*.py                            the measurement scripts (ARKit vs COLMAP, frame fit, visibility)
download/dl_e7af285f7d.yml         official ScanNet++ downloader config for the missing scene, token removed
download/splits/nvs_sem_val.txt    all 50 bench scenes are in this split
```

## Running the converter

```bash
pip install numpy                      # nothing else
python cam0_convert.py                 # -> cam0_boxes.jsonl, one row per scene
python cam0_convert.py --frame 10      # camera of mp4 frame 10 as the origin instead
```

Each row: `scene`, `pose_frame`, `cam2world`, `world2cam`, `K_mkv_1920x1440`, and `boxes[]` with `instance_id`,
`label`, `centre`, `axes` (3x3, columns = box axes) and `extent`, all in the chosen camera frame.

Verified on the source machine on 2026-10-27: 49 scenes, see the run log at the end of this file.

## Rebuilding det_es exactly (optional)

`code/det64f_posed_es/build_posed64f_scannetpp.py --source scannetpp_vsib --scenes scenes_vsib_scannetpp.txt` reproduces
`prebuilt/`. It additionally needs:

- `scans/mesh_aligned_0.05.ply` per scene for the ray-cast visibility test (3.1 GB for 49 scenes, not bundled)
- the mp4s for pixels (`dataset/vsib/vsibench/scannetpp/<scene>.mp4`, 50 files, 985 MB, not bundled)
- open3d, decord, opencv, scipy, PIL (the `vsibench_eval_full` conda env on the source machine)
- three modules that are NOT on the source machine any more and must come from Jean Zay: `prep_scene.py` and
  `labelmap.py` (were in `spatial_reasoning/finetuning/viz_posed64f/`) and `bench_ids.json`
  (`spatial_reasoning/boxer/scannetpp_probe/plan_checks/`). Hard-coded roots at the top of the script (`W`, `JZ`) must be edited.

## The missing scene

`e7af285f7d` (3 of the 1,458 questions) has no raw data on the source machine; only its mp4 exists. It was never
downloaded because the September scene list came from the debiased split, which dropped this scene. It is in
`nvs_sem_val`, so the official downloader fetches it.

The 3D boxes are NOT in the pose file. They come from `scans/segments_anno.json` (`segGroups[].obb`), which is the
`scan_anno_json_path` asset. `download/dl_e7af285f7d.yml` is already set to this scene and to the five assets the other
49 scenes were fetched with:

```
download_scenes: ["e7af285f7d"]
download_assets: [iphone_pose_intrinsic_imu_path, iphone_colmap_dir, scan_anno_json_path, scan_mesh_path, scan_mesh_segs_path]
```

Put your token in it (the source machine keeps it in `dataset/scannetpp/download_token.txt`, deliberately not
bundled), set `data_root`, then from the ScanNet++ toolkit (https://github.com/scannetpp/scannetpp):

```bash
python download_scannetpp.py dl_e7af285f7d.yml      # ~60 MB; drop the two scan_mesh* assets to skip the 60 MB mesh
```

Afterwards `scannetpp/data/e7af285f7d/{iphone/pose_intrinsic_imu.json, iphone/colmap/, scans/segments_anno.json}`
exist and `cam0_convert.py` picks the scene up with no other change.

## Not bundled, with source paths

| Item | Size (49 scenes) | Source path on the old machine |
|---|---|---|
| mesh_aligned_0.05.ply | 3.1 GB | dataset/scannetpp/data/<scene>/scans/ |
| segments.json (segment -> vertex map) | 623 MB | dataset/scannetpp/data/<scene>/scans/ |
| colmap/points3D.txt | 510 MB | dataset/scannetpp/data/<scene>/iphone/colmap/ |
| rgb.mkv, depth.bin | large | dataset/scannetpp/data/<scene>/iphone/ |
| VSI-Bench ScanNet++ mp4s | 985 MB (50) | dataset/vsib/vsibench/scannetpp/ |
| VSI-Bench test.jsonl (all 5,130 rows) | small | cache/hub/datasets--nyu-visionx--VSI-Bench/snapshots/d7cb.../test.jsonl |
| raw ScanNet++ root, 907 scenes | large | dataset/scannetpp/data |

## Run log

```
2026-10-27 cam0_convert.py on the source machine: 49 scenes converted, scene e7af285f7d skipped (not on disk).
cross-check vs prebuilt/det_es: max |cam2world - meta.cam0_cam2global| = 2.4e-07 over 49 scenes;
max |box centre - det.json bbox_3d[:3]| = 5.3e-05 and max |sorted extent diff| = 5.0e-05 over 3594 matched instances (det.json boxes are a list aligned with meta.json instance_ids; bbox_3d = [x,y,z,dx,dy,dz,yaw,roll,pitch] in camera 0).
```
