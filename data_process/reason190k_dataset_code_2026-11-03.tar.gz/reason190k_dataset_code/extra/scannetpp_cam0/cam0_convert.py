#!/usr/bin/env python3
"""ScanNet++ world (mesh) frame -> first-frame camera, for the VSI-Bench ScanNet++ scenes. numpy only.

Per scene:
  cam0      = `aligned_pose` of pose frame 0 in iphone/pose_intrinsic_imu.json (cam2world, 4x4, already in the
              mesh / segments_anno frame). VSI-Bench mp4 frame 0 == mkv/pose frame 0 (DET_ES_OPTIONS.md s6).
  world2cam = inv(cam0)
  every instance OBB in scans/segments_anno.json is mapped into that frame:
      centre_cam = world2cam @ centre ; axes_cam = world2cam[:3,:3] @ axes ; extent unchanged
  axes = normalizedAxes.reshape(3,3).T (columns = box axes; verified 100 % of instance vertices inside, see the note).
  Camera convention = COLMAP / OpenCV (x right, y down, z forward); aligned_pose agrees with COLMAP to ~0.3 deg.

No visibility filter and no label mapping here. For the det_es-style output (visible instances only, 288-label vocab,
9-DoF ZXY) use code/det64f_posed_es/build_posed64f_scannetpp.py, or take prebuilt/det_es/<scene>/det.json.

usage: python cam0_convert.py [--root scannetpp/data] [--scenes scenes_vsib_scannetpp.txt] [--out cam0_boxes.jsonl]
       python cam0_convert.py --frame 10        # camera of VSI-Bench mp4 frame 10 instead of frame 0
"""
import argparse, json, os
import numpy as np


def pose_index(mp4_frame, n_pose_frames):
    """VSI-Bench ScanNet++ mp4 (30 fps) frame i -> iPhone mkv / pose frame (60 fps): 2i - 3, clamped."""
    return min(max(2 * mp4_frame - 3, 0), n_pose_frames - 1)


def load_pose(root, scene, mp4_frame):
    pj = json.load(open(os.path.join(root, scene, "iphone", "pose_intrinsic_imu.json")))
    k = pose_index(mp4_frame, len(pj))
    e = pj[f"frame_{k:06d}"]
    return k, np.array(e["aligned_pose"], float), np.array(e["intrinsic"], float), len(pj)


def obbs(root, scene):
    anno = json.load(open(os.path.join(root, scene, "scans", "segments_anno.json")))
    for g in anno["segGroups"]:
        o = g["obb"]
        axes = np.array(o["normalizedAxes"], float).reshape(3, 3).T
        yield g["objectId"], g["label"], np.array(o["centroid"], float), axes, np.array(o["axesLengths"], float)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", default="scannetpp/data")
    p.add_argument("--scenes", default="scenes_vsib_scannetpp.txt")
    p.add_argument("--out", default="cam0_boxes.jsonl")
    p.add_argument("--frame", type=int, default=0, help="VSI-Bench mp4 frame whose camera becomes the origin")
    a = p.parse_args()
    ids = [l.strip() for l in open(a.scenes) if l.strip() and not l.startswith("#")]
    n_done = 0
    with open(a.out, "w") as f:
        for s in ids:
            if not os.path.isdir(os.path.join(a.root, s)):
                print("skip, not on disk:", s)
                continue
            k, cam, K, n = load_pose(a.root, s, a.frame)
            w2c = np.linalg.inv(cam)
            boxes = []
            for oid, label, c, axes, ext in obbs(a.root, s):
                boxes.append({"instance_id": oid, "label": label,
                              "centre": (w2c @ np.append(c, 1.0))[:3].round(4).tolist(),
                              "axes": (w2c[:3, :3] @ axes).round(6).tolist(),
                              "extent": ext.round(4).tolist()})
            f.write(json.dumps({"scene": s, "mp4_frame": a.frame, "pose_frame": k, "n_pose_frames": n,
                                "cam2world": cam.tolist(), "world2cam": w2c.tolist(), "K_mkv_1920x1440": K.tolist(),
                                "boxes": boxes}) + "\n")
            n_done += 1
            print(s, "pose frame", k, "boxes", len(boxes))
    print("wrote", a.out, "scenes", n_done)


if __name__ == "__main__":
    main()
